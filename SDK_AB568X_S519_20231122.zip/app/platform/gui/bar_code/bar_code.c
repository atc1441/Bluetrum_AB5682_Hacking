#include "include.h"

#define TRACE_EN            0
#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

u16 get_gui_screen_width(void);

//code128编码值数组，，每一个字符占11个单位表示，代码中用两个byte表示（取后11位bit）
static uint16_t code128_encode_tbl[] ={
    0x6cc,0x66c,0x666,0x498,0x48c,0x44c,0x4c8,0x4c4,0x464,0x648,
    0x644,0x624,0x59c,0x4dc,0x4ce,0x5cc,0x4ec,0x4e6,0x672,0x65c,
    0x64e,0x6e4,0x674,0x76e,0x74c,0x72c,0x726,0x764,0x734,0x732,
    0x6d8,0x6c6,0x636,0x518,0x458,0x446,0x588,0x468,0x462,0x688,
    0x628,0x622,0x5b8,0x58e,0x46e,0x5d8,0x5c6,0x476,0x776,0x68e,
    0x62e,0x6e8,0x6e2,0x6ee,0x758,0x746,0x716,0x768,0x762,0x71a,
    0x77a,0x642,0x78a,0x530,0x50c,0x4b0,0x486,0x42c,0x426,0x590,
    0x584,0x4d0,0x4c2,0x434,0x432,0x612,0x650,0x7ba,0x614,0x47a,
    0x53c,0x4bc,0x49e,0x5e4,0x4f4,0x4f2,0x7a4,0x794,0x792,0x6de,
    0x6f6,0x7b6,0x578,0x51e,0x45e,0x5e8,0x5e2,0x7a8,0x7a2,0x5de,
    0x5ee,0x75e,0x7ae,0x684,0x690,0x69c,0x18EB
};

#define CODE128_MEX_LEN 30

#define CODE128_ONE_ELEMENT_SIZE 11


WEAK u8 code128_auto_encode(const char *src, uint8_t length, uint16_t *p_out)
{
    int i = 0;
    int j = 0;
    uint8_t chr_temp = 0;
    uint32_t check_digit = 0;

    p_out[0] = 0x69c;            //Start
    p_out++;
    check_digit += 105;          //Start C

    bool code_a = false;         //奇数需要转codeA
    u8 len = length;
    if (len % 2) {               //奇数
        len -= 1;
        code_a = true;
    }
//    printf("len:%d\n", len);

    for(i = 0,j = 0;i < len;i += 2,j++ )
    {
        if(src[i] < '0' || src[i] > '9' || src[i+1] < '0' || src[i+1] > '9')
        {
            return 0;
        }

        chr_temp = (src[i] - '0')*10 + src[i + 1] - '0';
        TRACE("chr_temp:%d\n", chr_temp);
        check_digit += (j + 1)*chr_temp;
        p_out[j] = code128_encode_tbl[chr_temp];
    }

    if (code_a) {
        p_out[j] = 0x75e;                                   //CODE A
        check_digit += (j+1)*101;                           //CODE A 计算校验码
        j++;

        chr_temp = (src[len] - '0') + 16;                   //奇数位
        p_out[j] = code128_encode_tbl[chr_temp];
        check_digit += (j+1) * chr_temp;                    //奇数位 计算校验码
        j++;
    }

    check_digit %= 103;

    p_out[j] = code128_encode_tbl[check_digit];           //校验码
    p_out[j+1] = 0x63a;                                     //结束符

    return ((len >> 1) + code_a * 2);
}

//条形码长度预览
u16 barcode_pixle_len_cala(char *str, u8 str_len, u8 pixel)
{
    int w = 0;
    uint16_t code128_temp[CODE128_MEX_LEN];
    memset(code128_temp, 0, CODE128_MEX_LEN*2);
    u8 len = code128_auto_encode(str, str_len, code128_temp);

    w = ((3 + len) * 11 + 2) * pixel;
    return w;
}

void *barcode_creat(void *parent, char *str, int x, int y, int h, u8 length, bool dir)
{
    bool bs = false;
    int color = 0;
    int w = 0;
    uint16_t code128_temp[CODE128_MEX_LEN];
    memset(code128_temp, 0, CODE128_MEX_LEN*2);
    u8 len = code128_auto_encode(str, length, code128_temp);
    printf("len=%d\n",len);
    u8 bar_each_len = 3;
    if (len > 8) {
        bar_each_len = 2;
    }

#if TRACE_EN
    for(u8 i=0;i<30;i++) {
        TRACE("%x, ", code128_temp[i]);
    }
    TRACE("\n");
#endif

    widget_page_t* page_ptr = widget_page_create((widget_page_t*)parent);
    widget_rect_t* rect_ptr = widget_rect_create(page_ptr);
    widget_rect_set_color(rect_ptr, COLOR_WHITE);

    TRACE("len:%d\n", len);
    for(u8 n=0;n<(3 + len);n++) {
        for(u8 j=0;j<11;j++) {
            bs = code128_temp[n] & (BIT(10 - j));
            color = bs ? COLOR_BLACK : COLOR_WHITE;
            widget_rect_t* rect = widget_rect_create(page_ptr);
            if (dir) {
                widget_set_location(rect, 20 + bar_each_len*j + n*11*bar_each_len, (h+20)/2, bar_each_len, h);
            } else {
                widget_set_location(rect, (h+20)/2, 20 + bar_each_len*j + n*11*bar_each_len, h, bar_each_len);
            }
            widget_rect_set_color(rect, color);
            w += bar_each_len;
        }
    }

    widget_rect_t* rect = widget_rect_create(page_ptr);
    if (dir) {
        widget_set_location(rect, 20 + bar_each_len*0 + (3 + len)*11*bar_each_len, (h+20)/2, bar_each_len, h);
    } else {
        widget_set_location(rect, (h+20)/2, 20 + bar_each_len*0 + (3 + len)*11*bar_each_len, h, bar_each_len);
    }
    widget_rect_set_color(rect, COLOR_BLACK);
    rect = widget_rect_create(page_ptr);
    if (dir) {
        widget_set_location(rect, 20 + bar_each_len*1 + (3 + len)*11*bar_each_len, (h+20)/2, bar_each_len, h);
    } else {
        widget_set_location(rect, (h+20)/2, 20 + bar_each_len*1 + (3 + len)*11*bar_each_len, h, bar_each_len);
    }
    widget_rect_set_color(rect, COLOR_BLACK);
    w += bar_each_len*2;

    if (dir) {
        widget_set_location(rect_ptr, (w+40)/2, (h+20)/2, w + 40, h + 20);
        widget_set_location(page_ptr, x, y, w + 40, h + 20);
    } else {
        widget_set_location(rect_ptr, (h+20)/2, (w+40)/2, h + 20, w + 40);
        widget_set_location(page_ptr, x, y, h + 20, w + 40);
    }
    TRACE("[ %d, %d]\n",  y, w);

    return page_ptr;
}
