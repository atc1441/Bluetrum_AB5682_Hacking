#include "include.h"

#define TRACE_EN                1

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif


AT(.com_text.tft_spi)
static void tft_te_refresh(void)
{
    TICK0CNT = 0;
    compo_cb.rtc_cnt = RTCCNT;
    compo_cb.rtc_cnt2 = RTCCON2;
    compo_cb.rtc_update = true;
    os_gui_draw();
}

AT(.com_text.tft_spi)
void tft_bglight_en(void)
{
    LCD_BL_EN();            //LCD BL(开背光)
}

AT(.com_text.tft_spi)
void tft_te_isr(void)
{
    if (WKUPEDG & BIT(16+PORT_TFT_INT_VECTOR)) {
        WKUPCPND = BIT(16+PORT_TFT_INT_VECTOR);
        bool flag_mode_nochange = true;
        if (sys_cb.te_mode != sys_cb.te_mode_next) {
            sys_cb.te_mode = sys_cb.te_mode_next;
            sys_cb.despi_baud = sys_cb.te_mode ? sys_cb.despi_baud1 : sys_cb.despi_baud2;
            DESPIBAUD = sys_cb.despi_baud;
            flag_mode_nochange = false;
        }
        if (sys_cb.te_mode) {
            //1TE MODE
            TICK1CNT = 0;
            TICK1CON |= BIT(0);         //TICK EN
        } else {
            //>1TE MODE, 如果Mode change停一个TE
            if (flag_mode_nochange) {
                tft_te_refresh();
            }
        }
        //延时打开背光
        if (sys_cb.te_bglight_cnt > 0) {
            sys_cb.te_bglight_cnt--;
            if (sys_cb.te_bglight_cnt == 0) {
                sys_cb.tft_bglight_frist_set = true;
            }
        }
    }
}

AT(.com_text.tft_spi)
void tick_te_isr(void)
{
    if (TICK1CON & BIT(9)) {
        TICK1CON &= ~BIT(0);
        TICK1CPND = BIT(9);
        tft_te_refresh();
    }
}

//将TE量化到0~100, 由于TE中断不及时，可能偶尔会超过100
AT(.com_text.tft_spi)
int tft_te_getnorm(void)
{
    return TICK0CNT * 100 * 64 / (int)((XOSC_CLK_HZ / 1000) * TFT_TE_CYCLE);
}

AT(.com_text.tft_spi)
void tft_frame_start(void)
{
    //tft_write_cmd12(0x2C);      //TFT_RAMWR
    tft_write_data_start();
#if (GUI_SELECT == GUI_TFT_240_ST7789)
    TFT_SPI_DATA_EN();
#endif
}

AT(.com_text.tft_spi)
void tft_frame_end(void)
{
    tft_write_end();
    if (sys_cb.tft_bglight_kick)
    {
        sys_cb.tft_bglight_kick = false;
        sys_cb.te_bglight_cnt = 3; //3TE后打开背光
    }
}


//设置背光亮度
void tft_bglight_set_level(uint8_t level, bool stepless_en)
{
    int8_t  base_duty = 0;  //根据限流电阻调整占空比增益
    int8_t  duty = 0;

    if(!stepless_en)
    {
        level = level * (100 / 5);
    }
    if(100 < level)
    {
        level = 100;
    }
    duty = base_duty + level;
    sys_cb.tft_bglight_duty = duty;

    if (sys_cb.tft_bglight_last_duty != sys_cb.tft_bglight_duty)
    {
        bsp_pwm_duty_set(PORT_TFT_BL, sys_cb.tft_bglight_duty, false);
        sys_cb.tft_bglight_last_duty = sys_cb.tft_bglight_duty;
    }
}

//背光亮度初始设置检测
void tft_bglight_frist_set_check(void)
{
    if(!sys_cb.tft_bglight_frist_set) {
        return ;
    }
    sys_cb.tft_bglight_frist_set = false;

    sys_cb.tft_bglight_last_duty = 0;
    //todo:后续根据客户定制调整
    if(0 == sys_cb.tft_bglight_duty)
    {
        sys_cb.tft_bglight_duty = 100;
    }
    tft_bglight_set_level(sys_cb.tft_bglight_duty,true);
}

//设置TE MODE
void tft_set_temode(bool mode)
{
    sys_cb.te_mode_next = mode;
}

void tft_init(void)
{
    //clk init
    CLKDIVCON2 = (CLKDIVCON2 & ~(BIT(4) * 0xF)) | BIT(4) * 2;   // TFTDE div
    CLKGAT2 |= BIT(4);
    RSTCON0 |= BIT(8);

    port_tft_init();

    //TE port interrupt
    port_irq_register(PORT_TFT_INT_VECTOR, tft_te_isr);
    port_wakeup_init(PORT_TFT_INT, 1, 1);               //开内部上拉, 下降沿唤醒

    //TICK Timer init
    CLKGAT0 |= BIT(27);
    TICK0CON = BIT(6) | BIT(5) | BIT(2);                //div64[6:4], xosc26m[3:1]
    TICK0PR = 0xFFFF;
    TICK0CNT = 0;
    TICK0CON |= BIT(0);                                 //TICK EN

    TICK1CON = BIT(7) | BIT(6) | BIT(5) | BIT(2);       //TIE, div64[6:4], xosc26m[3:1]
    TICK1PR = (int)((XOSC_CLK_HZ / 1000) * TFT_TE_CYCLE_DELAY) / 64;
    TICK1CNT = 0;
    sys_irq_init(IRQ_TE_TICK_VECTOR, 0, tick_te_isr);

    sys_cb.te_mode = false;                             //初始化
    sys_cb.te_mode_next = false;

    tft_set_temode(DEFAULT_TE_MODE);

    port_tft_reset();

    //DE
#if (GUI_SELECT == GUI_TFT_240_ST7789)
    DESPICON = BIT(27) | BIT(9) | BIT(7) | BIT(0);    //[28:27]IN RGB565, [9]MultiBit, [7]IE, [3:2]1BIT, [0]EN

#elif (GUI_SELECT == GUI_TFT_JD9853)
    DESPICON = BIT(27) | BIT(26) | BIT(18) | BIT(9) | BIT(7) | BIT(0);     //[28:27]IN RGB565, [9]MultiBit, [7]IE, [3:2], [0]EN
#else
    DESPICON = BIT(27) | BIT(9) | BIT(7) | BIT(3) | BIT(2) | BIT(0);    //[28:27]IN RGB565, [9]MultiBit, [7]IE, [3:2]4BIT, [0]EN
#endif
    sys_irq_init(IRQ_DESPI_VECTOR, 0, tft_spi_isr);

    DESPIBAUD = 1;      //读ID建议在20M以内
    TRACE("TFT ID: %x\n", tft_read_id());
    DESPIBAUD = sys_cb.despi_baud;

#if (GUI_SELECT == GUI_TFT_320_ST77916)
    tft_320_st77916_init();
#elif (GUI_SELECT == GUI_TFT_360_GC9C01)
    tft_360_gc9c01_init();
#elif (GUI_SELECT == GUI_OLED_466_ICNA3310B)
    oled_466_icna3310b_init();
#elif (GUI_SELECT == GUI_TFT_JD9853)
    tft_240_jd9853_init();
#elif (GUI_SELECT == GUI_TFT_240_ST7789)
    tft_240_st7789_init();
#else
    #error "Please Select GUI Display"
#endif

    tft_set_window(0, 0, GUI_SCREEN_WIDTH - 1, GUI_SCREEN_HEIGHT - 1);

    sys_cb.tft_bglight_kick = true; //延时打开背光
}

void tft_exit(void)
{
    bsp_pwm_disable(PORT_TFT_BL); //关背光
    port_tft_exit();
    port_irq_free(PORT_TFT_INT_VECTOR);
    port_wakeup_exit(PORT_TFT_INT);
    DESPICON = 0;
    TICK0CON = 0;
    TICK1CON = 0;
    RSTCON0 &= ~BIT(8);
    CLKGAT2 &= ~BIT(4);
}

