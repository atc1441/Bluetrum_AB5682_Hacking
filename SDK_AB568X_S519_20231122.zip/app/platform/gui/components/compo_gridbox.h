#ifndef _COMPO_GRIDBOX_H
#define _COMPO_GRIDBOX_H

//图标大小范围
#define GRIDBOX_ICON_MAX_SIZE           80              //组件图标集合图标进行缩放最大尺寸
#define GRIDBOX_ICON_MIN_SIZE           40              //组件图标集合图标进行缩放最小尺寸
#define GRIDBOX_ICON_INIT_SIZE          80
#define GRIDBOX_ITEM_CNT_MAX            36              //组件最多可以显示图标数

#define GRID_START_POS_X                (0)             //界面初始化显示偏移Y坐标
#define GRID_START_POS_Y                (0)             //界面初始化显示偏移X坐标
#define GRID_ICON_ROW_NUM               (6)             //界面一行可以显示的图标个数
#define GRID_ICON_COL_NUM               (6)             //界面一列可以显示的图标个数
#define GRID_ICON_TOTAL_NUM             (36)            //界面要显示图标个数，不可大于组件最多显示图标数
#define GRID_RES_ICON_SIZE              (80)            //图标资源的图标大小

typedef struct compo_gridbox_item_t_ {
    u32 res_addr;                                       //图标
    u8 func_sta;                                        //对应任务
}compo_gridbox_item_t;

typedef struct compo_gridbox_t_ {
    COMPO_STRUCT_COMMON;
    widget_page_t *page;                                //底页
    widget_icon_t *sel_icon;                            //点击动作选择的图标
    u8 sel_idx;                                         //点击动作选择的图标下标
    u16 icon_width;                                     //gridbox组件中当前图标的宽度
    u16 icon_height;                                    //gridbox组件中当前图标的高度
    u8 icon_row_cnt;                                    //gridbox组件中一行可以最多显示图标数量
    u8 icon_col_cnt;                                    //gridbox组件中一列可以最多显示图标数量
    u16 icon_total_cnt;                                 //gridbox组件最多可以显示图标数量
    u16 icon_show_cnt;                                  //gridbox组件可以显示的图标数量
    point_t pos_xy;                                     //页面拖拽时的ofs
    point_t focus_pos_xy;                               //聚焦点对应的pos_xy
    s16 focus_idx;                                      //聚焦的图标下标
    u32 tick;
    compo_gridbox_item_t const *item;                   //图片资源
}compo_gridbox_t;

/**
 * @brief 更新图标集合Widget
 * @param[in] gridbox : gridbox指针
 **/
void compo_gridbox_update(compo_gridbox_t *gridbox);

/**
 * @brief 创建一个GRIDBOX组件
 * @param[in] frm : 窗体指针
 * @param[in] item : 图标资源
 * @return 返回图标集指针
 **/
compo_gridbox_t *compo_gridbox_create(compo_form_t *frm, const compo_gridbox_item_t *item);

/**
 * @brief 按坐标选择图标
 * @param[in] gridbox : gridbox指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 * @return 返回图标索引
 **/
int compo_gridbox_select(compo_gridbox_t *gridbox, s32 x, s32 y);

/**
 * @brief 按索引选择图标
 * @param[in] gridbox : gridbox指针
 * @param[in] idx : 编号索引
 * @return 返回图标指针
 **/
widget_icon_t *compo_gridbox_select_byidx(compo_gridbox_t *gridbox, int idx);

/**
 * @brief 按索引设置gridbox焦点坐标
 * @param[in] gridbox : gridbox指针
 * @param[in] idx : 编号索引
 **/
void compo_gridbox_set_focus_byidx(compo_gridbox_t* gridbox, int idx);

/**
 * @brief 设置gridbox图标大小
 * @param[in] gridbox : gridbox指针
 * @param[in] size : 图标大小
 **/
void compo_gridbox_set_iconsize(compo_gridbox_t* gridbox, u8 size);

/**
 * @brief 将坐标对齐到最临近的点
 * @param[in] gridbox : gridbox指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 * @return (x, y)坐标
 **/
point_t compo_gridbox_align_xy(compo_gridbox_t* gridbox, s16 to_x, s16 to_y);

/**
 * @brief 按坐标设置图标集合焦点坐标
 * @param[in] gridbox : gridbox指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 **/
void compo_gridbox_set_focus(compo_gridbox_t* gridbox, s16 focus_x, s16 focus_y);


#endif // _COMPO_GRIDBOX_H

