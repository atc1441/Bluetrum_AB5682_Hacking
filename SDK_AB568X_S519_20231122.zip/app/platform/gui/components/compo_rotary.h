#ifndef _COMPO_ROTARY_H
#define _COMPO_ROTARY_H

#define ROTARY_ITEM_CNT                     6
#define ROTARY_MAX_ITEM_CNT                 6           //转盘最多支持6张图片

//转盘项定义
typedef struct compo_rotary_item_t_ {
    u32 res_addr;               //图标
} compo_rotary_item_t;

typedef struct compo_rotary_t_ {
    COMPO_STRUCT_COMMON;
    widget_page_t *page;
    s16 cx;
    s16 cy;

    s16 angle;                          //转盘旋转角度
    u8 item_cnt;                        //转盘图片数量

    compo_rotary_item_t const *item;
    widget_image_t *item_img[ROTARY_MAX_ITEM_CNT];
} compo_rotary_t;

/**
 * @brief 创建一个转盘组件
 * @param[in] frm : 窗体指针
 * @param[in] item : 存放转盘相关的信息，图标等
 * @param[in] item_cnt : 存放转盘中信息的数量
 * @return 返回转盘指针
 **/
compo_rotary_t *compo_rotary_create(compo_form_t *frm, compo_rotary_item_t const *item, int item_cnt);

/**
 * @brief 更新转盘Widget
 * @param[in] rotary : 转盘指针
 **/
void compo_rotary_update(compo_rotary_t *rotary);

/**
 * @brief 设置转盘的旋转角度 (0 ~ 3599)
 * @param[in] rotary : 转盘指针
 * @param[in] angle : 旋转角度
 **/
void compo_rotary_set_rotation(compo_rotary_t *rotary, s16 angle);

#endif
