#ifndef _COMPO_TEXTBOX_H
#define _COMPO_TEXTBOX_H

typedef struct _compo_textbox_comm_t_
{
    COMPO_STRUCT_COMMON;
    widget_text_t *txt;
}compo_textbox_comm_t;


typedef struct compo_textbox_t_ {
    compo_textbox_comm_t comm;
    compo_roll_cb_t roll_cb;
    bool multiline;             //多行
} compo_textbox_t;

/**
 * @brief 创建一个文本框
 * @param[in] frm : 窗体指针
 * @param[in] max_word_cnt : 最大字数
 * @return 返回文本指针
 **/
compo_textbox_t *compo_textbox_create(compo_form_t *frm, u16 max_word_cnt);


/**
 * @brief 创建一个只有基础属性的文本框
 * @param[in] frm : 窗体指针
 * @param[in] max_word_cnt : 最大字数
 * @return 返回文本指针
 **/
compo_textbox_comm_t* compo_textbox_comm_create(compo_form_t *frm, u16 max_word_cnt);


/**
 * @brief 设置文本框内容
 * @param[in] textbox : 文本指针
 * @param[in] text : 文本内容 例："遥遥领先"
 **/
void compo_textbox_set(compo_textbox_t *textbox, const char *text);

/**
 * @brief 设置文本框的坐标及大小
          注意：文本框设置的坐标是以默认的中心点作为参考
 * @param[in] textbox : 文本指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 * @param[in] width : 文本框宽度
 * @param[in] height : 文本框高度
 **/
void compo_textbox_set_location(compo_textbox_t *textbox, s16 x, s16 y, s16 width, s16 height);

/**
 * @brief 设置文本框的坐标
          注意：文本框设置的坐标是以默认的中心点作为参考
 * @param[in] textbox : 文本指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 **/
void compo_textbox_set_pos(compo_textbox_t *textbox, s16 x, s16 y);

/**
 * @brief 设置文本框是否自适应尺寸
 * @param[in] textbox : 文本指针
 * @param[in] autosize : 是否自适应尺寸
 **/
void compo_textbox_set_autosize(compo_textbox_t *textbox, bool autosize);

/**
 * @brief 设置文本框是否为多行
 * @param[in] textbox : 文本指针
 * @param[in] multiline : 是否换行
 **/
void compo_textbox_set_multiline(compo_textbox_t *textbox, bool multiline);

/**
 * @brief 设置文本框是否居中
 * @param[in] textbox : 文本指针
 * @param[in] align_center : 是否居中
 **/
void compo_textbox_set_align_center(compo_textbox_t *textbox, bool align_center);

/**
 * @brief 设置文本框文字的颜色
 * @param[in] textbox : 文本指针
 * @param[in] color : 颜色
 **/
void compo_textbox_set_forecolor(compo_textbox_t *textbox, u16 color);

/**
 * @brief 设置文本框的透明度
 * @param[in] textbox : 文本指针
 * @param[in] alpha : 透明度
 **/
void compo_textbox_set_alpha(compo_textbox_t *textbox, u8 alpha);

/**
 * @brief 设置文本框是否可见
 * @param[in] textbox : 文本指针
 * @param[in] visible : 是否可见
 **/
void compo_textbox_set_visible(compo_textbox_t *textbox, bool visible);

/**
 * @brief 设置文本框自动滚动
 * @param[in] textbox : 文本指针
 * @param[in] autoroll : 是否自动滚动
 **/
void compo_textbox_set_autoroll(compo_textbox_t *textbox, bool autoroll);
#endif
