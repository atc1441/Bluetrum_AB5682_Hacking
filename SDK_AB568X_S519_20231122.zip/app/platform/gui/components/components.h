#ifndef _COMPONENTS_H
#define _COMPONENTS_H

enum COMPO_TYPE {
    COMPO_TYPE_NONE,
    COMPO_TYPE_FORM,                    //窗体
    COMPO_TYPE_PICTUREBOX,              //图像框
    COMPO_TYPE_TEXTBOX,                 //文本框
    COMPO_TYPE_COMM_TEXTBOX,            //基础的文本框
    COMPO_TYPE_SHAPE,                   //形状
    COMPO_TYPE_BUTTON,                  //铵钮
    COMPO_TYPE_NUMBER,                  //数字
    COMPO_TYPE_DATETIME,                //时间
    COMPO_TYPE_MSGBOX,                  //对话框
    COMPO_TYPE_LISTBOX,                 //列表框
    COMPO_TYPE_ICONLIST,                //图标集
    COMPO_TYPE_ROTARY,                  //转盘
    COMPO_TYPE_GRIDBOX,                 //栅格
    COMPO_TYPE_DISKLIST,                //圆盘列表
    COMPO_TYPE_KALEIDOSCOPE,            //万花筒
    COMPO_TYPE_ANIMATION,               //动图
    COMPO_TYPE_RINGS,                   //环形
};

//绑定数据
enum COMPO_BOND_DATA {
    COMPO_BOND_NONE,
    COMPO_BOND_YEAD,                    //年
    COMPO_BOND_MONTH,                   //月
    COMPO_BOND_DAY,                     //日
    COMPO_BOND_WEEKDAY,                 //周
    COMPO_BOND_HOUR,                    //时
    COMPO_BOND_MINUTE,                  //分
    COMPO_BOND_SECOND,                  //秒
    COMPO_BOND_HOUR_H,                  //时(十位)
    COMPO_BOND_HOUR_L,                  //时(个位)
    COMPO_BOND_MINUTE_H,                //分(十位)
    COMPO_BOND_MINUTE_L,                //分(个位)

    COMPO_BOND_IMAGE_STATIC = 16,       //静态图片
    COMPO_BOND_IMAGE_CLICK,             //点击图片

    COMPO_BOND_KCAL = 64,               //卡路里
    COMPO_BOND_STEP,                    //步数
    COMPO_BOND_HEARTRATE,               //心率
    COMPO_BOND_BLOOD_OXYGEN,            //血氧
    COMPO_BOND_BLOOD_SUGER,             //血糖
    COMPO_BOND_WEATHER,                 //天气
    COMPO_BOND_ATMOMS,                  //气压
    COMPO_BOND_TEMPERATURE,             //温度
    COMPO_BOND_REVERSE1,                //保留
    COMPO_BOND_ALTITUDE,                //海拔
    COMPO_BOND_REVERSE2,                //保留

};

#define COMPO_STRUCT_COMMON                                         \
    u8 type;                            /*组件类型*/                \
    u8 bond_data;                       /*绑定数据*/                \
    u16 id;                             /*组件ID*/

typedef struct component_t_ {
    COMPO_STRUCT_COMMON;
    u8 content[0];                      //组件详细内容
} component_t;

typedef struct compo_cb_t_ {
    u8 *buf0;                           //组件Buffer
    u32 buf0_size;
    u32 buf0_pos;
    u8 *buf1;
    u32 buf1_size;
    u32 buf1_pos;
    u8 top_num;

    //组件时间控制
    u32 rtc_cnt;
    u32 rtc_cnt2;
    tm_t tm;                            //时间tm结构体
    u16 mtime;                          //毫秒
    bool rtc_update;
} compo_cb_t;

extern compo_cb_t compo_cb;

typedef struct compo_form_t_ compo_form_t;

void compos_init(void);
void *compo_pool_create(bool flag_top);
void compo_pool_clear(compo_form_t *compo);
compo_form_t *compo_pool_get_top(void);
compo_form_t *compo_pool_get_bottom(void);
void *compo_create(compo_form_t *parent, u8 type);
void compo_bonddata(void *compo, u8 bond_data);         //设置组件绑定数据
void compo_setid(void *compo, u16 id);                  //设置组件ID
void *compo_get_head(void);
component_t *compo_get_next(component_t *compo);

#include "component_func.h"
#include "compo_form.h"
#include "compo_picturebox.h"
#include "compo_textbox.h"
#include "compo_shape.h"
#include "compo_button.h"
#include "compo_number.h"
#include "compo_datetime.h"
#include "compo_listbox.h"
#include "compo_iconlist.h"
#include "compo_rotary.h"
#include "compo_gridbox.h"
#include "compo_disklist.h"
#include "compo_kaleidoscope.h"
#include "compo_animation.h"
#include "compo_rings.h"

#endif
