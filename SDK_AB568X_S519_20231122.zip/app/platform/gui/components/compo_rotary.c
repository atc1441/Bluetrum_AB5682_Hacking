#include "include.h"

#define TRACE_EN                0

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

/**
 * @brief 创建一个转盘组件
 * @param[in] frm : 窗体指针
 * @param[in] item : 存放转盘相关的信息，图标等
 * @param[in] item_cnt : 存放转盘中信息的数量
 * @return 返回转盘指针
 **/
compo_rotary_t *compo_rotary_create(compo_form_t *frm, compo_rotary_item_t const *item, int item_cnt)
{
    int i;
    compo_rotary_t *rotary = compo_create(frm, COMPO_TYPE_ROTARY);
    widget_page_t *page = widget_page_create(frm->page_body);
    widget_set_location(page, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y, GUI_SCREEN_WIDTH, GUI_SCREEN_HEIGHT);
    rotary->cx = GUI_SCREEN_CENTER_X;
    rotary->cy = GUI_SCREEN_CENTER_Y;
    rotary->page = page;
    rotary->item = item;
    rotary->item_cnt = item_cnt;
    if (item_cnt <= 0 || item_cnt > ROTARY_MAX_ITEM_CNT) {
        halt(HALT_GUI_COMPO_ROTARY_CREATE);
    }
    for (i=0; i<ROTARY_ITEM_CNT; i++) {
        widget_image_t *img = widget_image_create(page, 0);
        rotary->item_img[i] = img;
        widget_image_set_rotation_mode(img, ROT_MODE_X);
    }
    return rotary;
}

/**
 * @brief 更新转盘Widget
 * @param[in] rotary : 转盘指针
 **/
void compo_rotary_update(compo_rotary_t *rotary)
{
    int i;
    int sidx;
    int s_angle = rotary->angle;
    s32 ea = 150;
    s32 eb = 60;
    s32 x, y;

    s_angle += 900;
    if (s_angle < 1800) {
        s_angle += 3600;
    }
    sidx = ((s_angle - 1800) * ROTARY_ITEM_CNT) / 3600;
    s_angle -= 3600 * sidx / ROTARY_ITEM_CNT;
    sidx = (sidx == 0) ? 0 : (ROTARY_ITEM_CNT - sidx);

    for (i=0; i<ROTARY_ITEM_CNT; i++) {
        int idx = sidx + i;
        s32 angle = s_angle + 3600 * i / ROTARY_ITEM_CNT;
        if (idx >= ROTARY_ITEM_CNT) {
            idx -= ROTARY_ITEM_CNT;
        }
        widget_image_t *img = rotary->item_img[i];
        compo_rotary_item_t const *item = &(rotary->item[idx]);
        widget_image_set(img, item->res_addr);
        x = muls_shift16(ea, COS(angle));
        y = muls_shift16(eb, SIN(angle));
        widget_set_pos(img, rotary->cx + x,  rotary->cy + y);
        widget_image_set_rotation_bypos(img, y * ea * ea / (eb * eb), x);
    }
}

/**
 * @brief 设置转盘的旋转角度 (0 ~ 3599)
 * @param[in] rotary : 转盘指针
 * @param[in] angle : 旋转角度
 **/
void compo_rotary_set_rotation(compo_rotary_t *rotary, s16 angle)
{
    if (angle < 0 || angle >= 3600) {
        halt(HALT_GUI_COMPO_ROTARY_ANGLE);
    }
    rotary->angle = angle;
}

