#include "include.h"

//图标之间的间距
#define     GRID_ICON_INTERVAL(icon_size)                   (icon_size/10 + icon_size)
//当屏幕没有偏移时, 图标显示在屏幕的X坐标 idx: icon所在第几列, space: 直接输入宏GRID_TOP_SPACE_X(icon_size), icon_size: 图标大小
#define     GRID_ICON_POS_X(idx, space, icon_size)          ((space + icon_size / 2) + (GRID_ICON_INTERVAL(icon_size) * (idx)))
//当屏幕没有偏移时, 图标显示在屏幕的Y坐标 idx: icon所在第几行, space: 直接输入宏GRID_TOP_SPACE_Y(icon_size), icon_size: 图标大小
#define     GRID_ICON_POS_Y(idx, space, icon_size)          ((space + icon_size / 2) + (GRID_ICON_INTERVAL(icon_size) * (idx)))
//当屏幕有偏移时, 图标显示在屏幕的Y坐标 i: icon所在第几行, icon_size: 图标大小, pos_y: 屏幕左上角起点坐标的y方向偏移
#define     POS_Y(i, icon_size, pos_y)                      (GRID_ICON_POS_Y(i, GRID_TOP_SPACE_Y(icon_size), icon_size) + icon_size / 2 - pos_y)
//当屏幕有偏移时, 图标显示在屏幕的X坐标 i: icon所在第几行, icon_size: 图标大小, pos_y: 屏幕左上角起点坐标的x方向偏移
#define     POS_X(i, icon_size, pos_x)                      (GRID_ICON_POS_X(i, GRID_TOP_SPACE_X(icon_size), icon_size) + icon_size / 2 - pos_x)
//用于自动计算gridbox组件页边距的中间变量
#define     POS_AUTO_X1(icon_size)                          (GRID_ICON_POS_X(GRID_ICON_ROW_NUM - 1, (icon_size/10), icon_size) + icon_size / 2 - GUI_SCREEN_WIDTH)
#define     POS_AUTO_Y1(icon_size)                          (GRID_ICON_POS_Y(GRID_ICON_COL_NUM - 1, (icon_size/10), icon_size) + icon_size / 2 - GUI_SCREEN_HEIGHT)
//当屏幕的图标需要回弹到初始显示状态对应的每个图标的坐标值 icon_size: 图标大小
#define     POS_AUTO_X(icon_size)                           (GRID_ICON_POS_X(GRID_ICON_ROW_NUM - 1, GRID_TOP_SPACE_X(icon_size), icon_size) + icon_size / 2 - GUI_SCREEN_WIDTH)
#define     POS_AUTO_Y(icon_size)                           (GRID_ICON_POS_Y(GRID_ICON_COL_NUM - 1, GRID_TOP_SPACE_Y(icon_size), icon_size) + icon_size / 2 - GUI_SCREEN_HEIGHT)
//自动计算gridbox组件中图标在不同大小对应的页边距, 保持图标集合都在页面的中心
#define     GRID_TOP_SPACE_Y(icon_size)                     (POS_AUTO_Y1(icon_size) < 0 ? ((GUI_SCREEN_HEIGHT - (GRID_ICON_POS_Y(GRID_ICON_COL_NUM - 1, (icon_size/10), icon_size) + icon_size / 2)) / 2) : (icon_size/10))
#define     GRID_TOP_SPACE_X(icon_size)                     (POS_AUTO_X1(icon_size) < 0 ? ((GUI_SCREEN_WIDTH - (GRID_ICON_POS_X(GRID_ICON_ROW_NUM - 1, (icon_size/10), icon_size) + icon_size / 2)) / 2) : (icon_size/10))

//static u8 icon_show_cnt=0;
static point_t compo_gridbox_idx2xy(compo_gridbox_t* gridbox, int idx);
static bool compo_gridbox_auto_limit(compo_gridbox_t *gridbox);


/**
 * @brief 创建一个GRIDBOX组件
 * @param[in] frm : 窗体指针
 * @param[in] item : 图标资源
 * @return 返回图标集指针
 **/
compo_gridbox_t *compo_gridbox_create(compo_form_t *frm, const compo_gridbox_item_t *item)
{
    u8 index = 0;
    int item_cnt = GRID_ICON_ROW_NUM * GRID_ICON_COL_NUM;
    compo_gridbox_t *gridbox = compo_create(frm, COMPO_TYPE_GRIDBOX);
    widget_page_t* page = widget_page_create(frm->page_body);

    widget_set_location(page, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y, GUI_SCREEN_WIDTH, GUI_SCREEN_HEIGHT);
    gridbox->item = item;
    gridbox->page = page;
    gridbox->icon_row_cnt = GRID_ICON_ROW_NUM;
    gridbox->icon_col_cnt = GRID_ICON_COL_NUM;
    gridbox->icon_width = GRIDBOX_ICON_INIT_SIZE;
    gridbox->icon_height = GRIDBOX_ICON_INIT_SIZE;
    gridbox->icon_total_cnt = item_cnt;
    gridbox->icon_show_cnt = GRID_ICON_TOTAL_NUM;
    gridbox->pos_xy.x = GRID_START_POS_X;
    gridbox->pos_xy.y = GRID_START_POS_Y;

    for(int i=0; i<GRID_ICON_COL_NUM; i++) {
        for(int j=0; j<gridbox->icon_row_cnt; j++) {
            //if(i*(gridbox->icon_row_cnt)+(j+1) > GRIDBOX_ITEM_CNT_MAX)
            //{
            //    break;
            //}
            //widget_page_t *item_page = widget_page_create(page);
            widget_icon_t *item_icon = widget_icon_create(page,0);
            widget_set_size(item_icon, GRID_RES_ICON_SIZE, GRID_RES_ICON_SIZE);
            widget_set_pos(item_icon, GRID_RES_ICON_SIZE/2, GRID_RES_ICON_SIZE/2);
            index++;
        }
    }
    return gridbox;
}

/**
 * @brief 将坐标对齐到最临近的点
 * @param[in] gridbox : gridbox指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 * @return (x, y)坐标
 **/
point_t compo_gridbox_align_xy(compo_gridbox_t* gridbox, s16 to_x, s16 to_y)
{
    int i=0,j=0;
    gridbox->focus_pos_xy.x = to_x;
    gridbox->focus_pos_xy.y = to_y;
    compo_gridbox_auto_limit(gridbox);

    //printf("to xy[%d,%d]\n", gridbox->focus_pos_xy.x, gridbox->focus_pos_xy.y);

    for (i=0; i<gridbox->icon_total_cnt/gridbox->icon_row_cnt; i++) {
        s16 x = GRID_ICON_POS_X(i,GRID_TOP_SPACE_X(gridbox->icon_width),gridbox->icon_width);
        if (x >= gridbox->focus_pos_xy.x + GUI_SCREEN_CENTER_X) {
            gridbox->focus_pos_xy.x = x - GUI_SCREEN_CENTER_X;
            break;
        }
    }

    for (j=0; j<gridbox->icon_row_cnt; j++) {
        s16 y = GRID_ICON_POS_Y(j,GRID_TOP_SPACE_Y(gridbox->icon_width),gridbox->icon_width);
        if (y >= gridbox->focus_pos_xy.y + GUI_SCREEN_CENTER_Y) {
            //printf("yt [%d,%d]\n", y, gridbox->focus_pos_xy.y+ GUI_SCREEN_CENTER_Y);
            gridbox->focus_pos_xy.y = y - GUI_SCREEN_CENTER_Y;
            break;
        }
    }

    return gridbox->focus_pos_xy;
}

/**
 * @brief 按索引设置gridbox焦点坐标
 * @param[in] gridbox : gridbox指针
 * @param[in] idx : 编号索引
 **/
void compo_gridbox_set_focus_byidx(compo_gridbox_t* gridbox, int idx)
{
    point_t grid_icon_pos_xy = compo_gridbox_idx2xy(gridbox, idx);      //根据图标idx计算 图标要到达的位置 进行聚焦
    point_t target_pos_xy;
    target_pos_xy.x = grid_icon_pos_xy.x - GUI_SCREEN_CENTER_X;         //目标点，当前xy_pos点要移动过去
    target_pos_xy.y = grid_icon_pos_xy.y - GUI_SCREEN_CENTER_Y;
    gridbox->pos_xy.x = target_pos_xy.x;      //xy_pos设置
    gridbox->pos_xy.y = target_pos_xy.y;
    //gridbox->focus_pos_xy.x = target_pos_xy.x;
    //gridbox->focus_pos_xy.y = target_pos_xy.y;
    gridbox->focus_idx = idx;
    compo_gridbox_auto_limit(gridbox);
}

/**
 * @brief 按坐标设置图标集合焦点坐标
 * @param[in] gridbox : gridbox指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 **/
void compo_gridbox_set_focus(compo_gridbox_t* gridbox, s16 focus_x, s16 focus_y)
{
    gridbox->pos_xy.x = focus_x;
    gridbox->pos_xy.y = focus_y;
    compo_gridbox_auto_limit(gridbox);
}


/**
 * @brief 更新图标集合Widget
 * @param[in] gridbox : gridbox指针
 **/
void compo_gridbox_update(compo_gridbox_t *gridbox)
{
    u8 update_index = 0;

    widget_t * widget = widget_get_next(gridbox->page);

    for (int i=0; i<gridbox->icon_total_cnt/gridbox->icon_row_cnt; i++) {
        for (int j=0; j<gridbox->icon_row_cnt; j++) {
            if (widget_is_icon(widget) && widget_get_parent(widget) == gridbox->page) {
                bool is_viable = (POS_Y(i, gridbox->icon_height, gridbox->pos_xy.y) >= 0) &&            //图标是否可以显示在屏幕上
                                 (POS_Y(i, gridbox->icon_height, gridbox->pos_xy.y) <= GUI_SCREEN_HEIGHT+gridbox->icon_height) &&
                                 (POS_X(j, gridbox->icon_width, gridbox->pos_xy.x) >= 0) &&
                                 (POS_X(j, gridbox->icon_width, gridbox->pos_xy.x) <= GUI_SCREEN_WIDTH+gridbox->icon_width);
                if (is_viable) {
                    //printf("%d\n",i*(gridbox->icon_row_cnt)+(j+1));
                    if (i * (gridbox->icon_row_cnt) + (j + 1) <= gridbox->icon_show_cnt) {
                        //printf("[1]item:%d\n",update_index);
                        widget_set_visible(widget, true);
                        widget_icon_set(widget, gridbox->item[update_index].res_addr);
                        widget_set_size(widget, gridbox->icon_width, gridbox->icon_height);
                        widget_set_pos(widget,
                                       GRID_ICON_POS_X(j, GRID_TOP_SPACE_X(gridbox->icon_width), gridbox->icon_width) - gridbox->pos_xy.x,
                                       GRID_ICON_POS_Y(i, GRID_TOP_SPACE_Y(gridbox->icon_height), gridbox->icon_height) - gridbox->pos_xy.y);
                    }
                } else {
                    widget_set_visible(widget, false);
                }
                update_index++;
            }
            widget = widget_get_next(widget);
        }
    }

}

/**
 * @brief 按坐标选择图标
 * @param[in] gridbox : gridbox指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 * @return 返回图标索引
 **/
int compo_gridbox_select(compo_gridbox_t *gridbox, s32 x, s32 y)
{
    int idx = 0;
    widget_t *widget = widget_get_next(gridbox->page);
    while (widget != NULL) {
        if (widget_get_parent(widget) == gridbox->page) {
            rect_t rect = widget_get_absolute(widget);
            if (abs_s(x - rect.x) * 2 <= rect.wid && abs_s(y - rect.y) * 2 <= rect.hei) {
                gridbox->sel_icon = widget;
                gridbox->sel_idx = idx;
                return idx;
            }
            idx++;
        }
        widget = widget_get_next(widget);
    }
    return -2;
}

/**
 * @brief 按索引选择图标
 * @param[in] gridbox : gridbox指针
 * @param[in] idx : 编号索引
 * @return 返回图标指针
 **/
widget_icon_t *compo_gridbox_select_byidx(compo_gridbox_t *gridbox, int idx)
{
    int i = 0;
    widget_t *widget = widget_get_next(gridbox->page);
    while (widget != NULL) {
        if (widget_get_parent(widget) == gridbox->page) {
            if (i == idx) {
                gridbox->sel_icon = widget;
                gridbox->sel_idx = idx;
                return gridbox->sel_icon;
            }
            i++;
        }
        widget = widget_get_next(widget);       //遍历Widget
    }
    gridbox->sel_icon = NULL;
    gridbox->sel_idx = -1;
    return NULL;
}

/**
 * @brief 设置gridbox图标大小
 * @param[in] gridbox : gridbox指针
 * @param[in] size : 图标大小
 **/
void compo_gridbox_set_iconsize(compo_gridbox_t* gridbox, u8 size)
{
    gridbox->icon_height = size;
    gridbox->icon_width = size;
}

//=========================================================================

static point_t compo_gridbox_idx2xy(compo_gridbox_t* gridbox, int idx)
{
    point_t point;
    for (int i=0; i<gridbox->icon_col_cnt; i++) {       //通过遍历解算idx对应的行和列
        for (int j=0; j<gridbox->icon_row_cnt; j++) {
            if (i * (gridbox->icon_row_cnt) + (j + 1) == idx + 1) {
                point.x = GRID_ICON_POS_X(j, GRID_TOP_SPACE_X(gridbox->icon_width), gridbox->icon_width);
                point.y = GRID_ICON_POS_Y(i, GRID_TOP_SPACE_Y(gridbox->icon_width), gridbox->icon_height);
                return point;
            }
        }
    }

    return point;
}

//判断图像偏移是否在限制区域内
static bool compo_gridbox_auto_limit(compo_gridbox_t *gridbox)
{
    point_t *point = NULL;
    for (u8 i=0; i<2; i++) {
        if (i == 0) {
            point = &gridbox->pos_xy;
        } else {
            point = &gridbox->focus_pos_xy;
        }
        //屏左上角移动限制区域
        bool x_min = ( point->x < ( GRID_ICON_POS_X(0, GRID_TOP_SPACE_X(gridbox->icon_width), gridbox->icon_width) - GUI_SCREEN_CENTER_X ) );
        bool y_min = ( point->y < ( GRID_ICON_POS_Y(0, GRID_TOP_SPACE_Y(gridbox->icon_height), gridbox->icon_height) - GUI_SCREEN_CENTER_Y ) );
        //屏左下角移动限制区域
        bool y_max = ( point->y > ( GRID_ICON_POS_Y(gridbox->icon_col_cnt - 1, GRID_TOP_SPACE_Y(gridbox->icon_height), gridbox->icon_height) - GUI_SCREEN_CENTER_Y ) );
        //屏右上角移动限制区域
        bool x_max = ( point->x > ( GRID_ICON_POS_X(gridbox->icon_row_cnt - 1, GRID_TOP_SPACE_X(gridbox->icon_width), gridbox->icon_width) - GUI_SCREEN_CENTER_X ) );
        //RB

        if (x_min || y_min || x_max || y_max) { //限制移动区域
            if (x_min) {
                point->x = ( GRID_ICON_POS_X(0, GRID_TOP_SPACE_X(gridbox->icon_width), gridbox->icon_width) - GUI_SCREEN_CENTER_X );
            } else if (x_max) {
                point->x = ( GRID_ICON_POS_X(gridbox->icon_row_cnt - 1, GRID_TOP_SPACE_X(gridbox->icon_width), gridbox->icon_width) - GUI_SCREEN_CENTER_X );
            }

            if (y_min) {
                point->y = ( GRID_ICON_POS_Y(0, GRID_TOP_SPACE_Y(gridbox->icon_height), gridbox->icon_height) - GUI_SCREEN_CENTER_Y );
            } else if (y_max) {
                point->y = ( GRID_ICON_POS_Y(gridbox->icon_col_cnt - 1, GRID_TOP_SPACE_Y(gridbox->icon_height), gridbox->icon_height) - GUI_SCREEN_CENTER_Y );
            }
            return false;
        }
    }

    return true;
}
