#include "include.h"

#define TRACE_EN                1

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

/**
 * @brief 根据数字图像资源创建一个数字
 * @param[in] frm : 窗体指针
 * @param[in] res_addr : 数字图片资源地址
 * @param[in] num_cnt : 表示该数字最大位数
 * @return 返回数字指针
 **/
 compo_number_t *compo_number_create(compo_form_t *frm, u32 res_addr, int num_cnt)
{
    int i;
    if (num_cnt <= 0 || num_cnt > MAX_NUMBER_CNT) {
        halt(HALT_GUI_COMPO_NUMBER_CNT);
    }
    compo_number_t *num = compo_create(frm, COMPO_TYPE_NUMBER);
    widget_page_t *page = frm->page_body;
    num->flag_zfill = false;
    num->num_cnt = num_cnt;
    num->max_val = 1;
    num->visible = true;
    for (i=0; i<num_cnt; i++) {
        //需要进行图像裁剪
        widget_image_t *img = widget_image_create(page, res_addr);
        if (num->num_wid == 0) {
            area_t area = gui_image_get_size(res_addr);
            num->num_wid = area.wid;
            num->num_hei = area.hei / 10;
            num->total_hei = area.hei;
        }
        widget_set_size(img, num->num_wid, num->num_hei);
        num->img_num[i] = img;
        num->max_val *= 10;
    }
    num->radix = 10;
    num->max_val--;
    compo_number_set_margin(num, num->num_wid / 8);
    return num;
}

/**
 * @brief 设置数字框裁剪个数
 * @param[in] num : 数字指针
 * @param[in] radix : 裁剪个数
 **/
void compo_number_set_radix(compo_number_t *num, u8 radix)
{
    num->radix = radix;
    num->num_hei = num->total_hei / radix;
    num->max_val = 1;
    for (int i=0; i<num->num_cnt; i++) {
        widget_set_size(num->img_num[i], num->num_wid, num->num_hei);
        num->max_val *= radix;
    }
    num->max_val--;
}

//更新内容
static void compo_number_update(compo_number_t *num)
{
    int i;
    int val = num->value;
    int total_wid = num->num_wid * num->num_cnt + num->x_margin * (num->num_cnt - 1);
    if (num->visible) {
        //显示
        int znum = num->num_cnt - 1;
        int x = num->x + ((total_wid - num->num_wid) >> 1);
        int y = num->y;
        int v = 0;
        for (i=znum; i>=0; i--) {
            v = val % num->radix;
            val /= num->radix;
            widget_image_cut(num->img_num[i], 0, v * num->num_hei, num->num_wid, num->num_hei);
            widget_set_pos(num->img_num[i], x, y);
            widget_set_visible(num->img_num[i], true);
            x -= num->num_wid + num->x_margin;
            if (v > 0) {
                znum = i;
            }
        }
        if (!num->flag_zfill) {
            for (i=0; i<znum; i++) {
                widget_set_visible(num->img_num[i], false);
            }
        }
    } else {
        //隐藏
        for (i=0; i<num->num_cnt; i++) {
            widget_set_visible(num->img_num[i], false);
        }
    }
}

/**
 * @brief 设置数字值
 * @param[in] num : 数字指针
 * @param[in] val : 设置的数值
 **/
void compo_number_set(compo_number_t *num, int val)
{
    if (val < 0 || val > num->max_val) {
        halt(HALT_GUI_COMPO_NUMBER_VALUE);
    }

    if (num->value != val) {
        num->value = val;
        compo_number_update(num);
    }
}

/**
 * @brief 设置坐标
          注意：该设置默认的坐标是以中心点作为参考点
 * @param[in] num : 数字指针
 * @param[in] x : x轴坐标
 * @param[in] y : y轴坐标
 **/
void compo_number_set_pos(compo_number_t *num, s16 x, s16 y)
{
    num->x = x;
    num->y = y;
    compo_number_update(num);
}

/**
 * @brief 设置透明度
 * @param[in] num : 数字指针
 * @param[in] alpha : 透明度
 **/
void compo_number_set_alpha(compo_number_t *num, u8 alpha)
{
    int i;
    for (i=0; i<num->num_cnt; i++) {
        widget_set_alpha(num->img_num[i], alpha);
    }
}

/**
 * @brief 设置字间距
 * @param[in] num : 数字指针
 * @param[in] margin : 字间距
 **/
void compo_number_set_margin(compo_number_t *num, int margin)
{
    num->x_margin = margin;
    compo_number_update(num);
}

/**
 * @brief 设置数字高位是否填0
 * @param[in] num : 数字指针
 * @param[in] flag : true  高位补0
                     false 高位不补0
 **/
void compo_number_set_zfill(compo_number_t *num, bool flag)
{
    num->flag_zfill = flag;
    compo_number_update(num);
}

/**
 * @brief 设置数字框是否可见
 * @param[in] num : 数字指针
 * @param[in] visible : true  可见
                        false 不可见
 **/
void compo_number_set_visible(compo_number_t *num, bool visible)
{
    if (num->visible != visible) {
        num->visible = visible;
        compo_number_update(num);
    }
}

/**
 * @brief 获取数字框位置和大小
 * @param[in] num : 数字指针
 * @return 返回数字框位置和大小
 **/
rect_t compo_number_get_location(compo_number_t *num)
{
    rect_t rect = {0};
    rect.x = num->x;
    rect.y = num->y;
    rect.wid = num->num_wid * num->num_cnt + num->x_margin * (num->num_cnt - 1);
    rect.hei = num->num_hei;
    return rect;
}
