#ifndef __IO_DEF_H
#define __IO_DEF_H


#include "global.h"
#include "config.h"
#include "sfr.h"

#endif //__IO_DEF_H
