#ifndef _BSP_BT_H
#define _BSP_BT_H

#include "pbap.h"

//标准HID键
#define HID_KEY_ENTER       0x28

//自定义HID键
#define HID_KEY_VOL_DOWN    0x00EA
#define HID_KEY_VOL_UP      0x00E9
#define HID_KEY_IOS_HOME    0x0040      //ios home
#define HID_KEY_IOS_POWER   0x0030      //ios 锁屏
#define HID_KEY_IOS_LAYOUT  0x01AE      //ios Keyboard Layout

typedef enum
{
    IMG_POINT_UP = 0,           //上滑
    IMG_POINT_DOWN,             //下滑
    IMG_POINT_LEFT,             //左滑
    IMG_POINT_RIGHT,            //右滑
    IMG_POINT_DD,
}img_point_type;

typedef struct{
    u16 warning_status;
    u8 disp_status;
    u8 hid_menu_flag;
    u8 hid_discon_flag;
    u8 ring_stop;
    u8 bt_is_inited;
    u8 rec_pause    : 1;
    u8 need_pairing : 1;
} bsp_bt_t;
extern bsp_bt_t bt_cb;

void bsp_bt_init(void);
void bsp_bt_close(void);
void bsp_bt_vol_change(void);
void bsp_bt_hid_photo(void);
bool bsp_bt_pwrkey5s_check(void);
void bsp_bt_pwrkey5s_clr(void);
void bsp_bt_hid_tog_conn(void);
void bsp_bt_hid_screen_left(void);
void bsp_bt_hid_screen_right(void);
void bt_name_suffix_set(void);
uint bsp_bt_get_hfp_vol(uint hfp_vol);
u16 bsp_bt_chkclr_warning(u16 bits);
void bsp_bt_switch_voice_lang(void);
void bsp_bt_warning(void);
void bsp_bt_status(void);
void bt_spp_cmd_process(u8 *ptr, u16 size, u8 type);

void bt_music_rec_init(void);
bool bt_rec_status_process(void);
void bt_music_rec_continue(void);
void bt_sco_rec_init(void);

void bt_redial_init(void);
void bt_redial_reset(uint8_t index);
void bt_update_redial_number(uint8_t index, char *buf, u32 len);
const char *bt_get_last_call_number(uint8_t index);

void bt_call_volume_change(u8 up_flag);
void bt_volume_up(void);
void bt_volume_down(void);

//hid
void user_finger_down(void);                    // 向下滑
void user_finger_up(void);                      //向上滑
void user_finger_p(void);                       //单击
void user_finger_pp(void);                      //双击
void bt_hid_point_user(img_point_type type);    //视频APP，翻页等功能, img_point_type 选择动作

#endif //_BSP_BT_H
