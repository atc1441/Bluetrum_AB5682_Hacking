#include "include.h"
#include "api.h"


#if !BT_A2DP_RECON_EN
void a2dp_recon_hook(void)
{
}
#endif

uint a2dp_get_vol(void)
{
    uint vol;

    vol = ((u32)sys_cb.vol * 1280L /VOL_MAX) /10;
    if(vol > 0x7f) {
        vol = 0x7f;
    }

    return vol;
}

