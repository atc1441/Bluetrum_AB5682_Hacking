#include "include.h"
#include "api.h"


#define BT_PROFILE          (PROF_A2DP*BT_A2DP_EN) | (PROF_HFP*BT_HFP_EN) | (PROF_SPP*BT_SPP_EN) | (PROF_HID*BT_HID_EN) | (PROF_HSP*BT_HSP_EN)
#define BT_CODEC            (CODEC_SBC) | (CODEC_MSBC * BT_HFP_MSBC_EN) | (CODEC_PLC * BT_PLC_EN)
#define HFP_FEATURE         (HFP_BAT_REPORT*BT_HFP_BAT_REPORT_EN) | (HFP_INBAND_RING_RONE*BT_HFP_INBAND_RING_EN) | (HFP_CALL_PRIVATE*BT_HFP_CALL_PRIVATE_FORCE_EN) | (HFP_RING_NUMBER_EN*BT_HFP_RING_NUMBER_EN)
#define A2DP_FEATURE        (A2DP_VOL_CTRL*BT_A2DP_VOL_CTRL_EN) | (A2DP_RESTORE_PLAYING) | (A2DP_AVDTP_DELAY_REPORT*BT_AVDTP_DELAY_REPORT_EN)


///baseband
uint8_t cfg_bt_rf_def_txpwr         = 0;        //降低预置参数RF发射功率，单位1dbm
uint8_t cfg_bt_page_inq_txpwr       = 0;        //降低回连和搜索RF发射功率，单位2dbm
uint8_t cfg_bt_sniff_clk_sel        = 2;		//2:31.25KHz 晶振, 3:31.25KHz RC

///stack
uint8_t cfg_bt_work_mode            = WORK_MODE;
uint8_t cfg_bt_max_acl_link         = BT_2ACL_EN+1;

bool cfg_bt_dual_mode               = BT_DUAL_MODE_EN;
bool cfg_bt_scan_ctrl_mode          = BT_DISCOVER_CTRL_EN;
bool cfg_bt_simple_pair_mode        = BT_SIMPLE_PAIR_EN;

uint16_t cfg_bt_support_profile     = BT_PROFILE;
uint16_t cfg_bt_support_codec       = BT_CODEC;

uint8_t cfg_bt_a2dp_feature         = A2DP_FEATURE;
uint8_t cfg_bt_hfp_feature          = HFP_FEATURE;
uint8_t cfg_bt_hid_type             = BT_HID_TYPE;

uint16_t cfg_bt_def_connect_times   = BT_POWER_UP_RECONNECT_TIMES;      //默认回连重试次数
uint16_t cfg_bt_sup_to_connect_times = BT_TIME_OUT_RECONNECT_TIMES;     //超时断线回连重试次数

bool cfg_bt_voip_reject_en          = BT_VOIP_REJECT_EN;

//自定义蓝牙类别图标，根据需要选择
u32 bt_get_class_of_device(void)
{
#if BT_HID_TYPE == 2
    return 0x0025c0;    //GamePad           - 游戏手柄
#else
//    return 0x002540;    //Keyboard          - 键盘图标，Android带显示电量，IOS不带电量显示。全部IOS均可连接HID拍照。
//    return 0x240418;    //HeadPhone         - 耳机图标，Android和IOS均带电量显示。
//    return 0x240404;    //WearableHeadset   - 耳机图标，Android和IOS均带电量显示。（默认使用）
    return 0x240704;    //WearablePager     - 手表图标
#endif
}

//PIN配对码（最多16个字符），默认"0000"
//#if !BT_SIMPLE_PAIR_EN
//const char *bt_get_pin_code(void)
//{
//    return "0000";
//}
//#endif

//回连间隔（N+3000）mS，间隔越大，下一次回连越慢，更容易被其他手机搜索连接，N应大于等于2000
//u32 bt_get_conn_fail_delay(void)
//{
//    return 2000;
//}

//是否需要一直回连手机
//bool bt_is_always_reconn(void)
//{
//    return false;
//}

//是否支持android & ios播放暂停快速切换，需要时定义该函数
//注意：打开后ios播放微信小视频会无声，播放器听音乐不影响
//      部分android4.0及之前系统打开多个播放器可能有兼容问题
//bool bt_force_super_fast_status(void)
//{
//    return true;
//}

//是否支持ios播放暂停快速切换，需要时定义该函数，蓝牙后台建议打开
//注意：打开后ios播放微信小视频会无声，播放器听音乐不影响
//bool bt_support_ios_fast_status(void)
//{
//    return true;
//}

//const bool cfg_bt_sniff_mode_dis   = true;  //true: 关闭蓝牙sniff功能

const char *bt_get_local_name(void)
{
    return xcfg_cb.bt_name;
}

void bt_get_local_bd_addr(u8 *addr)
{
#if LE_SM_SC_EN
    memcpy(addr, xcfg_cb.bt_addr, 6);
    if (!app_phone_type_get()) {
        addr[5] ^= 0x55;
    }
#elif BT_LOCAL_ADDR
    param_random_key_read(&addr[2]);
    addr[0] = 0x41;
    addr[1] = 0x42;
#else
    memcpy(addr, xcfg_cb.bt_addr, 6);
#endif
}

u32 bt_get_rand_seed(void)
{
    return sys_cb.rand_seed;
}

void bt_get_link_info(void *buf, u16 addr, u16 size)
{
    //printf("bt_read: %04x,%04x, %08lx\n", addr, size, BT_CM_PAGE(addr));
    cm_read(buf, BT_CM_PAGE(addr), size);
    //print_r(buf, size);
}

void bt_put_link_info(void *buf, u16 addr, u16 size)
{
    //printf("bt_write: %04x,%04x, %08lx\n", addr, size, BT_CM_PAGE(addr));
    //print_r(buf, size);
    cm_write(buf, BT_CM_PAGE(addr), size);
}

void bt_get_ext_link_info(void *buf, u16 addr, u16 size)
{
    //printf("bt_read: %04x,%04x, %08lx\n", addr, size, BT_CM_PAGE(addr));
    cm_read(buf, EXT_CM_PAGE(addr), size);
    //print_r(buf, size);
}

void bt_put_ext_link_info(void *buf, u16 addr, u16 size)
{
    //printf("bt_write: %04x,%04x, %08lx\n", addr, size, BT_CM_PAGE(addr));
    //print_r(buf, size);
    cm_write(buf, EXT_CM_PAGE(addr), size);
}

void bt_sync_link_info(void)
{
    cm_sync();
}

void bt_call_volume_change(u8 up_flag)
{
    if ((up_flag) && (sys_cb.hfp_vol < 15)) {
        sys_cb.hfp_vol++;
    } else if ((!up_flag) && (sys_cb.hfp_vol > 0)) {
        sys_cb.hfp_vol--;
    } else {
        return;
    }
    bt_ctrl_msg(BT_CTL_HFP_SPK_GAIN);
    bsp_change_volume(bsp_bt_get_hfp_vol(sys_cb.hfp_vol));
    printf("hfp vol: %d\n", sys_cb.hfp_vol);
}

void bt_volume_up(void)
{
    if (sys_cb.incall_flag) {
        bt_call_volume_change(1);
    } else {
        bsp_set_volume(bsp_volume_inc(sys_cb.vol));
        bsp_bt_vol_change();
        printf("volume: %d\n", sys_cb.vol);
    }
}

void bt_volume_down(void)
{
    if (sys_cb.incall_flag) {
        bt_call_volume_change(0);
    } else {
        bsp_set_volume(bsp_volume_dec(sys_cb.vol));
        bsp_bt_vol_change();
        printf("volume: %d\n", sys_cb.vol);
    }
}

#if BT_FCC_TEST_EN
ALIGNED(4)
u8 huart_buffer[256];

void huart_init(void)
{
#if LE_BQB_RF_EN
    huart_init_do(HUART_TR_PB1, HUART_TR_PB3, 9600, huart_buffer, 256);
#else
    huart_init_do(HUART_TR_PB3, HUART_TR_PB3, 1500000, huart_buffer, 256);
#endif
}
#endif


