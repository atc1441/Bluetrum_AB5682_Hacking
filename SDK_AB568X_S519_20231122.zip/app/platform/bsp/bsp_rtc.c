#include "include.h"

void rtc_clock_init(void)
{
    tm_t tm;
    tm.year = 2023;
    tm.mon  = 8;
    tm.day = 18;
    tm.hour = 10;
    tm.min  = 8;
    tm.sec  = 36;
    //tm.weekday = get_weekday(tm.year, tm.mon, tm.day);
    RTCCNT = tm_to_time(tm);
}

//多少秒后闹钟响
AT(.text.rtc)
void rtc_set_alarm_relative_time(u32 nsec)
{
    tm_t rtc_tm;
    rtc_tm = time_to_tm(RTCCNT);                //更新时间结构体
    RTCALM = tm_to_time(rtc_tm) + nsec;         //设置闹钟相对于当前时间n秒后
}

//设置多少秒后闹钟唤醒
AT(.text.rtc)
void rtc_set_alarm_wakeup(u32 nsec)
{
    uint rtccon3 = RTCCON3;

    RTCCPND = BIT(17);                          //clear RTC alarm pending
    RTCCON9 = BIT(0);                           //clear alarm pending
    rtc_set_alarm_relative_time(nsec);

    rtccon3 |= BIT(8);                          //RTC alarm wakeup enable
    RTCCON3 = rtccon3;
}

/*
 * 设置RTC时间
 * 输入：tm结构体指针
*/
void rtc_clock_set(tm_t rtc_tm)
{
    RTCCNT = tm_to_time(rtc_tm);
}


/*
 * 获取RTC时间
 * 输入: 空
   输出: rtc_tm结构体
*/
tm_t rtc_clock_get(void)
{
    return time_to_tm(RTCCNT);
}


