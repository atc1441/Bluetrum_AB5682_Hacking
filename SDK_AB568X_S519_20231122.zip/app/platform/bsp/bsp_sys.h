#ifndef _BSP_SYS_H
#define _BSP_SYS_H

#define VOL_MAX                         xcfg_cb.vol_max   //最大音量级数

//控制位汇总
#define SYS_CTL_BT                      0               //蓝牙开关
#define SYS_CTL_CALL_RING               1               //来电铃声
#define SYS_CTL_ACLOCK_MON              2               //闹钟设置星期一
#define SYS_CTL_ACLOCK_TUE              3               //闹钟设置星期二
#define SYS_CTL_ACLOCK_WED              4               //闹钟设置星期三
#define SYS_CTL_ACLOCK_THU              5               //闹钟设置星期四
#define SYS_CTL_ACLOCK_FRI              6               //闹钟设置星期五
#define SYS_CTL_ACLOCK_SAT              7               //闹钟设置星期六
#define SYS_CTL_ACLOCK_SUN              8               //闹钟设置星期日
#define SYS_CTL_ACLOCK1_ON              9               //闹钟1开关
#define SYS_CTL_ACLOCK2_ON              10              //闹钟2开关
#define SYS_CTL_ACLOCK3_ON              11              //闹钟3开关

#define SYS_CTL_TOTAL_BITS              256
#define SYS_CTL_TOTAL_BYTES             ((SYS_CTL_TOTAL_BITS + 7) / 8)      //系统控制位

//功能
#define ALARM_CLOCK_NUM_MAX             3               //闹钟最大数量，需要同步修改列表item
#define STOPWATCH_REC_NUM_MAX           10              //秒表最大数量，需要同步修改列表item

typedef struct {
    //控制位
    u8 ctl_bits[SYS_CTL_TOTAL_BYTES];   //控制位汇总

    //TE控制相关
    bool tft_bglight_kick;      //背光控制
    u8   tft_bglight_duty;      //背光pwm占空比
    u8   tft_bglight_last_duty; //背光pwm上一次占空比
    bool tft_bglight_frist_set;
    bool te_mode;
    bool te_mode_next;
    u8 te_bglight_cnt;          //在收到需要打开背光控制时，推完第一帧数据后延时打开背光
    u8 despi_baud;
    u8 despi_baud1;
    u8 despi_baud2;
    u8  play_mode;
    u8  vol;
    u8  hfp_vol;
    u8  eq_mode;
    u8  cur_dev;
    u8  lang_id;
    u8  lpwr_warning_cnt;
    u8  lpwr_warning_times;     //播报低电次数，0xff表示一直播
    u8  vbat_nor_cnt;
    s8  gain_offset;            //用于动态修改系统音量表
    u8  hfp2sys_mul;            //系统音量与HFP音量倍数，手机HFP音量只有16级。
    u8  lpwr_cnt;               //低电计数
#if DAC_DNR_EN
    u8  dnr_sta;                //动态降噪状态
#endif
    u16 vbat;                   //当前电压值(mv)
    u16 vbat_percent;           //电量百分比
    u16 kh_vol_msg;
    u32 sleep_time;             //配置工具配置系统息屏时间
    u32 pwroff_time;            //配置工具配置自动关机时间
    u32 sleep_delay;            //系统休眠时间, 深度睡眠计时
    u32 guioff_delay;           //系统息屏时间, 浅度睡眠计时
    u32 pwroff_delay;
    u32 sleep_wakeup_time;
    u32 sleep_counter;
    u32 ms_ticks;               //ms为单位
    u32 rand_seed;

volatile u8  cm_times;
volatile u8  loudspeaker_mute;  //功放MUTE标志
volatile u8  charge_sta;        //0:充电关闭， 1：充电开启， 2：充满
volatile u8  charge_bled_flag;  //charge充满蓝灯常亮标志
volatile u8  ch_bled_cnt;       //charge充满蓝灯亮时间计数
volatile u8  poweron_flag;      //pwrkey开机标志
volatile u8  pwrdwn_hw_flag;    //模拟硬开关，关机标志
volatile u8  incall_flag;
volatile u8  gui_sleep_sta;
volatile u8  gui_need_wakeup;

    ///位变量不要用于需要在中断改值的变量。 请谨慎使用位变量，尽量少定义位变量。
    u8  rtc_first_pwron  : 1,   //RTC是否第一次上电
        mute             : 1,   //系统MUTE控制标志
        cm_factory       : 1,   //是否第一次FLASH上电
        cm_vol_change    : 1,   //音量级数是否需要更新到FLASH
        port2led_en      : 1,   //1个IO推两个灯
        voice_evt_brk_en : 1;   //播放提示音时，U盘、SD卡、LINEIN等插入事件是否立即响应.

    u8  sleep_en         : 1,   //用于控制是否进入sleep
		lowbat_flag      : 1,
        bt_reconn_flag   : 1;   //回连失败时候发起一键双连标志

#if BT_MAP_EN
    u8 map_retry;
#endif

    //运动
    u8 sport_idx;                                   //运动列表编号
    //设置
    u8 set_idx;                                     //设置菜单编号
	//调节亮度
    u8 light_level;                                 //亮度等级
    //调节音量
    u8 volume_level;                                //音量等级
    //定时器
    u32 timer_total_sec;                            //定时器时间总计 （单位：秒）
    //密码锁
    u8 password_cnt;                                //密码有效长度
    u8 password_value[4];                           //密码有效值
    u8 password_change;                             //改密码锁
    //秒表
    u32 stopwatch_total_msec;                       //当前秒表时间总计 （单位：毫秒）
    u32 stopwatch_rec_view[STOPWATCH_REC_NUM_MAX];  //秒表最大记录
    u8 stopwatch_rec_cnt;                           //秒表记录总数
    //日期
    u16 year;
    u8  mon;
    u8  day;
    //闹钟
    u32 alarm_total_sec[ALARM_CLOCK_NUM_MAX];       //记录每个闹钟总秒数
    u8 alarm_week_sel[ALARM_CLOCK_NUM_MAX];         //记录每个闹钟的星期选择
    u8 alarm_idx;                                   //当前闹钟 idx:0,1,2
    u8 alarm_enable_cnt;                            //闹钟使能的个数 0:无闹钟
    u8 alarm_enable_sel;                            //使能闹钟选择
    //呼吸训练
    u32 breathe_duration;                           //训练时间 ms
    u8 breathe_mode;                                //训练模式 0:2,慢中快
    u8 dialplate_index;                             //表盘编号
} sys_cb_t;
extern sys_cb_t sys_cb;
extern volatile int micl2gnd_flag;
extern volatile u32 ticks_50ms;

typedef void (*isr_t)(void);
isr_t register_isr(int vector, isr_t isr);

void bsp_sys_init(void);
u8 bsp_sys_get_ctlbit(uint n);                      //获取系统控制位
void bsp_sys_set_ctlbit(uint n, u8 v);              //设置系统控制位
void bsp_sys_reverse_ctlbit(uint n);                //反转系统控制位
void bsp_sys_tm_update(void);           //更新tm结构体
void bsp_update_init(void);
void timer1_irq_init(void);
void bsp_sys_mute(void);
void bsp_sys_unmute(void);
void bsp_clr_mute_sta(void);
void bsp_loudspeaker_mute(void);
void bsp_loudspeaker_unmute(void);
void uart0_mapping_sel(void);
void linein_detect(void);
bool linein_micl_is_online(void);
void get_usb_chk_sta_convert(void);
void sd_soft_cmd_detect(u32 check_ms);
void print_info(void);

void huart_module_init(void);
void huart_wait_tx_finish(void);
void huart_putbuf(void *buf, u32 len);
#endif // _BSP_SYS_H

