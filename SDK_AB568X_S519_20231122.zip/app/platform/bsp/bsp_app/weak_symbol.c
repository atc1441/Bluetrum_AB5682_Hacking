#include "include.h"

WEAK void app_phone_type_set(u8 type)
{

}

WEAK u8 app_phone_type_get(void)
{
    return 0;
}

WEAK uint8_t app_distance_unit_get(void)
{
    return 0;
}
