#ifndef _APP_PLATFROM_H_
#define _APP_PLATFROM_H_

void app_platform_init(void);                                         //app平台相关初始化
void app_platform_process(void);                                      //app平台进程

#endif  //_APP_PLATFROM_H_
