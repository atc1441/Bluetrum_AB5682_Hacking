#include "include.h"
#include "ab_common.h"

#if (USE_APP_TYPE == USE_AB_APP)


const char * const appleAppID_table[] = {
    [ANCS_TYPE_NULL]                = " ",
    [ANCS_TYPE_INCOMINGCALL]        = "com.apple.mobilephone",        //wakeUpAppID 01, Incoming Call (Apple)
    [ANCS_TYPE_MISSEDCALL]          = "com.apple.mobilephone",        //wakeUpAppID 02, Missed Call (Apple)
    [ANCS_TYPE_MESSAGES]            = "com.apple.MobileSMS",          //wakeUpAppID 03, Messages (Apple)
    [ANCS_TYPE_MAIL]                = "com.apple.mobilemail",         //WakeUpAppID 04 , Mail (Apple)
    [ANCS_TYPE_CALENDAR]            = "com.apple.mobilecal",          //WakeUpAppID 05 , Calendar (Apple)
    [ANCS_TYPE_FACETIME]            = "com.apple.facetime",           //WakeUpAppID 06 , FaceTime (Apple)
    [ANCS_TYPE_QQ]                  = "com.tencent.mqq",              //WakeUpAppID 07 , QQ
    [ANCS_TYPE_SKYPE]               = "com.skype.skype",              //WakeUpAppID 08 , Skype
    [ANCS_TYPE_WECHAT]              = "com.tencent.xin",              //WakeUpAppID 09 , WeChat
    [ANCS_TYPE_WHATSAPP]            = "com.whatsapp.WhatsApp",        //WakeUpAppID 10 , WhatsApp
    [ANCS_TYPE_GMAIL]               = "com.google.Gmail",             //WakeUpAppID 11 , Gmail
    [ANCS_TYPE_HANGOUT]             = "com.google.hangouts",          //WakeUpAppID 12 , Hangout
    [ANCS_TYPE_INBOX]               = "com.google.inbox",             //WakeUpAppID 13 , Inbox
    [ANCS_TYPE_LINE]                = "jp.naver.line",                //WakeUpAppID 14 , Line
    [ANCS_TYPE_TWITTER]             = "com.atebits.Tweetie2",         //WakeUpAppID 15 , Twitter
    [ANCS_TYPE_FACEBOOK]            = "com.facebook.Facebook",        //WakeUpAppID 16 , Facebook
    [ANCS_TYPE_FACEBOOK_MESSENGER]  = "com.facebook.Messenger",       //WakeUpAppID 17 , Facebook Messenger
    [ANCS_TYPE_INSTAGRAM]           = "com.burbn.instagram",          //WakeUpAppID 18 , Instagram
    [ANCS_TYPE_WEIBO]               = "com.sina.weibo",               //WakeUpAppID 19 , WeiBo
    [ANCS_TYPE_KAKAOTALK]           = "com.iwilab.KakaoTaik",         //WakeUpAppID 20 , Kakaotalk
    [ANCS_TYPE_FACEBOOK_PAGE_MANAGER] = " ",                          //WakeUpAppID 21 , Facebook page manager
    [ANCS_TYPE_VIBER]               = "com.viber",                    //WakeUpAppID 22 , Viber
    [ANCS_TYPE_VKCLINET]            = "com.vk.vkclient",              //WakeUpAppID 23 , vkclient
    [ANCS_TYPE_TELEGRAM]            = "ph.telegra.Telegraph",         //WakeUpAppID 24 , Telegram
};

u32 timestamp_get(void)
{
    u32 timestamp = RTCCNT - (app_data.time_zone - 12)*3600;
    return timestamp;
}

void timestamp_data_save(timestamp_data_t *buf, u16 value)
{
    u32 rtccnt = timestamp_get();

    buf->timestamp = rtccnt;
    buf->value = value;
}

bool clock_in_time(tm_t *nowtime, uint8_t begin_hour, uint8_t begin_minute, uint8_t end_hour, uint8_t end_minute)
{
    bool res = false;
    uint16_t now = 0, begin = 0, end = 0;
    now   = (nowtime->hour) * 60 + nowtime->min;
    begin = begin_hour * 60 + begin_minute;
    end   = end_hour *60 + end_minute;

    if (begin != end) {
        if (begin > end) {
            res = (now >= begin && now < 1440) || (now < end);
        } else {
            res = (now >= begin && now < end);
        }
    } else if (begin == 0 && end == 0) {	//00:00~00:00
        res = true;
    } else {
        res = false;
    }
    return res;
}

bool clock_in_time_range(period_t *period)
{
//    printf("clock check: %d:%d - %d:%d\n", period->start_hour, period->start_minute, period->end_hour, period->end_minute);
    return clock_in_time(&compo_cb.tm, period->start_hour, period->start_minute, period->end_hour, period->end_minute);
}

void period_set(period_t *period, uint8_t begin_hour, uint8_t begin_minute, uint8_t end_hour, uint8_t end_minute)
{
    period->start_hour = begin_hour;
    period->start_minute = begin_minute;
    period->end_hour = end_hour;
    period->end_minute = end_minute;
}


u16 check_sum_get(u8 *buf, u16 len)
{
    u16 data_sum = 0;
    for (u16 i = 0; i < len; i++) {
        data_sum += buf[i];
    }
//    printf("cal data_sum[%x] len[%d]\n", data_sum, len);
    return data_sum;
}
#endif  //(USE_APP_TYPE == USE_AB_APP)
