#include "include.h"

#define FS_CRC_SEED         0xffff

static uint8_t mp3_res_playing;

uint calc_crc(void *buf, uint len, uint seed);
void mp3_res_play_kick(u32 addr, u32 len);
void wav_res_play_kick(u32 addr, u32 len);
void wav_res_dec_process(void);
bool wav_res_is_play(void);
bool wav_res_stop(void);
void mp3_res_play_exit(void);
void set_mp3_res_sta(uint8_t sta);
uint8_t get_mp3_res_sta(void);
void mp3_res_process(void);

void set_mp3_res_sta(uint8_t sta)
{
    mp3_res_playing = sta;
}

uint8_t get_mp3_res_sta(void)
{
    return mp3_res_playing;
}

void mp3_res_process(void)
{
    if(get_mp3_res_sta()){
        if(get_music_dec_sta() == MUSIC_STOP){
            set_mp3_res_sta(false);
            printf("mp3 ring stop\n");
            music_control(MUSIC_MSG_STOP);
            bsp_change_volume(sys_cb.vol);
            if (music_set_eq_is_done()) {
                music_set_eq_by_num(sys_cb.eq_mode); // 恢复 EQ
            }
            mp3_res_play_exit();
            if (sys_cb.mute) {
                bsp_loudspeaker_mute();
            }
            #if DAC_DNR_EN
                dac_dnr_set_sta(sta);
            #endif
        }

    }
}

void mp3_res_play_do(u32 addr, u32 len, bool sync)
{
    printf("mp3 ring\n");
//    u16 msg;
//    u8 mute_bak;
//    printf("%s: addr: %x, len: %x\n", __func__, addr, len);
    if (len == 0) {
        return;
    }

#if DAC_DNR_EN
    u8 sta = dac_dnr_get_sta();
    dac_dnr_set_sta(0);
#endif

//    mute_bak = sys_cb.mute;
    if (sys_cb.mute) {
        bsp_loudspeaker_unmute();
    }
    if(get_music_dec_sta() != MUSIC_STOP) { //避免来电响铃/报号未完成，影响get_music_dec_sta()状态
        music_control(MUSIC_MSG_STOP);
    }
    bsp_change_volume(WARNING_VOLUME);
    if (music_set_eq_is_done()) {
        music_set_eq_by_num(0); // EQ 设置为 normal
    }

    mp3_res_play_kick(addr, len);
    set_mp3_res_sta(true);
//     while (get_music_dec_sta() != MUSIC_STOP) {
//         WDT_CLR();
//         msg = msg_dequeue();
//         if (sys_cb.voice_evt_brk_en) {
//             if (((msg == EVT_SD_INSERT) || (msg == EVT_UDISK_INSERT)) && (func_cb.sta != FUNC_MUSIC)) {
//                 func_message(msg);
//                 break;
//             }
//         }
// 		if ((PWRKEY_2_HW_PWRON) && (sys_cb.pwrdwn_hw_flag)) {//PWRKEY模拟硬件开关机快速关机
//             break;
// 		}

//         if ((msg != NO_MSG) && ((msg & KEY_TYPE_MASK) != KEY_HOLD)) {
//             msg_enqueue(msg);       //还原未处理的消息
//         }
//     }
//     music_control(MUSIC_MSG_STOP);
//     bsp_change_volume(sys_cb.vol);
//     if (music_set_eq_is_done()) {
//         music_set_eq_by_num(sys_cb.eq_mode); // 恢复 EQ
//     }
//     mp3_res_play_exit();
//     sys_cb.mute = mute_bak;
//     if (sys_cb.mute) {
//         bsp_loudspeaker_mute();
//     }
// #if DAC_DNR_EN
//     dac_dnr_set_sta(sta);
// #endif
}

void mp3_res_play(u32 addr, u32 len)
{
    mp3_res_play_do(addr, len, 0);
}

