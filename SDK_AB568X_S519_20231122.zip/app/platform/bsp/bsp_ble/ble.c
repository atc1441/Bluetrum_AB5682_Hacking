#include "include.h"
#include "bsp_ble.h"


#if LE_EN

const bool cfg_ble_security_en = LE_PAIR_EN;
bool cfg_ble_sm_sc_en          = LE_SM_SC_EN;
bool cfg_bt_ble_adv            = LE_ADV_POWERON_EN;

static ble_gatt_characteristic_cb_info_t *characteristic_cb_info[LE_ATT_NUM] AT(.ble_cache.att);
static uint8_t  gatts_profile_table[LE_ATT_NUM * 10] AT(.ble_cache.att);

void bt_get_local_bd_addr(u8 *addr);

//上电默认BLE广播的间隔
uint16_t ble_get_adv_pwron_interval(void)
{
    return 0x60;        //625us * 90 = 60ms
}

//可重定义该函数修改ble地址类型
u8 ble_get_local_addr_mode(void)
{
#if LE_SM_SC_EN
    return GAP_RANDOM_ADDRESS_TYPE_OFF;
#else
    return GAP_RANDOM_ADDRESS_TYPE_STATIC;
#endif
}

void ble_disconnect_callback(uint8_t *packet)
{
    printf("--->ble_disconnect_callback:%x\n", packet[5]);
    ble_app_disconnect_callback();
}

void ble_connect_callback(void)
{
    printf("--->ble_connect_callback\n");
    ble_app_connect_callback();
}

//att_exchange_mtu_finish_callback(蓝牙线程请勿阻塞)
void ble_att_exchange_mtu_finish_callback(uint16_t mtu)
{

}

void ble_init_att(void)
{
    ble_gatts_init(gatts_profile_table, sizeof(gatts_profile_table),
                    characteristic_cb_info,
                    LE_ATT_NUM);
    ble_app_init();
}

//可重定义该函数修改ble地址
void ble_get_local_bd_addr(u8 *addr)
{
    memcpy(addr, xcfg_cb.bt_addr, 6);
#if !LE_SM_SC_EN
    addr[5] ^= 0x55;
#endif
}

#if LE_SM_SC_EN

//发起一键双连
void ble_bt_connect(void)
{
    ble_send_sm_req();
}

void bsp_change_bt_mac(bool flag)
{
	cfg_bt_scan_ctrl_mode = true;

    bt_reset_addr();
    delay_5ms(10);
    bt_set_scan(0, 0);
    delay_5ms(10);
    bt_set_scan(1, 1);
}

void app_once_connect(u8 ble_app_ios)
{
    app_phone_type_set(ble_app_ios);
    bsp_change_bt_mac(ble_app_ios);

    if (ble_app_ios) {                      //IOS
        if (bt_nor_get_link_info(NULL)) {   //如果存在配对信息
            if (!bt_is_connected()) {
                sys_cb.bt_reconn_flag = true;
                bt_connect(0);
            }
        } else {
            ble_bt_connect();               //一键双联
        }
    }
}

void ble_get_link_info(void *buf, u16 addr, u16 size)
{
    //printf("bt_read: %04x,%04x, %08lx\n", addr, size, BLE_CM_PAGE(addr));

    cm_read(buf, BLE_CM_PAGE(addr), size);

    //print_r(buf, size);
}

void ble_put_link_info(void *buf, u16 addr, u16 size)
{
    //printf("bt_write: %04x,%04x, %08lx\n", addr, size, BLE_CM_PAGE(addr));
    //print_r(buf, size);

    cm_write(buf, BLE_CM_PAGE(addr), size);
}

void ble_sync_link_info(void)
{
    cm_sync();
}
#endif


#endif  // LE_EN
