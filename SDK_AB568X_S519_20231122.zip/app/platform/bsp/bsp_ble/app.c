#include "include.h"
#include "app.h"

void ble_app_init(void)
{
#if LE_AB_LINK_APP_EN
    ble_app_ab_link_init();
#endif

#if USE_APP_TYPE
    ble_app_watch_init();
#endif
}

void ble_app_process(void)
{
#if LE_AB_LINK_APP_EN
    ble_app_ab_link_process();
#endif

#if USE_APP_TYPE
    ble_app_watch_process();
#endif
}

bool ble_app_need_wakeup(void)
{
    bool ret = false;

#if LE_AB_LINK_APP_EN
    ret |= ble_app_ab_link_need_wakeup();
#endif

#if USE_APP_TYPE
    ret |= ble_app_watch_need_wakeup();
#endif

    return ret;
}

void ble_app_disconnect_callback(void)
{
}

void ble_app_connect_callback(void)
{
#if USE_APP_TYPE
    ble_app_watch_connect_callback();
#endif
}
