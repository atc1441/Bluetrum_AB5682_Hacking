#ifndef __BLE_H
#define __BLE_H

void ble_get_local_bd_addr(u8 *addr);
#endif  //__BLE_H
