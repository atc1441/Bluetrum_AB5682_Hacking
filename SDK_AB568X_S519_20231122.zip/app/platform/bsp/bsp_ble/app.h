#ifndef __APP_H
#define __APP_H

#include "app_ab_link.h"
#include "app_watch.h"
#include "bt_fota.h"

void ble_app_init(void);
void ble_app_process(void);
bool ble_app_need_wakeup(void);
void ble_app_connect_callback(void);
void ble_app_disconnect_callback(void);
#endif
