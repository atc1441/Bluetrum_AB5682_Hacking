#ifndef _BSP_BLE_H
#define _BSP_BLE_H

#include "app.h"
#include "ble.h"

void ble_bt_connect(void);

#endif
