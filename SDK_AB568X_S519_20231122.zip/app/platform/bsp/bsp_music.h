#ifndef _BSP_MUSIC_H
#define _BSP_MUSIC_H

enum {
    NORMAL_MODE,
    SINGLE_MODE,
    FLODER_MODE,
    RANDOM_MODE,
};

bool pf_scan_music(u8 new_dev);
void music_playmode_next(void);
void mp3_res_play(u32 addr, u32 len);
void mp3_res_process(void);

#endif //_BSP_MUSIC_H
