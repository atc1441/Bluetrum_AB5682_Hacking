#ifndef _API_MEM_H
#define _API_MEM_H

void func_heap_init(void *heap, u32 size);          //initial func heap
void *func_zalloc(u32 size);                        //malloc & memset 0
void func_free(void *mem_ptr);                      //Free the memory area pointed by mem_ptr
bool func_mem_is_free(void* mem_ptr);               //Check if current pointer is free or not
bool func_heap_is_empty(void);                      //Check if current heap is empty or not
u32 func_heap_get_free_size(void);                  //Get free size of the current heap

#endif // _API_MEM_H
