/**********************************************************************
*
*   strong_symbol.c
*   定义库里面部分WEAK函数的Strong函数，动态关闭库代码
***********************************************************************/
#include "include.h"

int mpa_encode_frame(void) {return 0;}

bool sbc_encode_init(u8 spr, u8 nch){return false;}
u16 sbc_encode_frame(u8 *buf, u16 len) {return 0;}
void sbc_encode_process(void){}
void sbc_encode_exit(void){}

void adpcm_encode_process(void){}

int wav_dec_init(void){return 0;}
bool wav_dec_frame(void){return false;}
void lock_code_wavdec(void){}

int wma_dec_init(void){return 0;}
bool wma_dec_frame(void){return false;}
void lock_code_wmadec(void){}

int ape_dec_init(void){return 0;}
bool ape_dec_frame(void){return false;}
void lock_code_apedec(void){}

int flac_dec_init(void){return 0;}
bool flac_dec_frame(void){return false;}
void lock_code_flacdec(void){}

int sbcio_dec_init(void){return 0;}
bool sbcio_dec_frame(void){return false;}

void bt_music_rec_start(void) {}
void bt_music_rec_stop(void) {}

u32 fs_get_file_size(void){return 0;}
void fs_save_file_info(unsigned char *buf){}
void fs_load_file_info(unsigned char *buf){}

#if !BT_FCC_TEST_EN
void huart_init(void)
{
}
AT(.bcom_text.stack.uart_isr)
bool bt_uart_isr(void) {
    return false;
}
#endif

#if !LE_EN
AT(.bcom_text.bb.leisr)
void ble_isr(void) {}
AT(.bcom_text.bb.leisr)
void ble_evt_instant(void *evt, uint32_t *next_basetimecnt, bool role) {}
AT(.bcom_text.bb.leisr)
void ble_evt_schedule(void) {}
AT(.bcom_text.bb.leisr)
uint32_t ble_evt_time_get(void) { return 0; }
AT(.bcom_text.bb.leisr)
uint8_t mgr_set_adv_data(void const *param) { return 0; }
AT(.bcom_text.bb.leisr)
void ble_lm_adv_data_update(void) {}
AT(.bcom_text.bb.leisr)
void ble_lc_check_update_evt_sent(uint16_t conhdl, void *evt_new) {}
AT(.bcom_text.bb.leisr)
void ble_evt_free_do(void *evt) {}

void ll_con_update_ind(uint16_t conhdl, void *evt_new, void *ll_env_ptr,uint16_t msg_id_con, uint16_t msg_id_sup) {}
void ll_con_update_cmd_complete_send(uint8_t status, uint16_t conhdl, void *evt, uint16_t msg_id) {}
void ll_map_update_ind(uint16_t conhdl, void *param) {}
void ll_common_nb_of_pkt_comp_evt_send(uint16_t conhdl, uint8_t nb_of_pkt, uint16_t msg_id) {}

void ble_ll_init(void) {}
void ble_ll_reset(void) {}
bool ble_event_cmd_complete(uint8_t *packet, int size) { return false; }
void ble_event_meta(uint8_t *packet, int size) {}
int att_server_notify_do(void) { return 1;}
void hci_run_le_connection(void) {}
void btstack_ble_init(void) {}
void btstack_ble_send_req(void) {}
void btstack_ble_update_conn_param(void) {}
void btstack_ble_set_adv_interval(void) {}
void ble_set_adv_interval(u16 interval) {}
void btstack_adv0_ctrl(uint opcode){}
uint8_t ble_adv0_get_adv_en(void) {return 0;}
#endif

#if !LE_BQB_RF_EN
AT(.com_text.bb.leisr)
bool ble_data_ind_test_mode(uint8_t rx_cnt, uint8_t rx_hdl) {return false;}
#endif

#if !BT_SPP_EN
void spp_init(void) {}
int bt_spp_tx(uint8_t *packet, uint16_t len) {return 0;}
void btstack_spp_send(void){}
void spp_establish_service_level_connection(bd_addr_t bd_addr) {}
void spp_release_service_level_connection(bd_addr_t bd_addr) {}
#endif

#if !BT_HID_EN
void hid_establish_service_level_connection(bd_addr_t bd_addr) {}
void hid_release_service_level_connection(bd_addr_t bd_addr) {}
void btstack_hid_send(void) {}
void btstack_hid_key(uint keycode) {}
void btstack_hid_consumer(uint keycode) {}
void btstack_hid_touch_screen(uint keycode) {}
void btstack_hid_simple_keyboard(uint keycode) {}
#endif

#if !BT_PBAP_EN
void pbap_client_init(void) {}
#endif

#if !BT_MAP_EN
void map_client_init(void) {}
void btstack_map(uint param) {}
void bt_get_time(char *ptr){}
#endif

#if !(BT_PBAP_EN || BT_MAP_EN)
void goep_client_init(void) {}
#endif

#if !MIC_EQ_EN
AT(.com_text.mic_eq)
void sdadc_pcm_peri_eq(u8 *ptr, u32 samples){}
#endif

#if !WARNING_WAVRES_PLAY
bool wav_res_stop(void){return false;}
void wav_res_play_kick(u32 addr, u32 len){}
void wav_res_dec_process(void){}
bool wav_res_is_play(void){return false;}
AT(.rodata.wavres.buf)
const int wavres_cb = 0;
#endif

#if !BT_HFP_MSBC_EN
AT(.sbcdec.code)
bool btmsbc_fill_callback(u8 *eptr_in, u8 *eptr_out, u8 *dptr_in, u8 *dptr_out)
{
    return false;
}
void msbc_kick_start(void){}
void bt_msbc_process(void){}
void bt_msbc_pcm_output(u16 *output){}
void msbc_init(void){}
void msbc_exit(void){}
bool msbc_encode_init(void){return false;}
void msbc_encode_exit(void){}
u16 bt_msbc_encode_frame(u8 *buf, u16 len){return 0;}
#endif

#if (UART0_PRINTF_SEL == PRINTF_NONE)
AT(.com_text.err)
void sys_error_hook(u8 err_no)
{
    WDT_RST();
    while(1);
}

AT(.com_text.exception) WEAK
void exception_isr(void)
{
    sys_error_hook(2);
}
#endif

#if BT_ID3_TAG_EN
bool bt_id3_en(void)
{
    return BT_ID3_TAG_EN;
}
#endif

#if !BT_SCO_DUMP_EN
void bt_sco_dump_init(void) {}
AT(.com_text.sco_dump)
void bt_sco_huart_tx_done(void){}
AT(.bt_voice.sco_dump)
bool sco_huart_putcs(u8 type, u8 frame_num, void *buf, uint len){return false;}
AT(.bt_voice.sco_dump)
void bt_sco_2ch_dump(s16 *in, s16 *out, u32 len){}
AT(.bt_voice.sco_dump)
void bt_sco_3ch_dump(s16 *near, s16 *far, s16 *out, u32 len){}
AT(.bt_voice.sco_dump)
void bt_sco_dump(u32 index, s16 *ptr, u32 len){}
#endif

#if !BT_SCO_MAV_EN
AT(.com_text.mav)
void mav_kick_start(void) {}
void magic_voice_process(void){}
void magic_voice_init(void *cfg){}
#endif

#if !BT_SCO_FAR_NR_EN
void nr_far_init(u16 noise_thr, u16 nr_level) {}
void nr_far_process(s16 *data) {}
void bt_sco_far_nr_process(u8 *buf, u32 samples){}
#endif

#if !DAC_DRC_EN
AT(.com_text.dac.dnr)
void dac_dnr_process(void) {}
#endif


#if (!USB_SUPPORT_EN && !SD_SUPPORT_EN && !EARPHONE_DETECT_EN)
void dev_init(void)
{

}
#endif


