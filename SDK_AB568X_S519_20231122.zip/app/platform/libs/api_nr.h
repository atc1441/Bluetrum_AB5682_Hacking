#ifndef _API_NR_H
#define _API_NR_H

typedef struct {
    u8 enable;
    u8 mode;
    u8 level;
    u8 prior_opt_idx;
    u8 converg_en;
    u8 trumpet_en;
    u16 trumpet_smooth;
    u16 trumpet_range;
} near_nr_cfg_t;

typedef struct {
    u8 enable;
    u8 level;
    u8 noise_thr;
    u8 resv;
} far_nr_cfg_t;

typedef struct {
    //AEC
    u8  aec_en;
    u8  aec_echo_level;
    u16 aec_far_offset;
    u8  ef2df_copy_en;
    u8  nlp_monosig;
    u8  nlp_bypass;

    //ALC
    u8 alc_en;
    u8 alc_fade_in_step;
    u8 alc_fade_out_step;
    u8 alc_fade_in_delay;
    u8 alc_fade_out_delay;
    s32 alc_far_voice_thr;

    //near nr
    near_nr_cfg_t near_nr;

    //far nr
    far_nr_cfg_t far_nr;

    //other
    u8 hnltmp_level;
    u8 mic_eq_en;
    u8 mic_mav_en;
    u32 post_gain;              //后置数据增益
} bt_voice_cfg_t;

#endif // _API_NR_H
