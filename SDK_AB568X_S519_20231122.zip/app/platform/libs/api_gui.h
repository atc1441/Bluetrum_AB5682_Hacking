#ifndef _API_GUI_H
#define _API_GUI_H

typedef struct rect_t_ {
    s16 x;
    s16 y;
    s16 wid;
    s16 hei;
} rect_t;

typedef struct point_t_ {
    s16 x;
    s16 y;
} point_t;

typedef struct area_t_ {
    s16 wid;
    s16 hei;
} area_t;

typedef void widget_t;
typedef void widget_page_t;
typedef void widget_image_t;        //功能比较全
typedef void widget_icon_t;         //只有简单的贴图和缩放功能，但是更省Buffer
typedef void widget_text_t;
typedef void widget_rect_t;

//=== 常用颜色，非常用颜色可以用make_color函数来生成 ===
#define COLOR_WHITE             0xFFFF
#define COLOR_BLACK             0
#define COLOR_RED               0xF800
#define COLOR_GREEN             0x07E0
#define COLOR_BLUE              0x001F
#define COLOR_YELLOW            0xFFE0
#define COLOR_MAGENTA           0xF81F
#define COLOR_CYAN              0x07FF
#define COLOR_GRAY              0x8410
#define COLOR_DARKGRAY          0xAD55
#define COLOR_DIMGRAY           0x6B4D

//=== GUI ===
//GUI初始化参数
typedef struct gui_init_param_t_ {
    u16 screen_width;               //屏幕宽
    u16 screen_height;              //屏幕高
    u8 *element_buf;                //element与widget缓存
    u8 *widget_buf;
    u16 element_buf_size;
    u16 widget_buf_size;
    u8 *temp_buf;                   //中间计算缓存
    u32 temp_buf_size;              //中间计算缓存大小
    u8 *lines_buf;                  //推屏缓存(双份)
    u32 lines_buf_size;             //推屏缓存大小
    u16 lines_count;                //每次推屏的行数
    u16 maxsize_parbuf;             //PAR解码缓存
    u32 font_res_addr;              //字库资源地址
    u16 max_font_size;
    u8 font_wspace;                 //字的间距
    u8 font_hspace;
    u8 rsvd[20];
} gui_init_param_t;

void os_gui_init(const gui_init_param_t *param);        //GUI初始化
void os_gui_draw(void);                                 //TE信号起来后，GUI开始绘制图形
void gui_process(void);                                 //主循环调用，更新Widget绘制
void gui_set_te_margin(u8 margin);                      //设置TE时隙
void gui_widget_refresh(void);                          //刷新widget
void os_gui_draw_w4_done(void);                         //等待当前帧刷完
area_t gui_image_get_size(u32 res_addr);                //获取图像尺寸
area_t widget_image_get_size(widget_image_t *img);		//根据控件获取图像尺寸


//生成一个RGB565的颜色值
u16 make_color(u8 r, u8 g, u8 b);
//=== Widget Common ===
//从Widget Pool中创建一个Page, 最多允许创建两个
widget_page_t *widget_pool_create(bool flag_top);
//清除一个从Widget Pool中创建的Page
void widget_pool_clear(widget_page_t *widget);
//获取第一个Widget，配合widget_get_next来遍历所有Widget
void *widget_get_head(void);
widget_t *widget_get_next(const widget_t *widget);
//获取Widget的父Page
widget_page_t *widget_get_parent(const widget_t *widget);
//设置Widget的Alpha值
void widget_set_alpha(widget_t *widget, u8 alpha);
//获取Alpha
u8 widget_get_alpha(widget_t *widget);
//设置Widget按中心点来设置坐标(默认为按中心对齐,改false则按左上角对齐)
void widget_set_align_center(widget_t *widget, bool align_center);
//设置Widget坐标
void widget_set_pos(widget_t *widget, s16 x, s16 y);
//设置Widget大小
void widget_set_size(widget_t *widget, s16 width, s16 height);
//设置Widget坐标及大小
void widget_set_location(widget_t *widget, s16 x, s16 y, s16 width, s16 height);
//获取Widget坐标及大小
rect_t widget_get_location(const widget_t *widget);
//获取Widget绝对坐标及大小
rect_t widget_get_absolute(const widget_t *widget);
//设置Widget是否可见
void widget_set_visible(widget_t *widget, bool visible);
//获取显示状态
bool widget_get_visble(widget_t *widget);

//=== Widget Page ===
//创建一个Page
widget_page_t *widget_page_create(widget_page_t *parent);
//判断是否为一个Page
bool widget_is_page(const void *widget);
//设置Page client相对Page Window左上的坐标。0,0则对齐到左上角
void widget_page_set_client(widget_page_t *widget, s16 x, s16 y);
//设置Page window缩放到的大小。0,0则不进行缩放
void widget_page_scale_to(widget_page_t *widget, s16 wid, s16 hei);
//更新Page信息
void widget_page_update(void);

//=== Widget Image ===
enum {
    ROT_MODE_NORMAL,        //普通旋转模式
    ROT_MODE_X,             //只旋转X (平行四边形, 2.5D效果)
};
//创建一张图片(和widget_icon的区别：功能比较全，支持裁剪和旋转)
widget_image_t *widget_image_create(widget_page_t *parent, u32 res_addr);
//设置图片
void widget_image_set(widget_image_t *img, u32 res_addr);
//设置图片的旋转角度
void widget_image_set_rotation(void *img_ptr, s16 angle);
//按坐标设置图像旋转角度
void widget_image_set_rotation_bypos(widget_image_t *img, s16 x, s16 y);
//设置图片的旋转中心点
void widget_image_set_rotation_center(void *img_ptr, s16 x, s16 y);
//设置图像旋转模式
void widget_image_set_rotation_mode(widget_image_t *img, u8 mode);
//裁剪图片区域
void widget_image_cut(widget_image_t *img, s16 x, s16 y, s16 wid, s16 hei);

//=== Widget Icon ===
//创建一个图标(和wiget_image的区别：只有简单的贴图和缩放功能，但是更省Buffer)
widget_icon_t *widget_icon_create(widget_page_t *parent, u32 res_addr);
//判断是否是一个图标
bool widget_is_icon(widget_icon_t *icon);
//设置图标
void widget_icon_set(widget_icon_t *icon, u32 res_addr);

//=== Widget Text ===
//创建一个文本. max_word_cnt为最多多少个字(不分全半角)
widget_text_t *widget_text_create(widget_page_t *parent, u16 max_word_cnt);
//设置文件内容
void widget_text_set(widget_text_t *txt, const char *text);
//设置文本颜色
void widget_text_set_color(widget_text_t *txt, u16 color);
//设置自适应大小。
void widget_text_set_autosize(widget_text_t *txt, bool autosize);
//设置文本是否自动分行。
void widget_text_set_wordwrap(widget_text_t *txt, bool wordwrap);
//设置Client相对左上的坐标。0,0则对齐到左上角(用于文字滚动)
void widget_text_set_client(widget_text_t *txt, s16 x, s16 y);
//获取字体区域
area_t widget_text_get_area(widget_text_t *txt);
//获取字高(典型值，非最大值)
u8 widget_text_get_height(void);

//=== Widget Rect ===
//创建一个矩形
widget_rect_t *widget_rect_create(widget_page_t *parent);
//设置矩形的填充颜色
void widget_rect_set_color(widget_rect_t *rect, u16 color);

#endif // _API_GUI_H
