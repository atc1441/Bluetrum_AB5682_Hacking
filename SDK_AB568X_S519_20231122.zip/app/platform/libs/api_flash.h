#ifndef _API_FLASH_H
#define _API_FLASH_H

uint os_spiflash_read(void *buf, u32 addr, uint len);
void os_spiflash_program(void *buf, u32 addr, uint len);
void os_spiflash_erase(u32 addr);

#endif // _API_FLASH_H
