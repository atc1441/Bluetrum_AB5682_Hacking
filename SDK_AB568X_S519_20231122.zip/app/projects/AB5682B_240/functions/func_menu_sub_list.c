#include "include.h"
#include "func.h"
#include "func_menu.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define MENU_LIST_CNT                       ((int)(sizeof(tbl_menu_list) / sizeof(tbl_menu_list[0])))

enum {
    COMPO_ID_LISTBOX = 1,
};

typedef struct f_menu_list_t_ {
    compo_listbox_t *listbox;

} f_menu_list_t;

static compo_listbox_item_t tbl_menu_list[] = {
    {STR_SPORTS,                 UI_BUF_ICON_SPORT_BIN,             .func_sta = FUNC_SPORT},                //运动
//    {STR_STEP,                   UI_BUF_ICON_STEP_BIN,            .func_sta = FUNC_NULL},                 //计步
    {STR_SLEEP,                  UI_BUF_ICON_SLEEP_BIN,             .func_sta = FUNC_SLEEP},                //睡眠
    {STR_ACTIVITY_RECORD,        UI_BUF_ICON_ACTIVITY_BIN,          .func_sta = FUNC_ACTIVITY},             //活动记录
    {STR_HEART_RATE,             UI_BUF_ICON_HEART_RATE_BIN,        .func_sta = FUNC_HEARTRATE},            //心率
    {STR_BLOOD_PRESSURE,         UI_BUF_ICON_BLOOD_PRESSURE_BIN,    .func_sta = FUNC_BLOOD_PRESSURE},       //血压
    {STR_BLOOD_OXYGEN,           UI_BUF_ICON_BLOOD_OXYGEN_BIN,      .func_sta = FUNC_BLOOD_OXYGEN},         //血氧
    {STR_MESSAGE,                UI_BUF_ICON_MESSAGE_BIN,           .func_sta = FUNC_MESSAGE},              //消息
    {STR_PHONE,                  UI_BUF_ICON_CALL_BIN,              .func_sta = FUNC_CALL},                 //电话
    {STR_MUSIC,                  UI_BUF_ICON_MUSIC_BIN,             .func_sta = FUNC_BT},                   //音乐
    {STR_WEATHER,                UI_BUF_ICON_WEATHER_BIN,           .func_sta = FUNC_WEATHER},              //天气
    {STR_BREATHE,                UI_BUF_ICON_BREATHE_BIN,           .func_sta = FUNC_BREATHE},              //呼吸
    {STR_CACULATOR,              UI_BUF_ICON_CALCULATOR_BIN,        .func_sta = FUNC_CALCULATOR},           //计算器
    {STR_ALARM_CLOCK,            UI_BUF_ICON_ALARM_CLOCK_BIN,       .func_sta = FUNC_ALARM_CLOCK},          //闹钟
    {STR_TIMER,                  UI_BUF_ICON_TIMER_BIN,             .func_sta = FUNC_TIMER},                //定时器
    {STR_STOP_WATCH,             UI_BUF_ICON_STOPWATCH_BIN,         .func_sta = FUNC_STOPWATCH},            //秒表
    {STR_CAMERA,                 UI_BUF_ICON_CAMERA_BIN,            .func_sta = FUNC_CAMERA},               //相机
    {STR_VOICE_ASSISTANT,        UI_BUF_ICON_VOICE_BIN,             .func_sta = FUNC_VOICE},                //语音助手
    {STR_FIND_PHONE,             UI_BUF_ICON_FINDPHONE_BIN,         .func_sta = FUNC_FINDPHONE},            //查找手机
    {STR_GAME,                   UI_BUF_ICON_GAME_BIN,              .func_sta = FUNC_GAME},                 //游戏
    {STR_SETTING,                UI_BUF_ICON_SETTING_BIN,           .func_sta = FUNC_SETTING},              //设置
    {STR_STYLE,                  UI_BUF_ICON_MENU_BIN,              .func_sta = FUNC_STYLE},                //风格
};

//创建主菜单窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_menu_sub_list_form_create(void)
{
    //新建窗体
    compo_form_t *frm = compo_form_create(false);       //菜单一般创建在底层

    //新建菜单列表
    compo_listbox_t *listbox = compo_listbox_create(frm, COMPO_LISTBOX_STYLE_MENU_NORMAL);
//    compo_listbox_cycle_en(listbox, true);  //循环滑动
    compo_listbox_set(listbox, tbl_menu_list, MENU_LIST_CNT);
    compo_setid(listbox, COMPO_ID_LISTBOX);

    u8 menu_idx = func_cb.menu_idx;
    if (menu_idx < 1) {
        menu_idx = 1;
    }
    compo_listbox_set_focus_byidx(listbox, menu_idx);
    compo_listbox_update(listbox);
    return frm;
}

//点进图标进入应用
static void func_menu_sub_list_icon_click(void)
{
    int icon_idx;
    f_menu_list_t *f_menu = (f_menu_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_menu->listbox;
    u8 func_sta;

    icon_idx = compo_listbox_select(listbox, ctp_get_sxy());
    if (icon_idx < 0 || icon_idx >= MENU_LIST_CNT) {
        return;
    }

    //根据图标索引获取应用ID
    func_sta = tbl_menu_list[icon_idx].func_sta;

    //切入应用
    if (func_sta > 0) {
        compo_form_t *frm = func_create_form(func_sta);
        func_switching(FUNC_SWITCH_ZOOM_ENTER | FUNC_SWITCH_AUTO, listbox->sel_icon);
        compo_form_destroy(frm);
        func_cb.sta = func_sta;
        func_cb.menu_idx = icon_idx;                //记住当前编号
    }
}

//切换到时钟
static void func_menu_sub_list_switch_to_clock(void)
{
    f_menu_list_t *f_menu = (f_menu_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_menu->listbox;
    widget_icon_t *icon = compo_listbox_select_byidx(listbox, 0);
    u8 func_sta = FUNC_CLOCK;
    compo_form_t *frm = func_create_form(func_sta);
    func_switching(FUNC_SWITCH_ZOOM_FADE_ENTER | FUNC_SWITCH_AUTO, icon);
    compo_form_destroy(frm);
    func_cb.sta = func_sta;
    func_cb.menu_idx = 0;
}

//主菜单功能事件处理
static void func_menu_sub_list_process(void)
{
    f_menu_list_t *f_menu = (f_menu_list_t *)func_cb.f_cb;
    compo_listbox_move(f_menu->listbox);
    func_process();
}

//主菜单功能消息处理
static void func_menu_sub_list_message(size_msg_t msg)
{
    f_menu_list_t *f_menu = (f_menu_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_menu->listbox;

    if (compo_listbox_message(listbox, msg)) {
        return;                                         //处理列表框信息
    }
    switch (msg) {
    case MSG_CTP_CLICK:
        func_menu_sub_list_icon_click();                //单击图标
        break;

    case MSG_CTP_LONG:
        break;

    case MSG_CTP_SHORT_RIGHT:
    case KU_DELAY_BACK:
        if (tick_check_expire(func_cb.enter_tick, TICK_IGNORE_KEY)) {
            func_menu_sub_list_switch_to_clock();       //返回时钟表盘界面
        }
        break;

    default:
        func_menu_sub_message(msg);
        break;
    }
}

//进入主菜单功能
static void func_menu_sub_list_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_menu_list_t));
    func_cb.frm_main = func_menu_sub_list_form_create();

    f_menu_list_t *f_menu = (f_menu_list_t *)func_cb.f_cb;
    f_menu->listbox = compo_getobj_byid(COMPO_ID_LISTBOX);
    compo_listbox_t *listbox = f_menu->listbox;
    if (listbox->type != COMPO_TYPE_LISTBOX) {
        halt(HALT_GUI_COMPO_LISTBOX_TYPE);
    }
    listbox->mcb = func_zalloc(sizeof(compo_listbox_move_cb_t));        //建立移动控制块，退出时需要释放
    compo_listbox_move_init(listbox);
    func_cb.enter_tick = tick_get();
    if (func_cb.flag_animation) {
        func_cb.flag_animation = 0;
    }
}

//退出菜单样式
void func_menu_sub_list_exit(void)
{
    f_menu_list_t *f_menu = (f_menu_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_menu->listbox;
    func_free(listbox->mcb);

    compo_form_destroy(func_cb.frm_main);
    func_free(func_cb.f_cb);
    func_cb.frm_main = NULL;
    func_cb.f_cb = NULL;
}

//主菜单功能
void func_menu_sub_list(void)
{
    printf("%s\n", __func__);
    func_menu_sub_list_enter();
    while (func_cb.sta == FUNC_MENU && func_cb.menu_style == MENU_STYLE_LIST) {
        func_menu_sub_list_process();
        func_menu_sub_list_message(msg_dequeue());
    }
    func_menu_sub_list_exit();
}
