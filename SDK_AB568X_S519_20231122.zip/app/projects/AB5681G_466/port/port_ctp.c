#include "include.h"
#include "port_ctp.h"

void port_ctp_init(void)
{
    GPIOBDIR &= ~BIT(7);                            //RST
    GPIOBSET = BIT(7);
    GPIOBDE |= BIT(7);
    GPIOBFEN &= ~BIT(7);

    GPIOBDIR |= BIT(6) | BIT(5);                    //SCL SDA
    GPIOBPU |= BIT(6) | BIT(5);
    GPIOBDE |= BIT(6) | BIT(5);
    GPIOBFEN |= BIT(6) | BIT(5);
    FUNCMCON2 = (4 << 12);
}

void port_ctp_exit(void)
{
    GPIOBPU &= ~(BIT(6) | BIT(5));                  //SCL SDA
    GPIOBDE &= ~(BIT(6) | BIT(5));                  //analog io status

    GPIOBDE &= ~(BIT(7));                           //RST
    GPIOBDIR |= BIT(7);                             //analog io status
}
