﻿/*****************************************************************************
 * Module    : Config
 * File      : config.h
 * Function  : SDK配置文件
 *****************************************************************************/

#ifndef USER_CONFIG_H
#define USER_CONFIG_H
#include "config_define.h"

/*****************************************************************************
 * Module    : Function选择相关配置
 *****************************************************************************/
#define MAX_FUNC_SORT_CNT               8   //最大支持左右快捷切换任务的个数

#define FUNC_BT_EN                      1   //是否打开蓝牙功能
#define FUNC_BT_DUT_EN                  0   //是否打开蓝牙的独立DUT测试模式
#define FUNC_IDLE_EN                    0   //是否打开IDLE功能

/*****************************************************************************
 * Module    : 系统功能选择配置
 *****************************************************************************/
#define BUCK_MODE_EN                    1                       //是否BUCK MODE
#define SYS_CLK_SEL                     SYS_192M                //选择系统时钟
#define POWKEY_10S_RESET                xcfg_cb.powkey_10s_reset
#define SOFT_POWER_ON_OFF               1                       //是否使用软开关机功能
#define PWRKEY_2_HW_PWRON               0                       //用PWRKEY模拟硬开关
#define USB_SD_UPDATE_EN                0                       //是否支持UDISK/SD的离线升级
#define GUI_SELECT                      GUI_OLED_466_ICNA3310B  //GUI Display Select
#define CTP_SELECT                      CTP_CST8X               //CTP Select
#define DEFAULT_TE_MODE                 0                       //默认TE模式
#define UART0_PRINTF_SEL                PRINTF_PB3              //选择UART打印信息输出IO，或关闭打印信息输出
#define SYS_INIT_VOLUME                 xcfg_cb.sys_init_vol    //系统默认音量

#define HEAP_FUNC_SIZE                  4096                    //FUNC HEAP SIZE

#define TS_MODE_EN                      0                       //内部NTC模块是否开启
/*****************************************************************************
 * Module    : GUI相关配置
 *****************************************************************************/
#define COMPO_BUF_SIZE                  1024                    //组件BUF大小(2个BUF)
#define TFT_TE_CYCLE                    16.67                   //TE周期时间 (ms)
#define TFT_TE_CYCLE_DELAY              (TFT_TE_CYCLE / 3)
#define GUI_LINES_CNT                   10                      //单次推屏行数
#define GUI_FONT_W_SPACE                0                       //字的间距
#define GUI_FONT_H_SPACE                4                       //字的行间距

#define FORM_TITLE_HEIGHT               36                      //窗体标题高度
#define FORM_TITLE_LEFT                 (GUI_SCREEN_WIDTH / 9)

/*****************************************************************************
 * Module    : 场景切换相关配置
 *****************************************************************************/
#define GUI_SIDE_MENU_WIDTH             (GUI_SCREEN_WIDTH / 2)  //边菜单的宽度

/*****************************************************************************
 * Module    : FLASH配置
 *****************************************************************************/
#define FLASH_SIZE                      FSIZE_8M                //根据芯片信息配置实际FLASH SIZE
#define FLASH_CODE_SIZE                 492K                    //程序使用空间大小
#define FLASH_CM_SIZE                   0x5000                  //CM参数区大小, 参数区至少20k
#define FLASH_ERASE_4K                  1                       //是否支持4K擦除
#define FLASH_DUAL_READ                 0                       //是否支持2线模式
#define FLASH_QUAD_READ                 0                       //是否支持4线模式
#define SPIFLASH_SPEED_UP_EN            1                       //SPI FLASH提速。

/*****************************************************************************
 * Module    : 蓝牙功能配置
 *****************************************************************************/
#define BT_POWER_UP_RECONNECT_TIMES     3   //上电回连次数
#define BT_TIME_OUT_RECONNECT_TIMES     20  //掉线回连次数
#define BT_SIMPLE_PAIR_EN               1   //是否打开蓝牙简易配对功能（关闭时需要手机端输入PIN码）
#define BT_DISCOVER_CTRL_EN             0   //是否使用按键打开可被发现（按一下按键才能被连接配对）
#define BT_DISCOVER_TIMEOUT             100 //按键打开可被发现后，多久后仍无连接自动关闭，0不自动关闭，单位100ms
#define BT_ANTI_LOST_EN                 0   //是否打开蓝牙防丢报警
#define BT_BQB_RF_EN                    0   //蓝牙RF BR/EDR BQB测试
#define BT_CBT_TEST_EN                  0   //蓝牙CBT测试使能
#define BT_FCC_TEST_EN                  0   //蓝牙FCC测试使能   //默认PB3 波特率1500000通信
#define BT_LOCAL_ADDR                   0   //蓝牙是否使用本地地址，0使用配置工具地址

#define BT_2ACL_EN                      0   //是否支持连接两部手机
#define BT_A2DP_EN                      1   //是否打开蓝牙音乐服务
#define BT_HFP_EN                       1   //是否打开蓝牙通话服务
#define BT_HSP_EN                       0   //是否打开蓝牙HSP通话服务
#define BT_PBAP_EN                      0   //是否打开蓝牙电话簿服务
#define BT_MAP_EN                       0   //是否打开蓝牙短信服务(用于获取设备时间，支持IOS/Android)

#define BT_SPP_EN                       0   //是否打开蓝牙串口服务
#define BT_HID_EN                       0   //是否打开蓝牙HID服务
#define BT_HID_TYPE                     0   //选择HID服务类型: 0=自拍器(VOL+, 部分Android不能拍照), 1=自拍器(VOL+和ENTER, 影响IOS键盘使用), 2=游戏手柄, 3 = (支持BT_HID_SIMPLE_KEYBOARD时需要配置成3) 4=模拟触点功能(抖音点赞上下滑等);
#define BT_HID_MENU_EN                  0   //蓝牙HID是否需要手动连接/断开
#define BT_HID_DISCON_DEFAULT_EN        0   //蓝牙HID服务默认不连接，需要手动进行连接。
#define BT_HFP_CALL_PRIVATE_EN          1   //是否使能私密接听与蓝牙接听切换功能
#define BT_HFP_CALL_PRIVATE_FORCE_EN    0   //是否强制使用私密接听（手机端接听）
#define BT_HFP_RING_NUMBER_EN           1   //是否支持来电报号
#define BT_HFP_INBAND_RING_EN           1   //是否支持手机来电铃声（部分android不支持，默认用本地RING提示音）
#define BT_HFP_BAT_REPORT_EN            0   //是否支持电量显示 (上传电量给手机显示)
#define BT_HFP_MSBC_EN                  1   //是否打开宽带语音功能
#define BT_VOIP_REJECT_EN               0   //网络电话不建立SCO功能使能,使用时需A2DP断开 (网络电话：微信通话，QQ通话等)
#define BT_A2DP_PROFILE_DEFAULT_EN      1   //蓝牙音频服务是否默认打开
#define BT_A2DP_VOL_CTRL_EN             1   //是否支持A2DP音量与手机同步
#define BT_A2DP_RECON_EN                0   //是否支持A2DP控制键（播放/暂停、上下曲键）回连
#define BT_AVDTP_DELAY_REPORT_EN        1   //是否上报当前延迟给手机进行音视频同步
#define BT_SCO_DBG_EN                   1   //是否打开无线SPP调试通话参数功能
#define BT_CONNECTED_AUTO_PLAY_EN       0   //是否打开蓝牙连接后自动播放音乐功能
#define BT_ID3_TAG_EN                   0   //是否获取蓝牙ID3信息,蓝牙ID3信息会从bt_id3_tag_callback函数中输出
#define BT_SINGLE_SLEEP_LPW_EN          0   //是否打开单模进休眠关bt省电

/*****************************************************************************
 * Module    : BLE功能配置
 *****************************************************************************/
#define LE_EN                           1   //是否打开BLE功能
#define LE_PAIR_EN                      1   //是否使能BLE的加密配对
#define LE_SM_SC_EN                     1   //是否使能BLE的加密连接，需同时打开LE_PAIR_EN。一键双联需要打开此配置。
#define LE_ADV_POWERON_EN               1   //是否上电默认打开BLE广播
#define LE_BQB_RF_EN                    0   //BLE DUT测试模式，使用串口通信（仅用于BQB RFPHY测试）

//gatt 配置
#define LE_ATT_NUM                      25  //最大支持多少条gatt属性, att_handle 1 ~ LE_ATT_NUM

//APP 功能相关(APP同时只能打开1个)
#define LE_AB_LINK_APP_EN               0           //是否打开AB-LINK APP控制功能
#define USE_APP_TYPE                    USE_AB_APP  //选择手表应用app类型

//ANCS
#define LE_ANCS_CLIENT_EN               1   //是否打开ANCS Clients
#define LE_ANCS_MANUAL_EN               1   //是否需要手动打开ancs,调用ancs start

#define LE_ADV0_EN                      0   //是否打开无连接广播功能
#define LE_WIN10_POPUP                  0   //是否打开win10 swift pair快速配对

//FOTA功能配置
#define LE_APP_FOT_EN                   1   //是否打开BLE FOTA服务
#define AB_FOT_TYPE                     AB_FOT_TYPE_NORMAL     //独立FOTA升级方式选择

/*****************************************************************************
 * Module    : 通话功能配置
 *****************************************************************************/
//通话参数
#define BT_SCO_DUMP_EN                  0                           //是否通过HART DUMP通话数据, 需要打开HUART调EQ功能。1：dump近端算法前后数据，2：dump远端降噪前后数据
#define BT_SCO_MAV_EN                   0                           //是否打开蓝牙通话变声功能

#define BT_PLC_EN                       1
#define BT_ANL_GAIN                     xcfg_cb.bt_anl_gain         //MIC模拟增益(0~23)
#define BT_DIG_GAIN                     xcfg_cb.bt_dig_gain         //MIC数字增益(0-63), step: 0.5db
#define BT_CALL_MAX_GAIN                xcfg_cb.bt_call_max_gain    //配置通话时DAC最大模拟增益

#define BT_AEC_EN                       1
#define BT_ECHO_LEVEL                   xcfg_cb.bt_echo_level       //回声消除级别（级别越高，回声衰减越明显，但通话效果越差）(0~15)
#define BT_FAR_OFFSET                   xcfg_cb.bt_far_offset       //远端补偿值(0~255)

#define BT_ALC_EN                       1                           //是否使能ALC
#define BT_ALC_FADE_IN_DELAY            26                          //近端淡入延时(n*7.5ms)
#define BT_ALC_FADE_IN_STEP             1                           //近端淡入速度(64ms)
#define BT_ALC_FADE_OUT_DELAY           2                           //远端淡入延时(n*7.5ms)
#define BT_ALC_FADE_OUT_STEP            16                          //远端淡入速度(4ms)
#define BT_ALC_VOICE_THR                0x30000

//通话近端降噪算法(耳机MIC采集数据降噪)
#define BT_SCO_NR_EN					1	                        //是否打开AEC硬件的AINS3降噪
#define BT_SCO_NR_LEVEL				    xcfg_cb.bt_sco_nr_level	    //0-15级（默认0级）
#define BT_SCO_NR_TRUMPET_EN            xcfg_cb.bt_sco_nr_trumpet_en

//通话远端降噪算法(接收远端手机的通话数据降噪)
#define BT_SCO_FAR_NR_EN                0                           //是否打开远端降噪算法(Code: 5.5KB, Ram: 2.1KB)
#define BT_SCO_FAR_NR_LEVEL             5                           //强度: 0~5
#define BT_SCO_FAR_NOISE_THR            1                           //范围: 0~20

/*****************************************************************************
* Module    : DAC配置控制
******************************************************************************/
#define DAC_CH_SEL                      xcfg_cb.dac_sel             //DAC_MONO ~ DAC_VCMBUF_DUAL
#define DAC_FAST_SETUP_EN               1                           //DAC快速上电，有噪声需要外部功放MUTE
#define DAC_MAX_GAIN                    xcfg_cb.dac_max_gain        //配置DAC最大模拟增益，默认设置为dac_vol_table[VOL_MAX]
#define DAC_OUT_SPR                     DAC_OUT_48K                 //dac out sample rate
#define DAC_LDOH_SEL                    xcfg_cb.dacaud_ldo_sel
#define DACVDD_BYPASS_EN                xcfg_cb.dacaud_bypass_en    //DACVDD Bypass
#define DAC_PULL_DOWN_DELAY             80                          //控制DAC隔直电容的放电时间, 无电容时可设为0，减少开机时间。
#define DAC_DNR_EN                      0                           //是否使能动态降噪
#define DAC_DRC_EN                      1                           //是否使能DRC功能


/*****************************************************************************
 * Module    : EQ相关配置
 *****************************************************************************/
#define EQ_MODE_EN                      0           //是否调节EQ MODE (POP, Rock, Jazz, Classic, Country)
#define MIC_EQ_EN                       0           //是否调节MIC_EQ (非通话模式)
#define EQ_DBG_IN_UART                  1           //是否使能UART在线调节EQ
#define EQ_DBG_IN_SPP                   1           //是否使能SPP在线调节EQ


/*****************************************************************************
 * Module    : User按键配置 (可以同时选择多组按键)
 *****************************************************************************/
#define USER_PWRKEY                     1           //PWRKEY的使用，0为不使用
#define USER_ADKEY                      0           //ADKEY的使用， 0为不使用
#define USER_IOKEY                      0           //IOKEY的使用， 0为不使用

#define USER_KEY_QDEC_EN                1           //旋钮, 硬件正交解码, A,B输出分别接一个IO
#define USER_QDEC_MAPPING               QDEC_MAP_G1 //选择硬件正交解码的mapping, 每组map的IO固定，详见define处说明

#define USER_ADKEY_QDEC_EN              0           //旋钮, A,B串不同电阻接到同一个IO口上，软件ADC采集并解码
#define USER_QDEC_ADCH                  ADCCH_PA0   //选择旋钮的ADC通道

#define USER_MULTI_PRESS_EN             1           //按键多击检测使能
#define USER_MULTI_KEY_TIME             4           //按键多击响应时间（单位100ms）

#define USER_PWRON_KEY_SEL              0           //定义为开关机的PWRKEY按键编号, 范围: 0 ~ 2
#define PWRON_PRESS_TIME                1500        //长按PWRKEY多长时间开机？
#define PWROFF_PRESS_TIME               18          //长按PWRKEY多长时间关机 3: 1.5秒, 6: 2秒, 9: 2.5秒, 12: 3秒, 15: 3.5秒, 18: 4秒, 24: 5秒

#define ADKEY_CH                        ADCCH_PE7   //ADKEY的ADC通路选择
#define IS_PWRKEY_PRESS()			    (0 == (RTCCON & BIT(19)))

/*****************************************************************************
 * Module    : 电量检测及低电
 *****************************************************************************/
#define VBAT_DETECT_EN                  1           //电池电量检测功能
#define VBAT2_ADCCH                     ADCCH_VBAT  //ADCCH_VBAT为内部1/2电压通路，带升压应用需要外部ADC通路检测1/2电池电压
#define VBAT_FILTER_USE_PEAK            0           //电池检测滤波选则://0 取平均值.//1 取峰值(适用于播放音乐时,电池波动比较大的音箱方案).
#define LPWR_WARNING_VBAT               3500        //低电提醒电压   0：表示关闭此功能
#define LPWR_OFF_VBAT                   3100        //低电关机电压   0：表示关闭此功能
#define LOWPWR_REDUCE_VOL_EN            1           //低电时是否降低音量
#define LPWR_WARING_TIMES               0xff        //报低电次数
#define LPWR_WARNING_PERIOD             30          //低电播报周期(单位：秒)

/*****************************************************************************
 * Module    : 充电功能选择
 *****************************************************************************/
#define CHARGE_EN                       1                               //是否打开充电功能
#define CHARGE_TRICK_EN                 xcfg_cb.charge_trick_en         //是否打开涓流充电功能
#define CHARGE_DC_RESET                 xcfg_cb.charge_dc_reset         //是否打开DC插入复位功能
#define CHARGE_DC_NOT_PWRON             xcfg_cb.charge_dc_not_pwron     //DC插入，是否软开机。 1: DC IN时不能开机
#define CHARGE_DC_IN()                  ((RTCCON >> 20) & 0x01)//charge_dc_detect()
#define CHARGE_INBOX()                  ((RTCCON >> 22) & 0x01)

#define CHARGE_STOP_CURR                xcfg_cb.charge_stop_curr        //电流范围0~37.5mA, 配置值范围: 0~15, 步进2.5mA
#define CHARGE_CONSTANT_CURR            xcfg_cb.charge_constant_curr    //电流范围0~320mA, 配置值范围: 0~63, 步进5mA
#define CHARGE_TRICKLE_CURR             xcfg_cb.charge_trickle_curr
#define CHARGE_STOP_VOLT                0                               //充电截止电压：0:4.2v；1:4.35v; 2:4.4v; 3:4.45v
#define CHARGE_TRICK_STOP_VOLT          1                               //涓流截止电压：0:2.9v; 1:3v
#define CHARGE_VOLT_FOLLOW              0                               //是否打开跟随快充：0:NONE; 1:187.5mV; 2:62.5mV; 3:375mV

//充电辅助设置项
#define CHARGE_USER_NTC_EN              0                               //充电是否使用NTC参数
#define CHARGE_VBAT_REFILL              4150                            //充满后停止充电，电池掉到指定电压后续充

#define CHARGE_NTC_ADC_MAX_TEMP         53                            //设置最小温度 摄氏度      53
#define CHARGE_NTC_ADC_MAX_RE_TEMP      48                            //设置恢复温度 摄氏度     48
#define CHARGE_NTC_ADC_MIN_TEMP         0                             //设置最高温度 摄氏度0
#define CHARGE_NTC_ADC_MIN_RE_TEMP      5                             //设置恢复温度 摄氏度5
/*****************************************************************************
 * Module    : 硬件I2C配置
 *****************************************************************************/
#define I2C_HW_EN                       1           //是否使能硬件I2C功能

/*****************************************************************************
 * Module    : 软件I2C配置
 *****************************************************************************/
#define I2C_SW_EN                       0           //是否使能软件I2C功能

#define I2C_SCL_IN()                    {GPIOEDIR |= BIT(5); GPIOEPU  |= BIT(5);}
#define I2C_SCL_OUT()                   {GPIOEDE |= BIT(5); GPIOEDIR &= ~BIT(5);}
#define I2C_SCL_H()                     {GPIOESET = BIT(5);}
#define I2C_SCL_L()                     {GPIOECLR = BIT(5);}

#define I2C_SDA_IN()                    {GPIOEDIR |= BIT(7); GPIOEPU  |= BIT(7);}
#define I2C_SDA_OUT()                   {GPIOEDE |= BIT(7); GPIOEDIR &= ~BIT(7);}
#define I2C_SDA_H()                     {GPIOESET = BIT(7);}
#define I2C_SDA_L()                     {GPIOECLR = BIT(7);}
#define I2C_SDA_IS_H()                  (GPIOE & BIT(7))

#define I2C_SDA_SCL_OUT()               {I2C_SDA_OUT(); I2C_SCL_OUT();}
#define I2C_SDA_SCL_H()                 {I2C_SDA_H(); I2C_SCL_H();}

/*****************************************************************************
 * Module    : 传感器配置
 *****************************************************************************/
#define SENSOR_STEP_SEL                 SENSOR_STEP_NULL
#define SENSOR_HR_SEL                   SENSOR_HR_NULL
#define SENSOR_GEO_SEL                  SENSOR_GEO_NULL

/*****************************************************************************
 * Module    : Loudspeaker mute检测配置
 *****************************************************************************/
#define EARPHONE_DETECT_EN              0           //是否打开耳机检测
#define SDCMD_MUX_DETECT_EARPHONE       0           //是否复用SDCMD检测耳机插入
#define EARPHONE_DETECT_INIT()          earphone_detect_init()
#define EARPHONE_IS_ONLINE()            earphone_is_online()
#define IS_DET_EAR_BUSY()               is_detect_earphone_busy()
#define EARPHONE_DETECT_PORT            IO_NONE

#define LOUDSPEAKER_MUTE_EN             1           //是否使能功放MUTE
#define LOUDSPEAKER_MUTE_INIT()         loudspeaker_mute_init()
#define LOUDSPEAKER_MUTE_DIS()          loudspeaker_disable()
#define LOUDSPEAKER_MUTE()              loudspeaker_mute()
#define LOUDSPEAKER_UNMUTE()            loudspeaker_unmute()
#define LOUDSPEAKER_MUTE_PORT           IO_PE0
#define LOUDSPEAKER_HIGH_MUTE           1           //高电平为MUTE状态
#define LOUDSPEAKER_UNMUTE_DELAY        6           //UNMUTE延时配置，单位为5ms

#define AMP_CTRL_AB_D_EN                0           //功放AB/D类控制
#define AMP_CTRL_AB_D_PORT              IO_NONE     //控制IO
#define AMP_CTRL_AB_D_TYPE              0           //0:独立IO电平控制, 1:mute脉冲控制
#define AMPLIFIER_SEL_INIT()            amp_sel_cfg_init(AMP_CTRL_AB_D_PORT)
#define AMPLIFIER_SEL_D()               amp_sel_cfg_d()
#define AMPLIFIER_SEL_AB()              amp_sel_cfg_ab()

/*****************************************************************************
 * Module    : 提示音 功能选择
 *****************************************************************************/
#define WARNING_TONE_EN                 1            //是否打开提示音功能, 总开关
#define WARING_MAXVOL_MP3               0            //最大音量提示音WAV或MP3选择， 播放WAV可以与MUSIC叠加播放。
#define WARNING_WAVRES_PLAY             0            //是否支持WAV提示音播放
#define WARNING_VOLUME                  xcfg_cb.warning_volume   //播放提示音的音量级数
#define LANG_SELECT                     LANG_EN      //提示音语言选择

#define WARNING_POWER_ON                0
#define WARNING_POWER_OFF               0
#define WARNING_BT_INCALL               0

#include "config_extra.h"

#endif // USER_CONFIG_H
