#ifndef _FUNC_MUSIC_H
#define _FUNC_MUSIC_H

typedef struct {
    u8 min;                     //minute
    u8 sec;                     //second
} msc_time_t;

typedef struct {
    u32 frame_count;            //current frame count
    u32 file_ptr;               //file ptr of current frame
    u16 fname_crc;              //file name crc
} msc_breakpiont_t;

typedef struct {
    u8 pause        : 1,
       file_change  : 1,
       dev_change   : 2,
       //cur_dev      : 2,
       brkpt_flag   : 1,
       prev_flag    : 1;
    u8 cur_dev;

    u8 rec_type     : 1,
       rec_scan     : 2,
       encrypt      : 1;

    u8 type;                    //���ָ�ʽ
    u32 bit_rate;               //��������

    char *fname;

    msc_time_t alltime;         //music file total time
    msc_time_t curtime;         //music current playing time

    u16 file_num;
    u16 file_total;

    u16 dir_num;                //directory current number
    u16 dir_total;              //directory total number

#if MUSIC_BREAKPOINT_EN
    msc_breakpiont_t brkpt;     //music breakpoint info
#endif // MUSIC_BREAKPOINT_EN

#if MUSIC_LRC_EN
    u8 lrc_sta;
    u8 lrc_encoding;
#endif // MUSIC_LRC_EN

    ///LCD������������ʾ����
#if GUI_LCD_EN
    msc_time_t disptime;
#endif // GUI_LCD_EN
    u8 draw_update  : 1,
       sta_update   : 1,
       time_update  : 1,
       fname_update : 1,
       lrc_update   : 1;
} func_msc_t;
extern func_msc_t f_msc;

#if MUSIC_AB_BREAKPOINT_EN

typedef enum{
    AB_STA_NON = 0,
    AB_STA_A,
    AB_STA_B,
}AB_STA;

typedef struct{
    AB_STA ab_sta;  //��ǰAB�ϵ�״̬
    msc_breakpiont_t a_sta_bp;  //��ǰA��λ�õĶϵ���Ϣ
    u16 b_sta_play_time;    //B��ĵ�ǰ����ʱ��
    u16 cur_file_num;   //����AB�ϵ�ʱ��ǰ���ļ���
}AB_BREAKPOINT_VAR;

extern AB_BREAKPOINT_VAR  ab_bp_var;
void func_music_ab_breakpoint_switch(void);
void func_music_ab_breakpoint_clear(void);
#endif

void func_music_switch_file(u8 direction);
void func_music_switch_dir(u8 direction);
void func_music_select_dir(u16 sel_num);
bool func_music_auto_next_device(void);
void func_music_mp3_res_play(u32 addr, u32 len);
bool func_music_filter_switch(u8 rec_type);
void func_music_filter_set(void);
void func_music_insert_device(u8 dev);
void func_music_remove_device(u8 dev);
void func_music_file_navigation(void);

#endif // _FUNC_MUSIC_H
