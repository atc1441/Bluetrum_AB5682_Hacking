#include "include.h"
#include "func.h"

//组件ID
enum{
    //按键
    COMPO_ID_BTN_YEAR_INC = 1,
    COMPO_ID_BTN_MON_INC,
    COMPO_ID_BTN_DAY_INC,
    COMPO_ID_BTN_YEAR_REDU,
    COMPO_ID_BTN_MON_REDU,
    COMPO_ID_BTN_DAY_REDU,
    COMPO_ID_BTN_NO,
    COMPO_ID_BTN_YES,

    //数字
	COMPO_ID_NUM_DISP_YEAR,
	COMPO_ID_NUM_DISP_MON,
	COMPO_ID_NUM_DISP_DAY,
};

typedef struct f_calendar_t_ {
    u16 year;
    u8 mon;
    u8 day;
} f_calendar_t;

#define CALENDAR_BTN_ITEM_CNT    ((int)(sizeof(tbl_calendar_btn_item) / sizeof(tbl_calendar_btn_item[0])))

typedef struct calendar_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
} calendar_btn_item_t;

//按钮item，创建时遍历一下
static const  calendar_btn_item_t tbl_calendar_btn_item[] = {
    {UI_BUF_COMMON_INCREASE_CLICK_BIN,             COMPO_ID_BTN_YEAR_INC,         62,     97},
    {UI_BUF_COMMON_INCREASE_CLICK_BIN,             COMPO_ID_BTN_MON_INC,          151,    97},
    {UI_BUF_COMMON_INCREASE_CLICK_BIN,             COMPO_ID_BTN_DAY_INC,          254,    97},
    {UI_BUF_COMMON_REDUCE_CLICK_BIN,               COMPO_ID_BTN_YEAR_REDU,        62,     236},
    {UI_BUF_COMMON_REDUCE_CLICK_BIN,               COMPO_ID_BTN_MON_REDU,         151,    236},
    {UI_BUF_COMMON_REDUCE_CLICK_BIN,               COMPO_ID_BTN_DAY_REDU,         254,    236},
    {UI_BUF_COMMON_NO_BIN,                         COMPO_ID_BTN_NO,               62,     320},
    {UI_BUF_ALARM_CLOCK_YES_BIN,                   COMPO_ID_BTN_YES,              254,    320},
};

typedef struct calendar_num_item_t_ {
    u32 res_addr;
    int num_cnt;
    u16 num_id;
    int val;
    s16 x;
    s16 y;
    bool zfill_en;
    bool visible_en;
} calendar_num_item_t;

#define CALENDAR_NUM_ITEM_CNT                   ((int)(sizeof(tbl_calendar_num_item) / sizeof(tbl_calendar_num_item[0])))

//搞个数字item，创建时遍历一下
static const calendar_num_item_t tbl_calendar_num_item[] = {
    /*   res_addr,                           num_cnt,        num_id,                val,   x,     y,  zfill_en, visible_en*/
    {UI_BUF_COMMON_NUM_16_24_BIN,               4,       COMPO_ID_NUM_DISP_YEAR,     0,    62,   167,     true,   true},
    {UI_BUF_COMMON_NUM_16_24_BIN,               2,       COMPO_ID_NUM_DISP_MON,      0,   152,   167,     true,   true},
    {UI_BUF_COMMON_NUM_16_24_BIN,               2,       COMPO_ID_NUM_DISP_DAY,      0,   252,   167,     true,   true},
};

//日期设置页面
compo_form_t *func_calender_form_create(void)
{
      //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //创建文本
    compo_textbox_t *txt = compo_textbox_create(frm, 6);
    compo_textbox_set_pos(txt, 80, 34);
    compo_textbox_set(txt, "修改日期");
    compo_textbox_set_visible(txt, true);

    //创建按钮
    compo_button_t *btn;
    for (u8 idx_btn = 0; idx_btn < CALENDAR_BTN_ITEM_CNT; idx_btn++) {
        btn = compo_button_create_by_image(frm, tbl_calendar_btn_item[idx_btn].res_addr);
        compo_setid(btn, tbl_calendar_btn_item[idx_btn].btn_id);
        compo_button_set_pos(btn, tbl_calendar_btn_item[idx_btn].x, tbl_calendar_btn_item[idx_btn].y);
    }

    //创建数字
    compo_number_t *num;
    u16 year = sys_cb.year;
    u8  mon  = sys_cb.mon;
    u8  day  = sys_cb.day;
    for (u8 idx = 0; idx < CALENDAR_NUM_ITEM_CNT; idx++) {
        num = compo_number_create(frm, tbl_calendar_num_item[idx].res_addr, tbl_calendar_num_item[idx].num_cnt);
        compo_setid(num, tbl_calendar_num_item[idx].num_id);
        compo_number_set_pos(num, tbl_calendar_num_item[idx].x, tbl_calendar_num_item[idx].y);
        compo_number_set_zfill(num, tbl_calendar_num_item[idx].zfill_en);
        compo_number_set_visible(num, tbl_calendar_num_item[idx].visible_en);

        if (tbl_calendar_num_item[idx].num_id ==  COMPO_ID_NUM_DISP_YEAR) {
            compo_number_set(num, year);
        } else if (tbl_calendar_num_item[idx].num_id == COMPO_ID_NUM_DISP_MON) {
            compo_number_set(num, mon);
        } else if (tbl_calendar_num_item[idx].num_id == COMPO_ID_NUM_DISP_DAY) {
            compo_number_set(num, day);
        }
    }

    return frm;
}

//日历功能事件处理
static void func_calendar_process(void)
{
    func_process();
}

//单击按钮
static void func_calendar_button_click(void)
{
    int id = compo_get_button_id();
    u16 year;
    u8 mon;
    u8 day;

    f_calendar_t *time = (f_calendar_t *)func_cb.f_cb;
    if(time->year == 0) {
         year = sys_cb.year;
    }else{
         year = time->year;
    }

    if(time->mon == 0) {
         mon = sys_cb.mon;
    }else{
         mon = time->mon;
    }

    if(time->day == 0) {
         day = sys_cb.day;
    }else{
         day = time->day;
    }

    //获取数字组件的地址
    compo_number_t *num_year  = compo_getobj_byid(COMPO_ID_NUM_DISP_YEAR);
    compo_number_t *num_mon   = compo_getobj_byid(COMPO_ID_NUM_DISP_MON);
    compo_number_t *num_day   = compo_getobj_byid(COMPO_ID_NUM_DISP_DAY);

    switch (id) {
        case COMPO_ID_BTN_YEAR_INC:
            if(time->year < 9999 && year < 9999) {
                year++;
            }
            break;

        case COMPO_ID_BTN_MON_INC:
            if(time->mon < 12 && mon < 12) {
                mon++;
            }
            break;

        case COMPO_ID_BTN_DAY_INC:
            if(time->day < 31 && day < 31) {
                day++;
            }
            break;

        case COMPO_ID_BTN_YEAR_REDU:
            if( time->year >0 || year > 0) {
                year--;
                if(year == 0) {
                year = 9999;
                }
            }
            break;

        case COMPO_ID_BTN_MON_REDU:
            if(time->mon >0 || mon > 0) {
                mon--;
                if(mon == 0) {
                mon = 12;
                }
            }
            break;

        case COMPO_ID_BTN_DAY_REDU:
            if(time->day >0 || day > 0) {
                day--;
                if(day == 0) {
                day = 31;
                }
            }
            break;

        case COMPO_ID_BTN_NO:
            time->year = time->mon = time->day = 0;
            if(func_cb.last == FUNC_SETTING) {
                func_cb.sta = FUNC_SETTING;

            }else {
                func_cb.sta = FUNC_MENU;
            }
            break;

        case COMPO_ID_BTN_YES:
            sys_cb.year = time->year;
            sys_cb.mon  = time->mon;
            sys_cb.day  = time->day;
            time->year = time->mon = time->day = 0;
            if(func_cb.last == FUNC_SETTING) {
                func_cb.sta = FUNC_SETTING;
            }else {
            func_cb.sta = FUNC_MENU;
            }
            break;

        default:
            break;
        }

        time->year = year;
        time->mon  = mon;
        time->day  = day;

        compo_number_set(num_year,  time->year);
        compo_number_set_visible(num_year, true);
        compo_number_set(num_mon,   time->mon);
        compo_number_set_visible(num_mon, true);

        compo_number_set(num_day,   time->day);
        compo_number_set_visible(num_day, true);
}

//日期调整功能消息处理
static void func_calendar_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        func_calendar_button_click();
        break;

    case MSG_CTP_SHORT_RIGHT:
        if(func_cb.last == FUNC_SETTING || func_cb.last == FUNC_CLOCK) {
            func_switch_to(FUNC_CLOCK, FUNC_SWITCH_LR_ZOOM_RIGHT);
        } else {
            func_switching_to_menu();
        }
        break;

    case MSG_QDEC_FORWARD:
    case MSG_QDEC_BACKWARD:
        break;

    default:
        func_message(msg);
        break;
    }
}


//进入日历功能
static void func_calendar_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_calendar_t));
    func_cb.frm_main = func_calender_form_create();
}

//退出日历功能
static void func_calendar_exit(void)
{
    func_cb.last = FUNC_CALENDAER;
}

//日历功能
void func_calendar(void)
{
    printf("%s\n", __func__);
    func_calendar_enter();
    while (func_cb.sta == FUNC_CALENDAER) {
        func_calendar_process();
        func_calendar_message(msg_dequeue());
    }
    func_calendar_exit();
}

