#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define CALL_LIST_CNT                       ((int)(sizeof(tbl_call_list) / sizeof(tbl_call_list[0])))

enum {
    COMPO_ID_LISTBOX = 1,
};

typedef struct f_call_list_t_ {
    compo_listbox_t *listbox;

} f_call_list_t;

static compo_listbox_item_t tbl_call_list[] = {
    {STR_CALL_RECENT_ONE},
    {STR_CALL_RECENT_TWS},
    {STR_CALL_RECENT_THR},
    {STR_CALL_RECENT_FOUR},
    {STR_CALL_RECENT_FIVE},
    {STR_CALL_RECENT_SIX},
    {STR_CALL_RECENT_SEV},
};

//创建通话记录窗体
compo_form_t *func_call_sub_record_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_CALL_RECENT]);

    //新建菜单列表
    compo_listbox_t *listbox = compo_listbox_create(frm, COMPO_LISTBOX_STYLE_TITLE);
    compo_listbox_set(listbox, tbl_call_list, CALL_LIST_CNT);
    compo_listbox_set_bgimg(listbox, UI_BUF_COMMON_BG_BIN);
    compo_setid(listbox, COMPO_ID_LISTBOX);

    u8 set_idx = sys_cb.set_idx;
    if (set_idx < 1) {
        set_idx = 1;
    }
    compo_listbox_set_focus_byidx(listbox, set_idx);
    compo_listbox_update(listbox);

    return frm;
}

//点进图标进入应用
void func_call_sub_record_icon_click(void)
{
    int icon_idx;
    f_call_list_t *f_call = (f_call_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_call->listbox;
    u8 func_sta;

    icon_idx = compo_listbox_select(listbox, ctp_get_sxy());
    if (icon_idx < 0 || icon_idx >= CALL_LIST_CNT) {
        return;
    }

    //根据图标索引获取应用ID
    func_sta = tbl_call_list[icon_idx].func_sta;
    //切入应用
    if (func_sta > 0) {
        compo_form_t *frm = func_create_form(func_sta);
        func_switching(FUNC_SWITCH_ZOOM_ENTER | FUNC_SWITCH_AUTO, listbox->sel_icon);
        compo_form_destroy(frm);
        func_cb.sta = func_sta;
    }
}

//通话记录功能事件处理
static void func_set_sub_record_list_process(void)
{
    f_call_list_t *f_call = (f_call_list_t *)func_cb.f_cb;
    compo_listbox_move(f_call->listbox);
    func_process();
}

//通话记录功能消息处理
static void func_set_sub_record_list_message(size_msg_t msg)
{
    f_call_list_t *f_call = (f_call_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_call->listbox;

    if (compo_listbox_message(listbox, msg)) {
        return;                                         //处理列表框信息
    }
    switch (msg) {
    case MSG_CTP_CLICK:
       // func_set_sub_language_list_icon_click();                //单击图标
        break;

    case MSG_CTP_SHORT_RIGHT:
        //右滑缓慢退出任务
        func_switching_to_menu();
        break;

    case MSG_CTP_LONG:
        break;

    case KU_DELAY_BACK:
        if (tick_check_expire(func_cb.enter_tick, TICK_IGNORE_KEY)) {

        }
        break;

    default:
       // func_set_sub_message(msg);
        break;
    }
}

//进入通话记录功能
static void func_call_sub_record_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_call_list_t));
    func_cb.frm_main = func_call_sub_record_form_create();

    f_call_list_t *f_call = (f_call_list_t *)func_cb.f_cb;
    f_call->listbox = compo_getobj_byid(COMPO_ID_LISTBOX);
    compo_listbox_t *listbox = f_call->listbox;
    if (listbox->type != COMPO_TYPE_LISTBOX) {
        halt(HALT_GUI_COMPO_LISTBOX_TYPE);
    }
    listbox->mcb = func_zalloc(sizeof(compo_listbox_move_cb_t));        //建立移动控制块，退出时需要释放
    compo_listbox_move_init(listbox);
    func_cb.enter_tick = tick_get();
}

//退出通话记录功能
static void func_call_sub_record_exit(void)
{
    f_call_list_t *f_call = (f_call_list_t *)func_cb.f_cb;
    compo_listbox_t *listbox = f_call->listbox;
    func_free(listbox->mcb);                                            //释放移动控制块
    func_cb.last = FUNC_CALL_SUB_RECORD;
}

//通话记录功能
void func_call_sub_record(void)
{
    printf("%s\n", __func__);
    func_call_sub_record_enter();
    while (func_cb.sta == FUNC_CALL_SUB_RECORD) {
        func_set_sub_record_list_process();
        func_set_sub_record_list_message(msg_dequeue());
    }
    func_call_sub_record_exit();
}
