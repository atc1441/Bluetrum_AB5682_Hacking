#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_sport_sub_run_t_ {

} f_sport_sub_run_t;

//创建室内跑步窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_sport_sub_run_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);
    compo_form_add_image(frm, UI_BUF_SPORT_BEFORE_EXERCISE_TIME_BG_BIN, 160, 160);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_INDOOR_RUN]);

	//创建文本
    compo_textbox_t *txt = compo_textbox_create(frm, 2);
    compo_textbox_set_location(txt, 45, 180, 80, 40);
    compo_textbox_set(txt, "时间");

    compo_textbox_t *txt2 = compo_textbox_create(frm, 3);
    compo_textbox_set_location(txt2, 45, 210, 140, 40);
    compo_textbox_set(txt2, "30分钟");

    return frm;
}

//室内跑步功能事件处理
static void func_sport_sub_run_process(void)
{
    func_process();
}

//室内跑步功能消息处理
static void func_sport_sub_run_message(size_msg_t msg)
{
    compo_form_t *frm = NULL;
    bool res = false;

    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    case MSG_QDEC_FORWARD:
    case MSG_QDEC_BACKWARD:
        break;

    case KU_BACK:
    case MSG_CTP_SHORT_RIGHT:

        frm = func_create_form(FUNC_SPORT);
        res = func_switching(FUNC_SWITCH_LR_ZOOM_RIGHT,NULL);
        compo_form_destroy(frm);             //切换完成或取消，销毁窗体
        if (res) {
            func_cb.sta = FUNC_SPORT;
        }
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入室内跑步功能
static void func_sport_sub_run_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_sport_sub_run_t));
    func_cb.frm_main = func_sport_sub_run_form_create();
}

//退出室内跑步功能
static void func_sport_sub_run_exit(void)
{
    func_cb.last = FUNC_SPORT_SUB_RUN;
}

//室内跑步功能
void func_sport_sub_run(void)
{
    printf("%s\n", __func__);
    func_sport_sub_run_enter();
    while (func_cb.sta == FUNC_SPORT_SUB_RUN) {
        func_sport_sub_run_process();
        func_sport_sub_run_message(msg_dequeue());
    }
    func_sport_sub_run_exit();
}
