#include "include.h"
#include "func.h"
#include "func_clock.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define DIALPLATE_NUM           (sizeof(dialplate_info) / sizeof(u32))

//表盘资源结构体8bytes
typedef struct __attribute__((packed)) dp_header_t_ {
    u16 sig;                                //表盘头              2bytes
    u16 ver;                                //版本号              2bytes
    u16 num;                                //控件个数            2bytes
    u32 size;                               //总大小              4bytes
} dp_header_t;

//各部件结构体信息头16bytes
typedef struct dp_res_t_ {
    u32 res_addr;                           //资源相对bin的偏移   4bytes
    u8 res_type;                            //资源类型            1byte
    u8 bond_type;                           //资源绑定类型        1byte
    u8 res_num;                             //资源图片数量        1byte
    u8 rsv;                                 //保留位              1bytes
    s16 x;                                  //x坐标               2bytes
    s16 y;                                  //y坐标               2bytes
    s32 param1;                             //参数                8bytes
    s32 param2;                             //参数                8bytes
} dp_res_t;

const u32 dialplate_info[] = {
    UI_BUF_DIALPLATE_1_BIN,
};

//表盘快捷按钮编号表
const u8 quick_btn_tbl[] =
{
    FUNC_NULL,
    FUNC_HEARTRATE,
    FUNC_BT,
    FUNC_ALARM_CLOCK,
    FUNC_BLOOD_OXYGEN,
    FUNC_BLOODSUGAR,
    FUNC_BLOOD_PRESSURE,
    FUNC_BREATHE,
    FUNC_TIMER,
    FUNC_CAMERA,
    FUNC_TIMER,
    FUNC_SLEEP,
    FUNC_STOPWATCH,
    FUNC_WEATHER,
    FUNC_GAME,
    FUNC_STYLE,
    FUNC_ALTITUDE,
    FUNC_MAP,
    FUNC_MESSAGE,
    FUNC_SCAN,
    FUNC_VOICE,
    FUNC_ALIPAY,
    FUNC_COMPASS,
    FUNC_ADDRESS_BOOK,
    FUNC_SPORT,
    FUNC_CALL,
    FUNC_FINDPHONE,
    FUNC_CALENDAER,
    FUNC_ACTIVITY,
    FUNC_FLASHLIGHT,
    FUNC_SETTING,
};


int compo_get_animation_id(void);
void compo_animation_manual_next(compo_animation_t *animation);
void func_switch_to(u8 sta, u16 switch_mode);

//单击按钮
static void func_clock_button_click(void)
{
    u16 btn_id = compo_get_button_id();
    u16 animation_id = compo_get_animation_id();
    if (btn_id) {
        func_switch_to(quick_btn_tbl[btn_id], FUNC_SWITCH_LR_ZOOM_LEFT | FUNC_SWITCH_AUTO);
    } else if (animation_id){
        compo_animation_t *animation = compo_getobj_byid(animation_id);
        compo_animation_manual_next(animation);
    }
}

//时针
static void func_clock_pointer_create(compo_form_t *frm, dp_res_t *dp_res, u32 res_addr)
{
    TRACE("DP_TYPE_POINTER:%d, x:%d, y:%x, angle:%x\n", dp_res->bond_type, dp_res->x, dp_res->y, dp_res->param2);
    s16 pivot_x = dp_res->param1 & 0xff;
    s16 pivot_y = dp_res->param1 >> 16;
    compo_datetime_t *pointer = compo_datetime_create(frm, res_addr);
    compo_bonddata(pointer, dp_res->bond_type);
    compo_datetime_set_pos(pointer, dp_res->x, dp_res->y);
    compo_datetime_set_center(pointer, pivot_x, pivot_y);
    compo_datetime_set_start_angle(pointer, dp_res->param2);
}

//图像
static void func_clock_image_create(compo_form_t *frm, dp_res_t *dp_res, u32 res_addr)
{
    TRACE("DP_TYPE_IMAGE:%d, res_addr:%x, x:%d, y:%d\n", dp_res->bond_type, dp_res->res_addr, dp_res->x, dp_res->y);
    switch (dp_res->bond_type) {
        case COMPO_BOND_IMAGE_STATIC:
            compo_form_add_image(frm, res_addr, dp_res->x, dp_res->y);
            break;

        case COMPO_BOND_IMAGE_CLICK:
            {
                compo_animation_t *animation = compo_animation_create(frm, res_addr);
                compo_animation_set_pos(animation, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y);
                compo_animation_set_radix(animation, dp_res->res_num);
                compo_animation_set_interval(animation, 0);
                compo_setid(animation, 1);
            }
            break;

        default:
            break;
    }
}

//文本
static void func_clock_text_create(compo_form_t *frm, dp_res_t *dp_res, u32 res_addr)
{
    u8 index = BYTE0(dp_res->param1);
    TRACE("DP_TYPE_TEXT:%d\n", index);
    compo_textbox_t *txt = compo_textbox_create(frm, 10);
    compo_textbox_set_location(txt, dp_res->x, dp_res->y, 80, 40);
    compo_textbox_set(txt, i18n[index]);
}

//图片/字库数字
static void func_clock_num_create(compo_form_t *frm, dp_res_t *dp_res, u32 res_addr)
{
    u8 use_num = BYTE0(dp_res->param1);
    u8 max_cnt = 0;
    TRACE("DP_TYPE_NUM:%d, x:%d, y:%d, res_num:%d\n", dp_res->bond_type, dp_res->x, dp_res->y, dp_res->res_num);
    if (use_num) {
        switch (dp_res->bond_type) {
            case COMPO_BOND_HOUR_H:
            case COMPO_BOND_MINUTE_H:
            case COMPO_BOND_HOUR_L:
            case COMPO_BOND_MINUTE_L:
            case COMPO_BOND_WEEKDAY:
                max_cnt = 1;
                break;

            default:
                max_cnt = 2;
                break;
        }
        compo_number_t *num;
        num = compo_number_create(frm, res_addr, max_cnt);
        compo_number_set_radix(num, dp_res->res_num);
        compo_number_set_pos(num, dp_res->x, dp_res->y);
        compo_number_set_zfill(num, true);
//        compo_number_set_visible(num, false);
        compo_bonddata(num, dp_res->bond_type);
    } else {
        max_cnt = 2;
        compo_textbox_t *txt = compo_textbox_create(frm, max_cnt);
        compo_textbox_set_location(txt, dp_res->x, dp_res->y, 80, 40);
//        compo_textbox_set_visible(txt, false);
        compo_bonddata(txt, dp_res->bond_type);

    }
}

//动图
static void func_clock_animation_create(compo_form_t *frm, dp_res_t *dp_res, u32 res_addr)
{
    u8 interval = BYTE0(dp_res->param1);
    TRACE("inteval:%d, %d\n", interval, dp_res->param1);
    compo_animation_t *animation = compo_animation_create(frm, res_addr);
    compo_animation_set_pos(animation, dp_res->x, dp_res->y);
    compo_animation_set_radix(animation, dp_res->res_num);
    compo_animation_set_interval(animation, interval);
}

//区域
static void func_clock_area_create(compo_form_t *frm, dp_res_t *dp_res, u32 res_addr)
{
    u8 index = dp_res->param2 & 0xff;
    s16 wid = dp_res->param1 & 0xff;
    s16 hei = dp_res->param1 >> 16;
    TRACE("DP_TYPE_AREA:%d, %d, %d\n", index, wid, hei);
    compo_button_t *btn;
    btn = compo_button_create(frm);
    compo_setid(btn, index);
    compo_button_set_location(btn, dp_res->x, dp_res->y, wid, hei);
}

static u16 func_clock_header_phrase(u32 base_addr)
{
    base_addr = dialplate_info[sys_cb.dialplate_index];
    dp_header_t dp_header;

    os_spiflash_read(&dp_header, base_addr, DP_HEADER);
    TRACE("sig:%x, ver:%d, size:%x, num:%x\n", dp_header.sig, dp_header.ver, dp_header.size, dp_header.num);
	if (dp_header.sig != DP_HEADER_FORMAT) {
		printf("DIALPLATE Format Uncorrect:%x, %x\n", dp_header.sig, DP_HEADER_FORMAT);
		return false;
	}
	return dp_header.num;
}

void func_clock_create(compo_form_t *frm, u32 base_addr, u16 compo_num)
{
    dp_res_t dp_res[compo_num];
	memset(dp_res, 0, sizeof(dp_res));

    for(u16 i=0;i<compo_num;i++) {
        os_spiflash_read(&dp_res[i], base_addr + DP_HEADER + i * DP_RES_HEADER, DP_RES_HEADER);
        u32 res_addr = base_addr + dp_res[i].res_addr;
         switch (dp_res[i].res_type) {
            case DP_TYPE_POINTER:
                func_clock_pointer_create(frm, &dp_res[i], res_addr);
                break;

            case DP_TYPE_IMAGE:
                func_clock_image_create(frm, &dp_res[i], res_addr);
                break;

            case DP_TYPE_TEXT:
                func_clock_text_create(frm, &dp_res[i], res_addr);
                break;

            case DP_TYPE_NUM:
                func_clock_num_create(frm, &dp_res[i], res_addr);
                break;

            case DP_TYPE_ANIMATION:
                func_clock_animation_create(frm, &dp_res[i], res_addr);
                break;

            case DP_TYPE_AREA:
                func_clock_area_create(frm, &dp_res[i], res_addr);
                break;

            default:
                TRACE("HALT_GUI_DIALPLATE_TYPE:%d\n", dp_res[i].res_type);
                halt(HALT_GUI_DIALPLATE_TYPE);
                break;
            }

    }
}

compo_form_t *func_clock_form_create(void)
{
    u32 base_addr = dialplate_info[sys_cb.dialplate_index];
    u16 compo_num = func_clock_header_phrase(base_addr);
    if (!compo_num) {
        halt(HALT_GUI_DIALPLATE_HEAD);
    }

    compo_form_t *frm = compo_form_create(true);
    func_clock_create(frm, base_addr, compo_num);
    return frm;
}


//子功能公共事件处理
void func_clock_sub_process(void)
{
    func_process();                                     //刷新UI
}

//子功能公共消息处理
void func_clock_sub_message(size_msg_t msg)
{
}

//时钟表盘功能事件处理
static void func_clock_process(void)
{
    func_process();                                  //刷新UI
}

static void func_clock_swith(bool dir)
{
    if (dir) {
        sys_cb.dialplate_index++;
        if (sys_cb.dialplate_index > DIALPLATE_NUM - 1) {
            sys_cb.dialplate_index = 0;
        }
    } else {
        if (sys_cb.dialplate_index == 0) {
            sys_cb.dialplate_index = DIALPLATE_NUM - 1;
        } else {
            sys_cb.dialplate_index--;
        }
    }
    printf("dialplate index:%d\n", sys_cb.dialplate_index);
    compo_form_destroy(func_cb.frm_main);
    func_cb.frm_main = func_clock_form_create();
}

//时钟表盘功能消息处理
static void func_clock_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_SHORT_UP:
        func_clock_sub_pullup();                //上拉菜单
        break;

    case MSG_CTP_SHORT_RIGHT:
        func_clock_sub_side();                  //右拉边菜单
        break;

    case MSG_CTP_SHORT_DOWN:
        func_clock_sub_dropdown();              //下拉菜单
        break;

    case MSG_CTP_CLICK:
        func_clock_button_click();
        break;

    case MSG_QDEC_BACKWARD:
        func_clock_swith(false);
        break;

    case MSG_QDEC_FORWARD:
        func_clock_swith(true);
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入时钟表盘功能
static void func_clock_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_clock_t));
    func_cb.frm_main = func_clock_form_create();
}

//退出时钟表盘功能
static void func_clock_exit(void)
{
    func_cb.last = FUNC_CLOCK;
}

//时钟表盘功能
void func_clock(void)
{
    printf("%s\n", __func__);
    func_clock_enter();
    while (func_cb.sta == FUNC_CLOCK) {
        func_clock_process();
        func_clock_message(msg_dequeue());
    }
    func_clock_exit();
}
