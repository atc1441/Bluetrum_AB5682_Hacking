#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_camera_t_ {

} f_camera_t;

//创建相机窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_camera_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);
	compo_form_add_image(frm, UI_BUF_CAMERA_CAMERA_BIN, 160, 162);

	//设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_CAMERA]);

	//新建按钮
	compo_button_t *btn;
    btn = compo_button_create_by_image(frm, UI_BUF_COMMON_BUTTON_BIN);
    compo_button_set_pos(btn, 160, 336);

	//创建文本
	compo_textbox_t *txt_start = compo_textbox_create(frm, 2);
	compo_textbox_set_location(txt_start, 130, 315, 80, 40);
    compo_textbox_set(txt_start, "开始");

    return frm;
}

//相机功能事件处理
static void func_camera_process(void)
{
    func_process();
}

//相机功能消息处理
static void func_camera_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入相机功能
static void func_camera_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_camera_t));
    func_cb.frm_main = func_camera_form_create();
}

//退出相机功能
static void func_camera_exit(void)
{
    func_cb.last = FUNC_CAMERA;
}

//相机功能
void func_camera(void)
{
    printf("%s\n", __func__);
    func_camera_enter();
    while (func_cb.sta == FUNC_CAMERA) {
        func_camera_process();
        func_camera_message(msg_dequeue());
    }
    func_camera_exit();
}
