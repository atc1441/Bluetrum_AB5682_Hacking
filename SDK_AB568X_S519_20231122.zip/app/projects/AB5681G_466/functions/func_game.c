#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_game_t_ {

} f_game_t;

//创建游戏窗体
compo_form_t *func_game_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_GAME]);

	//创建按键
    compo_button_t *btn = compo_button_create_by_image(frm, UI_BUF_ICON_GAME_BIN);
    compo_button_set_pos(btn, 160, 180);


    return frm;
}

//游戏功能事件处理
static void func_game_process(void)
{
    func_process();
}

//游戏功能消息处理
static void func_game_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入游戏功能
static void func_game_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_game_t));
    func_cb.frm_main = func_game_form_create();
}

//退出游戏功能
static void func_game_exit(void)
{
    func_cb.last = FUNC_GAME;
}

//游戏功能
void func_game(void)
{
    printf("%s\n", __func__);
    func_game_enter();
    while (func_cb.sta == FUNC_GAME) {
        func_game_process();
        func_game_message(msg_dequeue());
    }
    func_game_exit();
}
