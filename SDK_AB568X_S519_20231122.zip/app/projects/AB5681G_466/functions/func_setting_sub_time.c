#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_time_t_ {

} f_time_t;

enum{
    //按键
    COMPO_ID_BIN_CUSTOM = 1,
};

//时间设置页面
compo_form_t *func_set_sub_time_form_create(void)
{
    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_SETTING_TIME]);

    //创建按键
    compo_button_t *btn = compo_button_create_by_image(frm,UI_BUF_SETTING_PASSWORD_OPEN_BIN);
    compo_setid(btn, COMPO_ID_BIN_CUSTOM);
    compo_button_set_pos(btn, 280, 240);

    //创建文本
    compo_textbox_t *txt_time = compo_textbox_create(frm, 2);
    compo_textbox_set_location(txt_time, 30, 220, 70, 40);
    compo_textbox_set(txt_time,"日期");


    return frm;
}

//时间设置事件处理
static void func_set_sub_time_process(void)
{
    func_process();
}

//单击按钮
static void func_time_button_click(void)
{
    int id = compo_get_button_id();

    switch (id) {
    case COMPO_ID_BIN_CUSTOM:
        func_cb.sta = FUNC_TIME_SUB_CUSTOM;
        break;

    default:
        break;
    }
}

//时间设置功能消息处理
static void func_set_sub_time_message(size_msg_t msg)
{
    compo_form_t *frm = NULL;
    bool res = false;
    switch (msg) {
    case MSG_CTP_CLICK:
        func_time_button_click();
        break;

    case MSG_CTP_SHORT_RIGHT:
        frm = func_create_form(FUNC_SETTING);
        res = func_switching(FUNC_SWITCH_LR_ZOOM_RIGHT,NULL);
        compo_form_destroy(frm);             //切换完成或取消，销毁窗体
        if (res) {
            func_cb.sta = FUNC_SETTING;
        }
        break;

    case KU_DELAY_BACK:
        break;

    default:
        break;
    }
}

//进入时间设置功能
static void func_set_sub_time_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_time_t));
    func_cb.frm_main = func_set_sub_time_form_create();
}

//退出时间设置功能
static void func_set_sub_time_exit(void)
{
    func_cb.last = FUNC_SET_SUB_TIME;
}

//时间设置功能
void func_set_sub_time(void)
{
    printf("%s\n", __func__);
    func_set_sub_time_enter();
    while (func_cb.sta == FUNC_SET_SUB_TIME) {
        func_set_sub_time_process();
        func_set_sub_time_message(msg_dequeue());
    }
    func_set_sub_time_exit();
}
