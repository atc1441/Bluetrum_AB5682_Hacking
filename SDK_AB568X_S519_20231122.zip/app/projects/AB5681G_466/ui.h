//该头文件由软件自动生成，请勿随意修改！
#ifndef _UI_H
#define _UI_H

#define UI_BUF_FONT_BIN                            0x100000
#define UI_LEN_FONT_BIN                            0x1b9753

#define UI_BUF_ALARM_CLOCK_ADD_BIN                 0x2b9753
#define UI_LEN_ALARM_CLOCK_ADD_BIN                 0xcb7

#define UI_BUF_ALARM_CLOCK_ADD_CLICK_BIN           0x2ba40a
#define UI_LEN_ALARM_CLOCK_ADD_CLICK_BIN           0xcac

#define UI_BUF_ALARM_CLOCK_CONTINUE_BIN            0x2bb0b6
#define UI_LEN_ALARM_CLOCK_CONTINUE_BIN            0xc73

#define UI_BUF_ALARM_CLOCK_CONTINUE_CLICK_BIN      0x2bbd29
#define UI_LEN_ALARM_CLOCK_CONTINUE_CLICK_BIN      0xc73

#define UI_BUF_ALARM_CLOCK_DELETE_BIN              0x2bc99c
#define UI_LEN_ALARM_CLOCK_DELETE_BIN              0x1212

#define UI_BUF_ALARM_CLOCK_DELETE_CLICK_BIN        0x2bdbae
#define UI_LEN_ALARM_CLOCK_DELETE_CLICK_BIN        0x118f

#define UI_BUF_ALARM_CLOCK_NUM_BIN                 0x2bed3d
#define UI_LEN_ALARM_CLOCK_NUM_BIN                 0x1560

#define UI_BUF_ALARM_CLOCK_OPEN_BIN                0x2c029d
#define UI_LEN_ALARM_CLOCK_OPEN_BIN                0x2cd

#define UI_BUF_ALARM_CLOCK_SELECT1_BIN             0x2c056a
#define UI_LEN_ALARM_CLOCK_SELECT1_BIN             0x5e5

#define UI_BUF_ALARM_CLOCK_SELECT1_ON_BIN          0x2c0b4f
#define UI_LEN_ALARM_CLOCK_SELECT1_ON_BIN          0x552

#define UI_BUF_ALARM_CLOCK_YES_BIN                 0x2c10a1
#define UI_LEN_ALARM_CLOCK_YES_BIN                 0xd2d

#define UI_BUF_ALARM_CLOCK_YES_CLICK_BIN           0x2c1dce
#define UI_LEN_ALARM_CLOCK_YES_CLICK_BIN           0xd1c

#define UI_BUF_ALIPAY_BG1_BIN                      0x2c2aea
#define UI_LEN_ALIPAY_BG1_BIN                      0x228a

#define UI_BUF_ALIPAY_BG2_BIN                      0x2c4d74
#define UI_LEN_ALIPAY_BG2_BIN                      0x9a2

#define UI_BUF_ALIPAY_COMPLETE_BIN                 0x2c5716
#define UI_LEN_ALIPAY_COMPLETE_BIN                 0x7f9

#define UI_BUF_ALIPAY_LOGO_BIN                     0x2c5f0f
#define UI_LEN_ALIPAY_LOGO_BIN                     0xada

#define UI_BUF_BLOOD_OXYGEN_BLOOD_OXYGEN_BIN       0x2c69e9
#define UI_LEN_BLOOD_OXYGEN_BLOOD_OXYGEN_BIN       0x1505

#define UI_BUF_BLOOD_OXYGEN_EXPLAIN_BIN            0x2c7eee
#define UI_LEN_BLOOD_OXYGEN_EXPLAIN_BIN            0x102b

#define UI_BUF_BREATHE_BREATHE_BIN                 0x2c8f19
#define UI_LEN_BREATHE_BREATHE_BIN                 0x83f2

#define UI_BUF_BREATHE_MODE_BIN                    0x2d130b
#define UI_LEN_BREATHE_MODE_BIN                    0xa9d

#define UI_BUF_BREATHE_MODE_CLICK_BIN              0x2d1da8
#define UI_LEN_BREATHE_MODE_CLICK_BIN              0x98e

#define UI_BUF_BREATHE_TIME_BIN                    0x2d2736
#define UI_LEN_BREATHE_TIME_BIN                    0x855

#define UI_BUF_BREATHE_TIME_CLICK_BIN              0x2d2f8b
#define UI_LEN_BREATHE_TIME_CLICK_BIN              0x737

#define UI_BUF_CALCULATOR_0_CLICK_BIN              0x2d36c2
#define UI_LEN_CALCULATOR_0_CLICK_BIN              0x886

#define UI_BUF_CALCULATOR_1_CLICK_BIN              0x2d3f48
#define UI_LEN_CALCULATOR_1_CLICK_BIN              0x707

#define UI_BUF_CALCULATOR_2_CLICK_BIN              0x2d464f
#define UI_LEN_CALCULATOR_2_CLICK_BIN              0x738

#define UI_BUF_CALCULATOR_3_CLICK_BIN              0x2d4d87
#define UI_LEN_CALCULATOR_3_CLICK_BIN              0x791

#define UI_BUF_CALCULATOR_4_CLICK_BIN              0x2d5518
#define UI_LEN_CALCULATOR_4_CLICK_BIN              0x77c

#define UI_BUF_CALCULATOR_5_CLICK_BIN              0x2d5c94
#define UI_LEN_CALCULATOR_5_CLICK_BIN              0x773

#define UI_BUF_CALCULATOR_6_CLICK_BIN              0x2d6407
#define UI_LEN_CALCULATOR_6_CLICK_BIN              0x831

#define UI_BUF_CALCULATOR_7_CLICK_BIN              0x2d6c38
#define UI_LEN_CALCULATOR_7_CLICK_BIN              0x6ed

#define UI_BUF_CALCULATOR_8_CLICK_BIN              0x2d7325
#define UI_LEN_CALCULATOR_8_CLICK_BIN              0x88b

#define UI_BUF_CALCULATOR_9_CLICK_BIN              0x2d7bb0
#define UI_LEN_CALCULATOR_9_CLICK_BIN              0x83b

#define UI_BUF_CALCULATOR_ADD_CLICK_BIN            0x2d83eb
#define UI_LEN_CALCULATOR_ADD_CLICK_BIN            0x6bf

#define UI_BUF_CALCULATOR_BG_BIN                   0x2d8aaa
#define UI_LEN_CALCULATOR_BG_BIN                   0x6ab2

#define UI_BUF_CALCULATOR_CE_CLICK_BIN             0x2df55c
#define UI_LEN_CALCULATOR_CE_CLICK_BIN             0x885

#define UI_BUF_CALCULATOR_C_CLICK_BIN              0x2dfde1
#define UI_LEN_CALCULATOR_C_CLICK_BIN              0x6ea

#define UI_BUF_CALCULATOR_DEL_CLICK_BIN            0x2e04cb
#define UI_LEN_CALCULATOR_DEL_CLICK_BIN            0x8ef

#define UI_BUF_CALCULATOR_DIVIDED_CLICK_BIN        0x2e0dba
#define UI_LEN_CALCULATOR_DIVIDED_CLICK_BIN        0x653

#define UI_BUF_CALCULATOR_EQUAL_CLICK_BIN          0x2e140d
#define UI_LEN_CALCULATOR_EQUAL_CLICK_BIN          0x5d7

#define UI_BUF_CALCULATOR_MINUS_CLICK_BIN          0x2e19e4
#define UI_LEN_CALCULATOR_MINUS_CLICK_BIN          0x846

#define UI_BUF_CALCULATOR_MULTIPLY_CLICK_BIN       0x2e222a
#define UI_LEN_CALCULATOR_MULTIPLY_CLICK_BIN       0x7e4

#define UI_BUF_CALCULATOR_POINT_CLICK_BIN          0x2e2a0e
#define UI_LEN_CALCULATOR_POINT_CLICK_BIN          0x5fc

#define UI_BUF_CALCULATOR_REDUCE_CLICK_BIN         0x2e300a
#define UI_LEN_CALCULATOR_REDUCE_CLICK_BIN         0x5c3

#define UI_BUF_CALL_0_CLICK_BIN                    0x2e35cd
#define UI_LEN_CALL_0_CLICK_BIN                    0x8af

#define UI_BUF_CALL_7_CLICK_BIN                    0x2e3e7c
#define UI_LEN_CALL_7_CLICK_BIN                    0x7b8

#define UI_BUF_CALL_9_CLICK_BIN                    0x2e4634
#define UI_LEN_CALL_9_CLICK_BIN                    0xa23

#define UI_BUF_CALL_ANSWER_BIN                     0x2e5057
#define UI_LEN_CALL_ANSWER_BIN                     0xd78

#define UI_BUF_CALL_ANSWER_CLICK_BIN               0x2e5dcf
#define UI_LEN_CALL_ANSWER_CLICK_BIN               0xcfe

#define UI_BUF_CALL_BG1_BIN                        0x2e6acd
#define UI_LEN_CALL_BG1_BIN                        0x45d3

#define UI_BUF_CALL_CALL_CLICK_BIN                 0x2eb0a0
#define UI_LEN_CALL_CALL_CLICK_BIN                 0x5d5

#define UI_BUF_CALL_DEL_CLICK_BIN                  0x2eb675
#define UI_LEN_CALL_DEL_CLICK_BIN                  0x781

#define UI_BUF_CALL_MES_BIN                        0x2ebdf6
#define UI_LEN_CALL_MES_BIN                        0x351

#define UI_BUF_CALL_MES_CLICK_BIN                  0x2ec147
#define UI_LEN_CALL_MES_CLICK_BIN                  0x351

#define UI_BUF_CALL_MUTE_BIN                       0x2ec498
#define UI_LEN_CALL_MUTE_BIN                       0x87e

#define UI_BUF_CALL_MUTE_CLICK_BIN                 0x2ecd16
#define UI_LEN_CALL_MUTE_CLICK_BIN                 0xb67

#define UI_BUF_CALL_MUTE_ON_BIN                    0x2ed87d
#define UI_LEN_CALL_MUTE_ON_BIN                    0xdc5

#define UI_BUF_CALL_REJECT_BIN                     0x2ee642
#define UI_LEN_CALL_REJECT_BIN                     0xdbc

#define UI_BUF_CALL_REJECT_CLICK_BIN               0x2ef3fe
#define UI_LEN_CALL_REJECT_CLICK_BIN               0xdb9

#define UI_BUF_CAMERA_CAMERA_BIN                   0x2f01b7
#define UI_LEN_CAMERA_CAMERA_BIN                   0x1bd9

#define UI_BUF_CHARGE_CHARGE1_BIN                  0x2f1d90
#define UI_LEN_CHARGE_CHARGE1_BIN                  0x7d8

#define UI_BUF_CHARGE_CHARGE2_BIN                  0x2f2568
#define UI_LEN_CHARGE_CHARGE2_BIN                  0x1240

#define UI_BUF_CHARGE_LOW_POWER_BIN                0x2f37a8
#define UI_LEN_CHARGE_LOW_POWER_BIN                0x1557

#define UI_BUF_COMMON_1_CLICK_BIN                  0x2f4cff
#define UI_LEN_COMMON_1_CLICK_BIN                  0x593

#define UI_BUF_COMMON_2_CLICK_BIN                  0x2f5292
#define UI_LEN_COMMON_2_CLICK_BIN                  0x5cd

#define UI_BUF_COMMON_3_CLICK_BIN                  0x2f585f
#define UI_LEN_COMMON_3_CLICK_BIN                  0x5e2

#define UI_BUF_COMMON_4_CLICK_BIN                  0x2f5e41
#define UI_LEN_COMMON_4_CLICK_BIN                  0x601

#define UI_BUF_COMMON_5_CLICK_BIN                  0x2f6442
#define UI_LEN_COMMON_5_CLICK_BIN                  0x612

#define UI_BUF_COMMON_6_CLICK_BIN                  0x2f6a54
#define UI_LEN_COMMON_6_CLICK_BIN                  0x6d7

#define UI_BUF_COMMON_8_CLICK_BIN                  0x2f712b
#define UI_LEN_COMMON_8_CLICK_BIN                  0x727

#define UI_BUF_COMMON_BG_BIN                       0x2f7852
#define UI_LEN_COMMON_BG_BIN                       0xa07

#define UI_BUF_COMMON_BG1_BIN                      0x2f8259
#define UI_LEN_COMMON_BG1_BIN                      0x323

#define UI_BUF_COMMON_BG2_BIN                      0x2f857c
#define UI_LEN_COMMON_BG2_BIN                      0xa3

#define UI_BUF_COMMON_BUTTON_BIN                   0x2f861f
#define UI_LEN_COMMON_BUTTON_BIN                   0xe00

#define UI_BUF_COMMON_BUTTON_CLICK_BIN             0x2f941f
#define UI_LEN_COMMON_BUTTON_CLICK_BIN             0xe00

#define UI_BUF_COMMON_CLICK_176_176_DIAPHANEITY_38_BIN    0x2fa21f
#define UI_LEN_COMMON_CLICK_176_176_DIAPHANEITY_38_BIN    0x15ae

#define UI_BUF_COMMON_CLICK_80_80_DIAPHANEITY_38_BIN    0x2fb7cd
#define UI_LEN_COMMON_CLICK_80_80_DIAPHANEITY_38_BIN    0x866

#define UI_BUF_COMMON_CLICK_92_92_DIAPHANEITY_38_BIN    0x2fc033
#define UI_LEN_COMMON_CLICK_92_92_DIAPHANEITY_38_BIN    0x999

#define UI_BUF_COMMON_COLON_NUM_16_24_BIN          0x2fc9cc
#define UI_LEN_COMMON_COLON_NUM_16_24_BIN          0xb7

#define UI_BUF_COMMON_COLON_NUM_30_46_BIN          0x2fca83
#define UI_LEN_COMMON_COLON_NUM_30_46_BIN          0x1cd

#define UI_BUF_COMMON_INCREASE_BIN                 0x2fcc50
#define UI_LEN_COMMON_INCREASE_BIN                 0x706

#define UI_BUF_COMMON_INCREASE_CLICK_BIN           0x2fd356
#define UI_LEN_COMMON_INCREASE_CLICK_BIN           0x704

#define UI_BUF_COMMON_NO_BIN                       0x2fda5a
#define UI_LEN_COMMON_NO_BIN                       0xe6b

#define UI_BUF_COMMON_NO_CLICK_BIN                 0x2fe8c5
#define UI_LEN_COMMON_NO_CLICK_BIN                 0xe38

#define UI_BUF_COMMON_NUM_16_24_BIN                0x2ff6fd
#define UI_LEN_COMMON_NUM_16_24_BIN                0x1a0f

#define UI_BUF_COMMON_NUM_24_38_BIN                0x30110c
#define UI_LEN_COMMON_NUM_24_38_BIN                0x2abe

#define UI_BUF_COMMON_NUM_30_46_BIN                0x303bca
#define UI_LEN_COMMON_NUM_30_46_BIN                0x359b

#define UI_BUF_COMMON_NUM_LEFT_18_18_BIN           0x307165
#define UI_LEN_COMMON_NUM_LEFT_18_18_BIN           0x1725

#define UI_BUF_COMMON_NUM_RIGHT_18_18_BIN          0x30888a
#define UI_LEN_COMMON_NUM_RIGHT_18_18_BIN          0x16c6

#define UI_BUF_COMMON_OFF_BIN                      0x309f50
#define UI_LEN_COMMON_OFF_BIN                      0x3ce

#define UI_BUF_COMMON_ON_BIN                       0x30a31e
#define UI_LEN_COMMON_ON_BIN                       0x3a6

#define UI_BUF_COMMON_PAUSE_BIN                    0x30a6c4
#define UI_LEN_COMMON_PAUSE_BIN                    0xc97

#define UI_BUF_COMMON_PAUSE_CLICK_BIN              0x30b35b
#define UI_LEN_COMMON_PAUSE_CLICK_BIN              0xc93

#define UI_BUF_COMMON_PERCENT_BIN                  0x30bfee
#define UI_LEN_COMMON_PERCENT_BIN                  0x763

#define UI_BUF_COMMON_POINT_NUM_16_24_BIN          0x30c751
#define UI_LEN_COMMON_POINT_NUM_16_24_BIN          0x4d

#define UI_BUF_COMMON_POINT_NUM_30_46_BIN          0x30c79e
#define UI_LEN_COMMON_POINT_NUM_30_46_BIN          0xc3

#define UI_BUF_COMMON_REDUCE_BIN                   0x30c861
#define UI_LEN_COMMON_REDUCE_BIN                   0x597

#define UI_BUF_COMMON_REDUCE_CLICK_BIN             0x30cdf8
#define UI_LEN_COMMON_REDUCE_CLICK_BIN             0x594

#define UI_BUF_COMMON_SELECT_BIN                   0x30d38c
#define UI_LEN_COMMON_SELECT_BIN                   0x830

#define UI_BUF_COMMON_SELECT_ON_BIN                0x30dbbc
#define UI_LEN_COMMON_SELECT_ON_BIN                0x651

#define UI_BUF_COMMON_START_BIN                    0x30e20d
#define UI_LEN_COMMON_START_BIN                    0xe7d

#define UI_BUF_COMMON_START_CLICK_BIN              0x30f08a
#define UI_LEN_COMMON_START_CLICK_BIN              0xe01

#define UI_BUF_DIALPLATE_1_BIN                     0x30fe8b
#define UI_LEN_DIALPLATE_1_BIN                     0xdd93

#define UI_BUF_DROPDOWN_CALL_BIN                   0x31dc1e
#define UI_LEN_DROPDOWN_CALL_BIN                   0x9f5

#define UI_BUF_DROPDOWN_CONNECT_BIN                0x31e613
#define UI_LEN_DROPDOWN_CONNECT_BIN                0x357

#define UI_BUF_DROPDOWN_CONNECT_OFF_BIN            0x31e96a
#define UI_LEN_DROPDOWN_CONNECT_OFF_BIN            0x537

#define UI_BUF_DROPDOWN_CONNECT_ON_BIN             0x31eea1
#define UI_LEN_DROPDOWN_CONNECT_ON_BIN             0xbf1

#define UI_BUF_DROPDOWN_CONNECT_PHONE_BIN          0x31fa92
#define UI_LEN_DROPDOWN_CONNECT_PHONE_BIN          0xc4f

#define UI_BUF_DROPDOWN_DISTURB_BIN                0x3206e1
#define UI_LEN_DROPDOWN_DISTURB_BIN                0x9f6

#define UI_BUF_DROPDOWN_DISTURB_OFF_BIN            0x3210d7
#define UI_LEN_DROPDOWN_DISTURB_OFF_BIN            0xb2d

#define UI_BUF_DROPDOWN_DISTURB_ON_BIN             0x321c04
#define UI_LEN_DROPDOWN_DISTURB_ON_BIN             0x9f4

#define UI_BUF_DROPDOWN_FIND_PHONE_BIN             0x3225f8
#define UI_LEN_DROPDOWN_FIND_PHONE_BIN             0xe36

#define UI_BUF_DROPDOWN_FIND_PHONE_OFF_BIN         0x32342e
#define UI_LEN_DROPDOWN_FIND_PHONE_OFF_BIN         0xeba

#define UI_BUF_DROPDOWN_FIND_PHONE_ON_BIN          0x3242e8
#define UI_LEN_DROPDOWN_FIND_PHONE_ON_BIN          0xf08

#define UI_BUF_DROPDOWN_FLASHLIGHT_OFF_BIN         0x3251f0
#define UI_LEN_DROPDOWN_FLASHLIGHT_OFF_BIN         0xc28

#define UI_BUF_DROPDOWN_FLASHLIGHT_ON_BIN          0x325e18
#define UI_LEN_DROPDOWN_FLASHLIGHT_ON_BIN          0xc2e

#define UI_BUF_DROPDOWN_LIGHT_BIN                  0x326a46
#define UI_LEN_DROPDOWN_LIGHT_BIN                  0xd33

#define UI_BUF_DROPDOWN_LIGHT_1_BIN                0x327779
#define UI_LEN_DROPDOWN_LIGHT_1_BIN                0xe5a

#define UI_BUF_DROPDOWN_LIGHT_2_BIN                0x3285d3
#define UI_LEN_DROPDOWN_LIGHT_2_BIN                0xe91

#define UI_BUF_DROPDOWN_MUTE_BIN                   0x329464
#define UI_LEN_DROPDOWN_MUTE_BIN                   0xbde

#define UI_BUF_DROPDOWN_MUTE_OFF_BIN               0x32a042
#define UI_LEN_DROPDOWN_MUTE_OFF_BIN               0xcf3

#define UI_BUF_DROPDOWN_MUTE_ON_BIN                0x32ad35
#define UI_LEN_DROPDOWN_MUTE_ON_BIN                0xd46

#define UI_BUF_DROPDOWN_NUM_22_36_BIN              0x32ba7b
#define UI_LEN_DROPDOWN_NUM_22_36_BIN              0x27dd

#define UI_BUF_DROPDOWN_NUM_22_36_COLON_BIN        0x32e258
#define UI_LEN_DROPDOWN_NUM_22_36_COLON_BIN        0x13b

#define UI_BUF_DROPDOWN_NUM_22_36_DEGREE_BIN       0x32e393
#define UI_LEN_DROPDOWN_NUM_22_36_DEGREE_BIN       0x5c1

#define UI_BUF_DROPDOWN_NUM_22_36_TILDE_BIN        0x32e954
#define UI_LEN_DROPDOWN_NUM_22_36_TILDE_BIN        0x160

#define UI_BUF_DROPDOWN_OVERCAST_BIN               0x32eab4
#define UI_LEN_DROPDOWN_OVERCAST_BIN               0xa6c

#define UI_BUF_DROPDOWN_POWER1_BIN                 0x32f520
#define UI_LEN_DROPDOWN_POWER1_BIN                 0x253

#define UI_BUF_DROPDOWN_POWER2_BIN                 0x32f773
#define UI_LEN_DROPDOWN_POWER2_BIN                 0x322

#define UI_BUF_DROPDOWN_POWER3_BIN                 0x32fa95
#define UI_LEN_DROPDOWN_POWER3_BIN                 0x3f2

#define UI_BUF_DROPDOWN_POWER4_BIN                 0x32fe87
#define UI_LEN_DROPDOWN_POWER4_BIN                 0x4c6

#define UI_BUF_DROPDOWN_POWER5_BIN                 0x33034d
#define UI_LEN_DROPDOWN_POWER5_BIN                 0x5af

#define UI_BUF_DROPDOWN_POWER6_BIN                 0x3308fc
#define UI_LEN_DROPDOWN_POWER6_BIN                 0x2ef

#define UI_BUF_DROPDOWN_POWER_BG_BIN               0x330beb
#define UI_LEN_DROPDOWN_POWER_BG_BIN               0xd17

#define UI_BUF_DROPDOWN_RAIN_BIN                   0x331902
#define UI_LEN_DROPDOWN_RAIN_BIN                   0x14c1

#define UI_BUF_DROPDOWN_SAND_DUST_BIN              0x332dc3
#define UI_LEN_DROPDOWN_SAND_DUST_BIN              0x16a9

#define UI_BUF_DROPDOWN_SCAN_1_BIN                 0x33446c
#define UI_LEN_DROPDOWN_SCAN_1_BIN                 0xbe1

#define UI_BUF_DROPDOWN_SCAN_2_BIN                 0x33504d
#define UI_LEN_DROPDOWN_SCAN_2_BIN                 0xbdb

#define UI_BUF_DROPDOWN_SETTING_BIN                0x335c28
#define UI_LEN_DROPDOWN_SETTING_BIN                0xbe7

#define UI_BUF_DROPDOWN_SMOG_BIN                   0x33680f
#define UI_LEN_DROPDOWN_SMOG_BIN                   0xf46

#define UI_BUF_DROPDOWN_SNOWY_BIN                  0x337755
#define UI_LEN_DROPDOWN_SNOWY_BIN                  0x1b2e

#define UI_BUF_DROPDOWN_SUNNY_BIN                  0x339283
#define UI_LEN_DROPDOWN_SUNNY_BIN                  0x1133

#define UI_BUF_DROPDOWN_WINDY_BIN                  0x33a3b6
#define UI_LEN_DROPDOWN_WINDY_BIN                  0xbbb

#define UI_BUF_HEART_RATE_CHART_BG_BIN             0x33af71
#define UI_LEN_HEART_RATE_CHART_BG_BIN             0x3217

#define UI_BUF_HEART_RATE_DOWN_BIN                 0x33e188
#define UI_LEN_HEART_RATE_DOWN_BIN                 0xed

#define UI_BUF_HEART_RATE_HR_BIN                   0x33e275
#define UI_LEN_HEART_RATE_HR_BIN                   0x21d7

#define UI_BUF_HEART_RATE_HR_BG_BIN                0x34044c
#define UI_LEN_HEART_RATE_HR_BG_BIN                0x11e7

#define UI_BUF_HEART_RATE_UP_BIN                   0x341633
#define UI_LEN_HEART_RATE_UP_BIN                   0xec

#define UI_BUF_ICON_ACTIVITY_BIN                   0x34171f
#define UI_LEN_ICON_ACTIVITY_BIN                   0x1dad

#define UI_BUF_ICON_ADDRESS_BOOK_BIN               0x3434cc
#define UI_LEN_ICON_ADDRESS_BOOK_BIN               0x128f

#define UI_BUF_ICON_ALARM_CLOCK_BIN                0x34475b
#define UI_LEN_ICON_ALARM_CLOCK_BIN                0x1319

#define UI_BUF_ICON_ALIPAY_BIN                     0x345a74
#define UI_LEN_ICON_ALIPAY_BIN                     0x11cd

#define UI_BUF_ICON_ALTITUDE_BIN                   0x346c41
#define UI_LEN_ICON_ALTITUDE_BIN                   0x1523

#define UI_BUF_ICON_BLOODSUGAR_BIN                 0x348164
#define UI_LEN_ICON_BLOODSUGAR_BIN                 0x12b7

#define UI_BUF_ICON_BLOOD_OXYGEN_BIN               0x34941b
#define UI_LEN_ICON_BLOOD_OXYGEN_BIN               0x1608

#define UI_BUF_ICON_BLOOD_PRESSURE_BIN             0x34aa23
#define UI_LEN_ICON_BLOOD_PRESSURE_BIN             0x1284

#define UI_BUF_ICON_BREATHE_BIN                    0x34bca7
#define UI_LEN_ICON_BREATHE_BIN                    0xf54

#define UI_BUF_ICON_CALCULATOR_BIN                 0x34cbfb
#define UI_LEN_ICON_CALCULATOR_BIN                 0x17e2

#define UI_BUF_ICON_CALENDAR_BIN                   0x34e3dd
#define UI_LEN_ICON_CALENDAR_BIN                   0x12ea

#define UI_BUF_ICON_CALL_BIN                       0x34f6c7
#define UI_LEN_ICON_CALL_BIN                       0xec5

#define UI_BUF_ICON_CAMERA_BIN                     0x35058c
#define UI_LEN_ICON_CAMERA_BIN                     0x16f5

#define UI_BUF_ICON_CLOCK_BIN                      0x351c81
#define UI_LEN_ICON_CLOCK_BIN                      0x1160

#define UI_BUF_ICON_CLOCK_BG_BIN                   0x352de1
#define UI_LEN_ICON_CLOCK_BG_BIN                   0xc5c

#define UI_BUF_ICON_CLOCK_H_BIN                    0x353a3d
#define UI_LEN_ICON_CLOCK_H_BIN                    0x10f

#define UI_BUF_ICON_CLOCK_M_BIN                    0x353b4c
#define UI_LEN_ICON_CLOCK_M_BIN                    0x12c

#define UI_BUF_ICON_CLOCK_S_BIN                    0x353c78
#define UI_LEN_ICON_CLOCK_S_BIN                    0xd7

#define UI_BUF_ICON_COMPASS_BIN                    0x353d4f
#define UI_LEN_ICON_COMPASS_BIN                    0x18d0

#define UI_BUF_ICON_CONNECT_PHONE_BIN              0x35561f
#define UI_LEN_ICON_CONNECT_PHONE_BIN              0x119f

#define UI_BUF_ICON_FINDPHONE_BIN                  0x3567be
#define UI_LEN_ICON_FINDPHONE_BIN                  0x14ec

#define UI_BUF_ICON_FLASHLIGHT_BIN                 0x357caa
#define UI_LEN_ICON_FLASHLIGHT_BIN                 0x1357

#define UI_BUF_ICON_GAME_BIN                       0x359001
#define UI_LEN_ICON_GAME_BIN                       0x182d

#define UI_BUF_ICON_HEART_RATE_BIN                 0x35a82e
#define UI_LEN_ICON_HEART_RATE_BIN                 0x126c

#define UI_BUF_ICON_LANGUAGE_BIN                   0x35ba9a
#define UI_LEN_ICON_LANGUAGE_BIN                   0x1b22

#define UI_BUF_ICON_LIGHT_BIN                      0x35d5bc
#define UI_LEN_ICON_LIGHT_BIN                      0x15f0

#define UI_BUF_ICON_MAP_BIN                        0x35ebac
#define UI_LEN_ICON_MAP_BIN                        0x14fe

#define UI_BUF_ICON_MENU_BIN                       0x3600aa
#define UI_LEN_ICON_MENU_BIN                       0xf4e

#define UI_BUF_ICON_MESSAGE_BIN                    0x360ff8
#define UI_LEN_ICON_MESSAGE_BIN                    0xec4

#define UI_BUF_ICON_MUSIC_BIN                      0x361ebc
#define UI_LEN_ICON_MUSIC_BIN                      0x128a

#define UI_BUF_ICON_OFF_BIN                        0x363146
#define UI_LEN_ICON_OFF_BIN                        0x1336

#define UI_BUF_ICON_RESTART_BIN                    0x36447c
#define UI_LEN_ICON_RESTART_BIN                    0x1301

#define UI_BUF_ICON_RESTORE_FACTORY_BIN            0x36577d
#define UI_LEN_ICON_RESTORE_FACTORY_BIN            0x12ce

#define UI_BUF_ICON_SCAN_BIN                       0x366a4b
#define UI_LEN_ICON_SCAN_BIN                       0xfb3

#define UI_BUF_ICON_SETTING_BIN                    0x3679fe
#define UI_LEN_ICON_SETTING_BIN                    0x11b5

#define UI_BUF_ICON_SLEEP_BIN                      0x368bb3
#define UI_LEN_ICON_SLEEP_BIN                      0x105c

#define UI_BUF_ICON_SPORT_BIN                      0x369c0f
#define UI_LEN_ICON_SPORT_BIN                      0x128b

#define UI_BUF_ICON_STEP_BIN                       0x36ae9a
#define UI_LEN_ICON_STEP_BIN                       0x11ba

#define UI_BUF_ICON_STOPWATCH_BIN                  0x36c054
#define UI_LEN_ICON_STOPWATCH_BIN                  0x105e

#define UI_BUF_ICON_TIMER_BIN                      0x36d0b2
#define UI_LEN_ICON_TIMER_BIN                      0x1578

#define UI_BUF_ICON_VOICE_BIN                      0x36e62a
#define UI_LEN_ICON_VOICE_BIN                      0x17c4

#define UI_BUF_ICON_VOLUME_BIN                     0x36fdee
#define UI_LEN_ICON_VOLUME_BIN                     0x1380

#define UI_BUF_ICON_WEATHER_BIN                    0x37116e
#define UI_LEN_ICON_WEATHER_BIN                    0x124d

#define UI_BUF_MUSIC_NEXT_BIN                      0x3723bb
#define UI_LEN_MUSIC_NEXT_BIN                      0x563

#define UI_BUF_MUSIC_NEXT_CLICK_BIN                0x37291e
#define UI_LEN_MUSIC_NEXT_CLICK_BIN                0x8d7

#define UI_BUF_MUSIC_PAUSE_BIN                     0x3731f5
#define UI_LEN_MUSIC_PAUSE_BIN                     0xff4

#define UI_BUF_MUSIC_PAUSE_CLICK_BIN               0x3741e9
#define UI_LEN_MUSIC_PAUSE_CLICK_BIN               0xe3a

#define UI_BUF_MUSIC_PLAY_BIN                      0x375023
#define UI_LEN_MUSIC_PLAY_BIN                      0x11b6

#define UI_BUF_MUSIC_PREV_BIN                      0x3761d9
#define UI_LEN_MUSIC_PREV_BIN                      0x569

#define UI_BUF_MUSIC_PREV_CLICK_BIN                0x376742
#define UI_LEN_MUSIC_PREV_CLICK_BIN                0x8de

#define UI_BUF_MUSIC_VOLUME1_BIN                   0x377020
#define UI_LEN_MUSIC_VOLUME1_BIN                   0x41

#define UI_BUF_MUSIC_VOLUME2_BIN                   0x377061
#define UI_LEN_MUSIC_VOLUME2_BIN                   0x3d

#define UI_BUF_MUSIC_VOLUME3_BIN                   0x37709e
#define UI_LEN_MUSIC_VOLUME3_BIN                   0x7d

#define UI_BUF_MUSIC_VOLUME4_BIN                   0x37711b
#define UI_LEN_MUSIC_VOLUME4_BIN                   0x91

#define UI_BUF_MUSIC_VOLUME5_BIN                   0x3771ac
#define UI_LEN_MUSIC_VOLUME5_BIN                   0x91

#define UI_BUF_MUSIC_VOLUME_BG_BIN                 0x37723d
#define UI_LEN_MUSIC_VOLUME_BG_BIN                 0x5b

#define UI_BUF_MUSIC_VOLUME_DOWN_BIN               0x377298
#define UI_LEN_MUSIC_VOLUME_DOWN_BIN               0x499

#define UI_BUF_MUSIC_VOLUME_DOWN_CLICK_BIN         0x377731
#define UI_LEN_MUSIC_VOLUME_DOWN_CLICK_BIN         0x78b

#define UI_BUF_MUSIC_VOLUME_UP_BIN                 0x377ebc
#define UI_LEN_MUSIC_VOLUME_UP_BIN                 0x520

#define UI_BUF_MUSIC_VOLUME_UP_CLICK_BIN           0x3783dc
#define UI_LEN_MUSIC_VOLUME_UP_CLICK_BIN           0x82e

#define UI_BUF_SETTING_ABOUT_BIN                   0x378c0a
#define UI_LEN_SETTING_ABOUT_BIN                   0x3f5

#define UI_BUF_SETTING_ABOUT_CLICK_BIN             0x378fff
#define UI_LEN_SETTING_ABOUT_CLICK_BIN             0x3f5

#define UI_BUF_SETTING_BREATHING_SCREEN_BIN        0x3793f4
#define UI_LEN_SETTING_BREATHING_SCREEN_BIN        0x56f

#define UI_BUF_SETTING_BREATHING_SCREEN_CLICK_BIN    0x379963
#define UI_LEN_SETTING_BREATHING_SCREEN_CLICK_BIN    0x556

#define UI_BUF_SETTING_CALENDAR_BIN                0x379eb9
#define UI_LEN_SETTING_CALENDAR_BIN                0x416

#define UI_BUF_SETTING_CALENDAR_CLICK_BIN          0x37a2cf
#define UI_LEN_SETTING_CALENDAR_CLICK_BIN          0x41b

#define UI_BUF_SETTING_DISTURB_BIN                 0x37a6ea
#define UI_LEN_SETTING_DISTURB_BIN                 0x429

#define UI_BUF_SETTING_DISTURB_CLICK_BIN           0x37ab13
#define UI_LEN_SETTING_DISTURB_CLICK_BIN           0x418

#define UI_BUF_SETTING_LANGUAGE_BIN                0x37af2b
#define UI_LEN_SETTING_LANGUAGE_BIN                0x535

#define UI_BUF_SETTING_LANGUAGE_CLICK_BIN          0x37b460
#define UI_LEN_SETTING_LANGUAGE_CLICK_BIN          0x51c

#define UI_BUF_SETTING_LIGHT_BIN                   0x37b97c
#define UI_LEN_SETTING_LIGHT_BIN                   0x4ed

#define UI_BUF_SETTING_LIGHT_CLICK_BIN             0x37be69
#define UI_LEN_SETTING_LIGHT_CLICK_BIN             0x4eb

#define UI_BUF_SETTING_OFF_BIN                     0x37c354
#define UI_LEN_SETTING_OFF_BIN                     0x4da

#define UI_BUF_SETTING_OFF_CLICK_BIN               0x37c82e
#define UI_LEN_SETTING_OFF_CLICK_BIN               0x4d5

#define UI_BUF_SETTING_PASSWORD_BIN                0x37cd03
#define UI_LEN_SETTING_PASSWORD_BIN                0x438

#define UI_BUF_SETTING_PASSWORD_CLICK_BIN          0x37d13b
#define UI_LEN_SETTING_PASSWORD_CLICK_BIN          0x432

#define UI_BUF_SETTING_RESTART_BIN                 0x37d56d
#define UI_LEN_SETTING_RESTART_BIN                 0x44f

#define UI_BUF_SETTING_RESTART_CLICK_BIN           0x37d9bc
#define UI_LEN_SETTING_RESTART_CLICK_BIN           0x449

#define UI_BUF_SETTING_RESTORE_FACTORY_BIN         0x37de05
#define UI_LEN_SETTING_RESTORE_FACTORY_BIN         0x48d

#define UI_BUF_SETTING_RESTORE_FACTORY_CLICK_BIN    0x37e292
#define UI_LEN_SETTING_RESTORE_FACTORY_CLICK_BIN    0x483

#define UI_BUF_SETTING_SOUND_AND_VIBRATION_BIN     0x37e715
#define UI_LEN_SETTING_SOUND_AND_VIBRATION_BIN     0x414

#define UI_BUF_SETTING_SOUND_AND_VIBRATION_CLICK_BIN    0x37eb29
#define UI_LEN_SETTING_SOUND_AND_VIBRATION_CLICK_BIN    0x40d

#define UI_BUF_SETTING_TIME_BIN                    0x37ef36
#define UI_LEN_SETTING_TIME_BIN                    0x400

#define UI_BUF_SETTING_TIME_CLICK_BIN              0x37f336
#define UI_LEN_SETTING_TIME_CLICK_BIN              0x3ff

#define UI_BUF_SETTING_WRIST_BIN                   0x37f735
#define UI_LEN_SETTING_WRIST_BIN                   0x46f

#define UI_BUF_SETTING_WRIST_CLICK_BIN             0x37fba4
#define UI_LEN_SETTING_WRIST_CLICK_BIN             0x456

#define UI_BUF_SETTING_LIGHT_LIGHT_BIN             0x37fffa
#define UI_LEN_SETTING_LIGHT_LIGHT_BIN             0x16d1

#define UI_BUF_SETTING_PASSWORD_7_CLICK_BIN        0x3816cb
#define UI_LEN_SETTING_PASSWORD_7_CLICK_BIN        0x56e

#define UI_BUF_SETTING_PASSWORD_9_CLICK_BIN        0x381c39
#define UI_LEN_SETTING_PASSWORD_9_CLICK_BIN        0x715

#define UI_BUF_SETTING_PASSWORD_BG_BIN             0x38234e
#define UI_LEN_SETTING_PASSWORD_BG_BIN             0x5214

#define UI_BUF_SETTING_PASSWORD_BG_NUM_BIN         0x387562
#define UI_LEN_SETTING_PASSWORD_BG_NUM_BIN         0x848

#define UI_BUF_SETTING_PASSWORD_DEL_CLICK_BIN      0x387daa
#define UI_LEN_SETTING_PASSWORD_DEL_CLICK_BIN      0x78c

#define UI_BUF_SETTING_PASSWORD_FRAME_755_BIN      0x388536
#define UI_LEN_SETTING_PASSWORD_FRAME_755_BIN      0x6d1

#define UI_BUF_SETTING_PASSWORD_NUM_BIN            0x388c07
#define UI_LEN_SETTING_PASSWORD_NUM_BIN            0x22d

#define UI_BUF_SETTING_PASSWORD_OPEN_BIN           0x388e34
#define UI_LEN_SETTING_PASSWORD_OPEN_BIN           0x223

#define UI_BUF_SLEEP_CHART_BG_BIN                  0x389057
#define UI_LEN_SLEEP_CHART_BG_BIN                  0x2ecc

#define UI_BUF_SLEEP_DEEP_ALEEP_BIN                0x38bf23
#define UI_LEN_SLEEP_DEEP_ALEEP_BIN                0x433

#define UI_BUF_SLEEP_LIGHT_SLEEP_BIN               0x38c356
#define UI_LEN_SLEEP_LIGHT_SLEEP_BIN               0x39d

#define UI_BUF_SLEEP_SLEEP_BIN                     0x38c6f3
#define UI_LEN_SLEEP_SLEEP_BIN                     0xb78

#define UI_BUF_SPORT_BEFORE_EXERCISE_BG_BIN        0x38d26b
#define UI_LEN_SPORT_BEFORE_EXERCISE_BG_BIN        0x1aab

#define UI_BUF_SPORT_BEFORE_EXERCISE_FOOTBALL_BIN    0x38ed16
#define UI_LEN_SPORT_BEFORE_EXERCISE_FOOTBALL_BIN    0xdcd

#define UI_BUF_SPORT_BEFORE_EXERCISE_INDOOR_CYCLING_BIN    0x38fae3
#define UI_LEN_SPORT_BEFORE_EXERCISE_INDOOR_CYCLING_BIN    0x1114

#define UI_BUF_SPORT_BEFORE_EXERCISE_INDOOR_RUNNING_BIN    0x390bf7
#define UI_LEN_SPORT_BEFORE_EXERCISE_INDOOR_RUNNING_BIN    0xfeb

#define UI_BUF_SPORT_BEFORE_EXERCISE_KCAL_BG_BIN    0x391be2
#define UI_LEN_SPORT_BEFORE_EXERCISE_KCAL_BG_BIN    0x260c

#define UI_BUF_SPORT_BEFORE_EXERCISE_KCAL_NUM_BIN    0x3941ee
#define UI_LEN_SPORT_BEFORE_EXERCISE_KCAL_NUM_BIN    0x121d

#define UI_BUF_SPORT_BEFORE_EXERCISE_KM_BG_BIN     0x39540b
#define UI_LEN_SPORT_BEFORE_EXERCISE_KM_BG_BIN     0x2550

#define UI_BUF_SPORT_BEFORE_EXERCISE_KM_NUM_BIN    0x39795b
#define UI_LEN_SPORT_BEFORE_EXERCISE_KM_NUM_BIN    0x121d

#define UI_BUF_SPORT_BEFORE_EXERCISE_OUTDOOR_CYCLING_BIN    0x398b78
#define UI_LEN_SPORT_BEFORE_EXERCISE_OUTDOOR_CYCLING_BIN    0x13f0

#define UI_BUF_SPORT_BEFORE_EXERCISE_RUN_BIN       0x399f68
#define UI_LEN_SPORT_BEFORE_EXERCISE_RUN_BIN       0xd05

#define UI_BUF_SPORT_BEFORE_EXERCISE_STEP_BG_BIN    0x39ac6d
#define UI_LEN_SPORT_BEFORE_EXERCISE_STEP_BG_BIN    0x22ea

#define UI_BUF_SPORT_BEFORE_EXERCISE_STEP_NUM_BIN    0x39cf57
#define UI_LEN_SPORT_BEFORE_EXERCISE_STEP_NUM_BIN    0x1579

#define UI_BUF_SPORT_BEFORE_EXERCISE_SWIM_BIN      0x39e4d0
#define UI_LEN_SPORT_BEFORE_EXERCISE_SWIM_BIN      0xd52

#define UI_BUF_SPORT_BEFORE_EXERCISE_TIME_BG_BIN    0x39f222
#define UI_LEN_SPORT_BEFORE_EXERCISE_TIME_BG_BIN    0x24f9

#define UI_BUF_SPORT_BEFORE_EXERCISE_TIME_NUM_BIN    0x3a171b
#define UI_LEN_SPORT_BEFORE_EXERCISE_TIME_NUM_BIN    0x121d

#define UI_BUF_SPORT_BEFORE_EXERCISE_WALK_BIN      0x3a2938
#define UI_LEN_SPORT_BEFORE_EXERCISE_WALK_BIN      0xd32

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_FOOTBALL_BIN    0x3a366a
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_FOOTBALL_BIN    0x5c89

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_INDOOR_CYCLING_BIN    0x3a92f3
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_INDOOR_CYCLING_BIN    0x77c6

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_INDOOR_RUNNING_BIN    0x3b0ab9
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_INDOOR_RUNNING_BIN    0x6d35

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_OUTDOOR_CYCLING_BIN    0x3b77ee
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_OUTDOOR_CYCLING_BIN    0x8ca6

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_RUN_BIN    0x3c0494
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_RUN_BIN    0x567d

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_SWIM_BIN    0x3c5b11
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_SWIM_BIN    0x7a24

#define UI_BUF_SPORT_BEFORE_EXERCISE_GIF_WALK_BIN    0x3cd535
#define UI_LEN_SPORT_BEFORE_EXERCISE_GIF_WALK_BIN    0x6645

#define UI_BUF_SPORT_EXERCISING_1_BIN              0x3d3b7a
#define UI_LEN_SPORT_EXERCISING_1_BIN              0x3962

#define UI_BUF_SPORT_EXERCISING_2_BIN              0x3d74dc
#define UI_LEN_SPORT_EXERCISING_2_BIN              0x3b08

#define UI_BUF_SPORT_EXERCISING_3_BIN              0x3dafe4
#define UI_LEN_SPORT_EXERCISING_3_BIN              0x3c05

#define UI_BUF_SPORT_EXERCISING_BG_HR_BIN          0x3debe9
#define UI_LEN_SPORT_EXERCISING_BG_HR_BIN          0x776

#define UI_BUF_SPORT_EXERCISING_CANCEL_BIN         0x3df35f
#define UI_LEN_SPORT_EXERCISING_CANCEL_BIN         0x11dc

#define UI_BUF_SPORT_EXERCISING_CANCEL_CLICK_BIN    0x3e053b
#define UI_LEN_SPORT_EXERCISING_CANCEL_CLICK_BIN    0xfe9

#define UI_BUF_SPORT_EXERCISING_COMPLETE_BIN       0x3e1524
#define UI_LEN_SPORT_EXERCISING_COMPLETE_BIN       0x3d85

#define UI_BUF_SPORT_EXERCISING_DOU1_BIN           0x3e52a9
#define UI_LEN_SPORT_EXERCISING_DOU1_BIN           0x228

#define UI_BUF_SPORT_EXERCISING_DOU2_BIN           0x3e54d1
#define UI_LEN_SPORT_EXERCISING_DOU2_BIN           0x228

#define UI_BUF_SPORT_EXERCISING_DOU3_BIN           0x3e56f9
#define UI_LEN_SPORT_EXERCISING_DOU3_BIN           0x228

#define UI_BUF_SPORT_EXERCISING_HR1_BIN            0x3e5921
#define UI_LEN_SPORT_EXERCISING_HR1_BIN            0x20e

#define UI_BUF_SPORT_EXERCISING_HR2_BIN            0x3e5b2f
#define UI_LEN_SPORT_EXERCISING_HR2_BIN            0x20e

#define UI_BUF_SPORT_EXERCISING_HR3_BIN            0x3e5d3d
#define UI_LEN_SPORT_EXERCISING_HR3_BIN            0x20e

#define UI_BUF_SPORT_EXERCISING_HR4_BIN            0x3e5f4b
#define UI_LEN_SPORT_EXERCISING_HR4_BIN            0x20e

#define UI_BUF_SPORT_EXERCISING_KCAL_BIN           0x3e6159
#define UI_LEN_SPORT_EXERCISING_KCAL_BIN           0xabd

#define UI_BUF_SPORT_EXERCISING_KM_BIN             0x3e6c16
#define UI_LEN_SPORT_EXERCISING_KM_BIN             0xa0e

#define UI_BUF_SPORT_EXERCISING_LOCK_BIN           0x3e7624
#define UI_LEN_SPORT_EXERCISING_LOCK_BIN           0x11c2

#define UI_BUF_SPORT_EXERCISING_LOCK_CLICK_BIN     0x3e87e6
#define UI_LEN_SPORT_EXERCISING_LOCK_CLICK_BIN     0x10f5

#define UI_BUF_SPORT_EXERCISING_OFF_BIN            0x3e98db
#define UI_LEN_SPORT_EXERCISING_OFF_BIN            0x1153

#define UI_BUF_SPORT_EXERCISING_ON_BIN             0x3eaa2e
#define UI_LEN_SPORT_EXERCISING_ON_BIN             0x124c

#define UI_BUF_SPORT_EXERCISING_PAUSE_BIN          0x3ebc7a
#define UI_LEN_SPORT_EXERCISING_PAUSE_BIN          0x110b

#define UI_BUF_SPORT_EXERCISING_PAUSE_CLICK_BIN    0x3ecd85
#define UI_LEN_SPORT_EXERCISING_PAUSE_CLICK_BIN    0x1056

#define UI_BUF_SPORT_EXERCISING_STEP_BIN           0x3edddb
#define UI_LEN_SPORT_EXERCISING_STEP_BIN           0x732

#define UI_BUF_SPORT_EXERCISING_TIME_BIN           0x3ee50d
#define UI_LEN_SPORT_EXERCISING_TIME_BIN           0x916

#define UI_BUF_STOPWATCH_AFRESH_BIN                0x3eee23
#define UI_LEN_STOPWATCH_AFRESH_BIN                0x4d7

#define UI_BUF_STOPWATCH_AFRESH_CLICK_BIN          0x3ef2fa
#define UI_LEN_STOPWATCH_AFRESH_CLICK_BIN          0x445

#define UI_BUF_STOPWATCH_NUM1_16_24_BIN            0x3ef73f
#define UI_LEN_STOPWATCH_NUM1_16_24_BIN            0x1a28

#define UI_BUF_STOPWATCH_NUM1_16_24_CLICK_BIN      0x3f1167
#define UI_LEN_STOPWATCH_NUM1_16_24_CLICK_BIN      0x1a29

#define UI_BUF_STOPWATCH_RECORD_BIN                0x3f2b90
#define UI_LEN_STOPWATCH_RECORD_BIN                0x5eb

#define UI_BUF_STOPWATCH_RECORD1_BIN               0x3f317b
#define UI_LEN_STOPWATCH_RECORD1_BIN               0x4e4

#define UI_BUF_STOPWATCH_RECORD1_CLICK_BIN         0x3f365f
#define UI_LEN_STOPWATCH_RECORD1_CLICK_BIN         0x4a3

#define UI_BUF_STOPWATCH_RECORD_CLICK_BIN          0x3f3b02
#define UI_LEN_STOPWATCH_RECORD_CLICK_BIN          0x596

#define UI_BUF_TIMER_AGAIN_BIN                     0x3f4098
#define UI_LEN_TIMER_AGAIN_BIN                     0xc1b

#define UI_BUF_TIMER_BG_BIN                        0x3f4cb3
#define UI_LEN_TIMER_BG_BIN                        0x485

#define UI_BUF_VOICE_320_86_BIN                    0x3f5138
#define UI_LEN_VOICE_320_86_BIN                    0x32a0

#define UI_BUF_WEATHER_CLOUDY_BIN                  0x3f83d8
#define UI_LEN_WEATHER_CLOUDY_BIN                  0x99e

#define UI_BUF_WEATHER_OVERCAST_BIN                0x3f8d76
#define UI_LEN_WEATHER_OVERCAST_BIN                0x7c1

#define UI_BUF_WEATHER_RAIN_BIN                    0x3f9537
#define UI_LEN_WEATHER_RAIN_BIN                    0xf80

#define UI_BUF_WEATHER_SAND_DUST_BIN               0x3fa4b7
#define UI_LEN_WEATHER_SAND_DUST_BIN               0xf9d

#define UI_BUF_WEATHER_SMOG_BIN                    0x3fb454
#define UI_LEN_WEATHER_SMOG_BIN                    0xb29

#define UI_BUF_WEATHER_SNOWY_BIN                   0x3fbf7d
#define UI_LEN_WEATHER_SNOWY_BIN                   0x132b

#define UI_BUF_WEATHER_SUNNY_BIN                   0x3fd2a8
#define UI_LEN_WEATHER_SUNNY_BIN                   0xcad

#define UI_BUF_WEATHER_WINDY_BIN                   0x3fdf55
#define UI_LEN_WEATHER_WINDY_BIN                   0x8a0

#endif
