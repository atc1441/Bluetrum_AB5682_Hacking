#ifndef _PORT_TFT_H
#define _PORT_TFT_H

#define PORT_TFT_INT            IO_PA6
#define PORT_TFT_INT_VECTOR     PORT_INT1_VECTOR

#define PORT_TFT_RST_H()        GPIOBSET = BIT(7);
#define PORT_TFT_RST_L()        GPIOBCLR = BIT(7);

#define TFT_SPI_CS_EN()         GPIOACLR = BIT(5);
#define TFT_SPI_CS_DIS()        GPIOASET = BIT(5);

#if CHIP_PACKAGE_QNF40
#define PORT_TFT_BL             GPIO_PF1  //pwm_gpio
#define LCD_BL_EN()             {GPIOFDIR &= ~BIT(1); GPIOFDE  |= BIT(1); GPIOFSET  = BIT(1);}
#define LCD_BL_DIS()            {GPIOFDIR |= BIT(1); GPIOFDE  &= ~BIT(1);}
#else
#define PORT_TFT_BL             GPIO_PB4
#define LCD_BL_EN()             {GPIOBDIR &= ~BIT(4); GPIOBDE  |= BIT(4); GPIOBSET  = BIT(4);}
#define LCD_BL_DIS()            {GPIOBDIR |= BIT(4); GPIOBDE  &= ~BIT(4);}
#endif // CHIP_PACKAGE_QNF40

#if MODE_4WIRE_8BIT
#define   DC_ENABLE()        GPIOADIR &= ~BIT(3); // DC脚 设置输出
#define   DC_CMD_EN()        GPIOACLR = BIT(3);   // DC 拉低
#define   DC_DATA_EN()       GPIOASET = BIT(3);   // DC 拉高
#endif

void port_tft_init(void);
void port_tft_exit(void);
void port_tft_reset(void);

#endif
