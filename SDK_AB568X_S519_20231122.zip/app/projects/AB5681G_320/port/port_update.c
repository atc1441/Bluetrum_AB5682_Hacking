#include "include.h"

//复位开始升级。返回True时软(不)复位，False时直接硬复位
bool updateset_reset(void)
{
    return true;
}
