#include "include.h"
#include "port_ctp.h"

void port_tft_init(void)
{
    GPIOAFEN &= ~BIT(5);                        // CS
    GPIOADE  |=  BIT(5);
    GPIOASET  =  BIT(5);
    GPIOADIR &= ~BIT(5);

    GPIOAFEN |=  BIT(4);                        // CLK
    GPIOADE  |=  BIT(4);
    GPIOACLR  =  BIT(4);
    GPIOADIR &= ~BIT(4);

    GPIOAFEN |= (BIT(2)|BIT(3)|BIT(1)|BIT(0));  // D0/D1/D2/D3
    GPIOADE  |= (BIT(2)|BIT(3)|BIT(1)|BIT(0));
    GPIOADIR |= (BIT(2)|BIT(3)|BIT(1)|BIT(0));

    #if MODE_4WIRE_8BIT
    DC_ENABLE();
    #endif

    FUNCMCON2 = BIT(28);
}

void port_tft_reset(void)
{
    GPIOAFEN &= ~BIT(7);                            //RESET
    GPIOADE  |= BIT(7);
    GPIOASET = BIT(7);
    GPIOADIR &= ~BIT(7);
    delay_ms(10);
    GPIOACLR = BIT(7);
    delay_ms(20);
    GPIOASET = BIT(7);
    delay_ms(50);
}

void port_tft_exit(void)
{
    GPIOADE  &= ~(BIT(2)|BIT(3)|BIT(1)|BIT(0)|BIT(4)|BIT(5)|BIT(7));
    GPIOADIR |= (BIT(2)|BIT(3)|BIT(1)|BIT(0)|BIT(4)|BIT(5)|BIT(7));
}
