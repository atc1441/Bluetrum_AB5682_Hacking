#ifndef _PORT_CTP_H
#define _PORT_CTP_H

#if CHIP_PACKAGE_QNF40
#define PORT_CTP_INT            IO_PB4
#define PORT_CTP_INT_VECTOR     PORT_INT5_VECTOR

#define PORT_CTP_RST_H()        GPIOBSET = BIT(7);
#define PORT_CTP_RST_L()        GPIOBCLR = BIT(7);

#else
#define PORT_CTP_INT            IO_PF3
#define PORT_CTP_INT_VECTOR     PORT_INT6_VECTOR

#define PORT_CTP_RST_H()        GPIOESET = BIT(3);
#define PORT_CTP_RST_L()        GPIOECLR = BIT(3);

#endif // CHIP_PACKAGE_QNF40

void port_ctp_init(void);
void port_ctp_exit(void);

#endif
