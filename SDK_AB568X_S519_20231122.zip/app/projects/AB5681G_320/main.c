#include "include.h"

//320x385 60Hz 数据量为14.784MByte
const u8 tbl_despi_clk1[] = {
    [SYS_88M] = 1,          //44M
    [SYS_132M] = 2,         //44M
    [SYS_144M] = 2,         //48M
#if MODE_4WIRE_8BIT
    [SYS_176M] = 2,         //58M  需要注意屏幕是否支持这么高的速度
#else
    [SYS_176M] = 3,         //44M
#endif
    [SYS_192M] = 3,         //48M
};
const u8 tbl_despi_clk2[] = {
    [SYS_88M] = 2,          //29.3M
    [SYS_132M] = 4,         //26.4M
    [SYS_144M] = 4,         //28.8M
    [SYS_176M] = 5,         //29.3M
    [SYS_192M] = 6,         //27.4M
};

//设置DESPI CLK接口
void sys_set_despi_baud_hook(u32 sys_clk)
{
    sys_cb.despi_baud1 = tbl_despi_clk1[sys_clk];
    sys_cb.despi_baud2 = tbl_despi_clk2[sys_clk];
    sys_cb.despi_baud = sys_cb.te_mode ? sys_cb.despi_baud1 : sys_cb.despi_baud2;
    DESPIBAUD = sys_cb.despi_baud;
}

const uint8_t *bt_rf_get_inq_param(void)
{
    return NULL;
}

u8 get_chip_package(void)
{
    return 0;
}

const uint8_t *bt_rf_get_param(void)
{
    return (const uint8_t *)&xcfg_cb.rf_pa_gain;
}

//正常启动Main函数
int main(void)
{
    printf("Hello AB5680: %08x\n", (LVDCON & 0x1ff0000));
    bsp_sys_init();
    func_run();
    return 0;
}

//升级完成
void update_complete(int mode)
{
    bsp_update_init();
    if (mode == 0) {
        WDT_DIS();
        while (1);
    }
    WDT_RST();
}
