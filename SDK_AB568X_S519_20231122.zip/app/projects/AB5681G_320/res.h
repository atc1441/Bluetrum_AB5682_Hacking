//该头文件由软件自动生成，请勿随意修改！
#ifndef _RES_H
#define _RES_H

#define RES_BUF_CTP_CTP_UPDATE_BIN                  (*(u32 *)0x11000038)
#define RES_LEN_CTP_CTP_UPDATE_BIN                  (*(u32 *)0x1100003c)

#define RES_BUF_DRC_BT_MIC_16K_DRC                  (*(u32 *)0x11000058)
#define RES_LEN_DRC_BT_MIC_16K_DRC                  (*(u32 *)0x1100005c)

#define RES_BUF_DRC_BT_MIC_8K_DRC                   (*(u32 *)0x11000078)
#define RES_LEN_DRC_BT_MIC_8K_DRC                   (*(u32 *)0x1100007c)

#define RES_BUF_DRC_CALL_DAC_DRC                    (*(u32 *)0x11000098)
#define RES_LEN_DRC_CALL_DAC_DRC                    (*(u32 *)0x1100009c)

#define RES_BUF_DRC_DAC_DRC                         (*(u32 *)0x110000b8)
#define RES_LEN_DRC_DAC_DRC                         (*(u32 *)0x110000bc)

#define RES_BUF_DRC_SPK_MIC_DRC                     (*(u32 *)0x110000d8)
#define RES_LEN_DRC_SPK_MIC_DRC                     (*(u32 *)0x110000dc)

#define RES_BUF_EN_NUM_0_MP3                        (*(u32 *)0x110000f8)
#define RES_LEN_EN_NUM_0_MP3                        (*(u32 *)0x110000fc)

#define RES_BUF_EN_NUM_1_MP3                        (*(u32 *)0x11000118)
#define RES_LEN_EN_NUM_1_MP3                        (*(u32 *)0x1100011c)

#define RES_BUF_EN_NUM_2_MP3                        (*(u32 *)0x11000138)
#define RES_LEN_EN_NUM_2_MP3                        (*(u32 *)0x1100013c)

#define RES_BUF_EN_NUM_3_MP3                        (*(u32 *)0x11000158)
#define RES_LEN_EN_NUM_3_MP3                        (*(u32 *)0x1100015c)

#define RES_BUF_EN_NUM_4_MP3                        (*(u32 *)0x11000178)
#define RES_LEN_EN_NUM_4_MP3                        (*(u32 *)0x1100017c)

#define RES_BUF_EN_NUM_5_MP3                        (*(u32 *)0x11000198)
#define RES_LEN_EN_NUM_5_MP3                        (*(u32 *)0x1100019c)

#define RES_BUF_EN_NUM_6_MP3                        (*(u32 *)0x110001b8)
#define RES_LEN_EN_NUM_6_MP3                        (*(u32 *)0x110001bc)

#define RES_BUF_EN_NUM_7_MP3                        (*(u32 *)0x110001d8)
#define RES_LEN_EN_NUM_7_MP3                        (*(u32 *)0x110001dc)

#define RES_BUF_EN_NUM_8_MP3                        (*(u32 *)0x110001f8)
#define RES_LEN_EN_NUM_8_MP3                        (*(u32 *)0x110001fc)

#define RES_BUF_EN_NUM_9_MP3                        (*(u32 *)0x11000218)
#define RES_LEN_EN_NUM_9_MP3                        (*(u32 *)0x1100021c)

#define RES_BUF_EQ_BT_MIC_16K_EQ                    (*(u32 *)0x11000238)
#define RES_LEN_EQ_BT_MIC_16K_EQ                    (*(u32 *)0x1100023c)

#define RES_BUF_EQ_BT_MIC_8K_EQ                     (*(u32 *)0x11000258)
#define RES_LEN_EQ_BT_MIC_8K_EQ                     (*(u32 *)0x1100025c)

#define RES_BUF_EQ_CALL_NORMAL_EQ                   (*(u32 *)0x11000278)
#define RES_LEN_EQ_CALL_NORMAL_EQ                   (*(u32 *)0x1100027c)

#define RES_BUF_EQ_CLASSIC_EQ                       (*(u32 *)0x11000298)
#define RES_LEN_EQ_CLASSIC_EQ                       (*(u32 *)0x1100029c)

#define RES_BUF_EQ_COUNTRY_EQ                       (*(u32 *)0x110002b8)
#define RES_LEN_EQ_COUNTRY_EQ                       (*(u32 *)0x110002bc)

#define RES_BUF_EQ_JAZZ_EQ                          (*(u32 *)0x110002d8)
#define RES_LEN_EQ_JAZZ_EQ                          (*(u32 *)0x110002dc)

#define RES_BUF_EQ_NORMAL_EQ                        (*(u32 *)0x110002f8)
#define RES_LEN_EQ_NORMAL_EQ                        (*(u32 *)0x110002fc)

#define RES_BUF_EQ_POP_EQ                           (*(u32 *)0x11000318)
#define RES_LEN_EQ_POP_EQ                           (*(u32 *)0x1100031c)

#define RES_BUF_EQ_ROCK_EQ                          (*(u32 *)0x11000338)
#define RES_LEN_EQ_ROCK_EQ                          (*(u32 *)0x1100033c)

#define RES_BUF_EQ_SPK_MIC_EQ                       (*(u32 *)0x11000358)
#define RES_LEN_EQ_SPK_MIC_EQ                       (*(u32 *)0x1100035c)

#endif
