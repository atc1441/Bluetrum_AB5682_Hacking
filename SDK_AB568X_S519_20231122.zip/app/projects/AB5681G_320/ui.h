//该头文件由软件自动生成，请勿随意修改！
#ifndef _UI_H
#define _UI_H

#define UI_BUF_FONT_BIN                            0x87000
#define UI_LEN_FONT_BIN                            0x10b4a1

#define UI_BUF_ALARM_CLOCK_ADD_BIN                 0x1924a1
#define UI_LEN_ALARM_CLOCK_ADD_BIN                 0x967

#define UI_BUF_ALARM_CLOCK_ADD_CLICK_BIN           0x192e08
#define UI_LEN_ALARM_CLOCK_ADD_CLICK_BIN           0xcac

#define UI_BUF_ALARM_CLOCK_CONTINUE_BIN            0x193ab4
#define UI_LEN_ALARM_CLOCK_CONTINUE_BIN            0x927

#define UI_BUF_ALARM_CLOCK_CONTINUE_CLICK_BIN      0x1943db
#define UI_LEN_ALARM_CLOCK_CONTINUE_CLICK_BIN      0xc73

#define UI_BUF_ALARM_CLOCK_DELETE_BIN              0x19504e
#define UI_LEN_ALARM_CLOCK_DELETE_BIN              0xc9e

#define UI_BUF_ALARM_CLOCK_DELETE_CLICK_BIN        0x195cec
#define UI_LEN_ALARM_CLOCK_DELETE_CLICK_BIN        0x118f

#define UI_BUF_ALARM_CLOCK_NUM_BIN                 0x196e7b
#define UI_LEN_ALARM_CLOCK_NUM_BIN                 0x1560

#define UI_BUF_ALARM_CLOCK_OPEN_BIN                0x1983db
#define UI_LEN_ALARM_CLOCK_OPEN_BIN                0x1c5

#define UI_BUF_ALARM_CLOCK_SELECT1_BIN             0x1985a0
#define UI_LEN_ALARM_CLOCK_SELECT1_BIN             0x378

#define UI_BUF_ALARM_CLOCK_SELECT1_ON_BIN          0x198918
#define UI_LEN_ALARM_CLOCK_SELECT1_ON_BIN          0x3eb

#define UI_BUF_ALARM_CLOCK_YES_BIN                 0x198d03
#define UI_LEN_ALARM_CLOCK_YES_BIN                 0xd2d

#define UI_BUF_ALARM_CLOCK_YES_CLICK_BIN           0x199a30
#define UI_LEN_ALARM_CLOCK_YES_CLICK_BIN           0xd1c

#define UI_BUF_ALIPAY_BG1_BIN                      0x19a74c
#define UI_LEN_ALIPAY_BG1_BIN                      0x16eb

#define UI_BUF_ALIPAY_BG2_BIN                      0x19be37
#define UI_LEN_ALIPAY_BG2_BIN                      0x689

#define UI_BUF_ALIPAY_COMPLETE_BIN                 0x19c4c0
#define UI_LEN_ALIPAY_COMPLETE_BIN                 0x5f1

#define UI_BUF_ALIPAY_LOGO_BIN                     0x19cab1
#define UI_LEN_ALIPAY_LOGO_BIN                     0x883

#define UI_BUF_BLOOD_OXYGEN_BLOOD_OXYGEN_BIN       0x19d334
#define UI_LEN_BLOOD_OXYGEN_BLOOD_OXYGEN_BIN       0x1505

#define UI_BUF_BLOOD_OXYGEN_EXPLAIN_BIN            0x19e839
#define UI_LEN_BLOOD_OXYGEN_EXPLAIN_BIN            0x102b

#define UI_BUF_BREATHE_BREATHE_BIN                 0x19f864
#define UI_LEN_BREATHE_BREATHE_BIN                 0x83f2

#define UI_BUF_BREATHE_MODE_BIN                    0x1a7c56
#define UI_LEN_BREATHE_MODE_BIN                    0xa9d

#define UI_BUF_BREATHE_MODE_CLICK_BIN              0x1a86f3
#define UI_LEN_BREATHE_MODE_CLICK_BIN              0x98e

#define UI_BUF_BREATHE_TIME_BIN                    0x1a9081
#define UI_LEN_BREATHE_TIME_BIN                    0x855

#define UI_BUF_BREATHE_TIME_CLICK_BIN              0x1a98d6
#define UI_LEN_BREATHE_TIME_CLICK_BIN              0x737

#define UI_BUF_CALCULATOR_0_CLICK_BIN              0x1aa00d
#define UI_LEN_CALCULATOR_0_CLICK_BIN              0x886

#define UI_BUF_CALCULATOR_1_CLICK_BIN              0x1aa893
#define UI_LEN_CALCULATOR_1_CLICK_BIN              0x707

#define UI_BUF_CALCULATOR_2_CLICK_BIN              0x1aaf9a
#define UI_LEN_CALCULATOR_2_CLICK_BIN              0x738

#define UI_BUF_CALCULATOR_3_CLICK_BIN              0x1ab6d2
#define UI_LEN_CALCULATOR_3_CLICK_BIN              0x791

#define UI_BUF_CALCULATOR_4_CLICK_BIN              0x1abe63
#define UI_LEN_CALCULATOR_4_CLICK_BIN              0x77c

#define UI_BUF_CALCULATOR_5_CLICK_BIN              0x1ac5df
#define UI_LEN_CALCULATOR_5_CLICK_BIN              0x773

#define UI_BUF_CALCULATOR_6_CLICK_BIN              0x1acd52
#define UI_LEN_CALCULATOR_6_CLICK_BIN              0x831

#define UI_BUF_CALCULATOR_7_CLICK_BIN              0x1ad583
#define UI_LEN_CALCULATOR_7_CLICK_BIN              0x6ed

#define UI_BUF_CALCULATOR_8_CLICK_BIN              0x1adc70
#define UI_LEN_CALCULATOR_8_CLICK_BIN              0x88b

#define UI_BUF_CALCULATOR_9_CLICK_BIN              0x1ae4fb
#define UI_LEN_CALCULATOR_9_CLICK_BIN              0x83b

#define UI_BUF_CALCULATOR_ADD_CLICK_BIN            0x1aed36
#define UI_LEN_CALCULATOR_ADD_CLICK_BIN            0x6bf

#define UI_BUF_CALCULATOR_BG_BIN                   0x1af3f5
#define UI_LEN_CALCULATOR_BG_BIN                   0x6ab2

#define UI_BUF_CALCULATOR_CE_CLICK_BIN             0x1b5ea7
#define UI_LEN_CALCULATOR_CE_CLICK_BIN             0x885

#define UI_BUF_CALCULATOR_C_CLICK_BIN              0x1b672c
#define UI_LEN_CALCULATOR_C_CLICK_BIN              0x6ea

#define UI_BUF_CALCULATOR_DEL_CLICK_BIN            0x1b6e16
#define UI_LEN_CALCULATOR_DEL_CLICK_BIN            0x8ef

#define UI_BUF_CALCULATOR_DIVIDED_CLICK_BIN        0x1b7705
#define UI_LEN_CALCULATOR_DIVIDED_CLICK_BIN        0x653

#define UI_BUF_CALCULATOR_EQUAL_CLICK_BIN          0x1b7d58
#define UI_LEN_CALCULATOR_EQUAL_CLICK_BIN          0x5d7

#define UI_BUF_CALCULATOR_MINUS_CLICK_BIN          0x1b832f
#define UI_LEN_CALCULATOR_MINUS_CLICK_BIN          0x846

#define UI_BUF_CALCULATOR_MULTIPLY_CLICK_BIN       0x1b8b75
#define UI_LEN_CALCULATOR_MULTIPLY_CLICK_BIN       0x7e4

#define UI_BUF_CALCULATOR_POINT_CLICK_BIN          0x1b9359
#define UI_LEN_CALCULATOR_POINT_CLICK_BIN          0x5fc

#define UI_BUF_CALCULATOR_REDUCE_CLICK_BIN         0x1b9955
#define UI_LEN_CALCULATOR_REDUCE_CLICK_BIN         0x5c3

#define UI_BUF_CALL_0_CLICK_BIN                    0x1b9f18
#define UI_LEN_CALL_0_CLICK_BIN                    0x8af

#define UI_BUF_CALL_7_CLICK_BIN                    0x1ba7c7
#define UI_LEN_CALL_7_CLICK_BIN                    0x7b8

#define UI_BUF_CALL_9_CLICK_BIN                    0x1baf7f
#define UI_LEN_CALL_9_CLICK_BIN                    0xa23

#define UI_BUF_CALL_ANSWER_BIN                     0x1bb9a2
#define UI_LEN_CALL_ANSWER_BIN                     0xa25

#define UI_BUF_CALL_ANSWER_CLICK_BIN               0x1bc3c7
#define UI_LEN_CALL_ANSWER_CLICK_BIN               0xcfe

#define UI_BUF_CALL_BG1_BIN                        0x1bd0c5
#define UI_LEN_CALL_BG1_BIN                        0x45d3

#define UI_BUF_CALL_CALL_CLICK_BIN                 0x1c1698
#define UI_LEN_CALL_CALL_CLICK_BIN                 0x5d5

#define UI_BUF_CALL_DEL_CLICK_BIN                  0x1c1c6d
#define UI_LEN_CALL_DEL_CLICK_BIN                  0x781

#define UI_BUF_CALL_MES_BIN                        0x1c23ee
#define UI_LEN_CALL_MES_BIN                        0x258

#define UI_BUF_CALL_MES_CLICK_BIN                  0x1c2646
#define UI_LEN_CALL_MES_CLICK_BIN                  0x256

#define UI_BUF_CALL_MUTE_BIN                       0x1c289c
#define UI_LEN_CALL_MUTE_BIN                       0x635

#define UI_BUF_CALL_MUTE_CLICK_BIN                 0x1c2ed1
#define UI_LEN_CALL_MUTE_CLICK_BIN                 0xb67

#define UI_BUF_CALL_MUTE_ON_BIN                    0x1c3a38
#define UI_LEN_CALL_MUTE_ON_BIN                    0xb0e

#define UI_BUF_CALL_REJECT_BIN                     0x1c4546
#define UI_LEN_CALL_REJECT_BIN                     0xa5e

#define UI_BUF_CALL_REJECT_CLICK_BIN               0x1c4fa4
#define UI_LEN_CALL_REJECT_CLICK_BIN               0xdb9

#define UI_BUF_CAMERA_CAMERA_BIN                   0x1c5d5d
#define UI_LEN_CAMERA_CAMERA_BIN                   0x1bd9

#define UI_BUF_CHARGE_CHARGE1_BIN                  0x1c7936
#define UI_LEN_CHARGE_CHARGE1_BIN                  0x7d8

#define UI_BUF_CHARGE_CHARGE2_BIN                  0x1c810e
#define UI_LEN_CHARGE_CHARGE2_BIN                  0x1240

#define UI_BUF_CHARGE_LOW_POWER_BIN                0x1c934e
#define UI_LEN_CHARGE_LOW_POWER_BIN                0x1210

#define UI_BUF_COMMON_1_CLICK_BIN                  0x1ca55e
#define UI_LEN_COMMON_1_CLICK_BIN                  0x593

#define UI_BUF_COMMON_2_CLICK_BIN                  0x1caaf1
#define UI_LEN_COMMON_2_CLICK_BIN                  0x5cd

#define UI_BUF_COMMON_3_CLICK_BIN                  0x1cb0be
#define UI_LEN_COMMON_3_CLICK_BIN                  0x5e2

#define UI_BUF_COMMON_4_CLICK_BIN                  0x1cb6a0
#define UI_LEN_COMMON_4_CLICK_BIN                  0x601

#define UI_BUF_COMMON_5_CLICK_BIN                  0x1cbca1
#define UI_LEN_COMMON_5_CLICK_BIN                  0x612

#define UI_BUF_COMMON_6_CLICK_BIN                  0x1cc2b3
#define UI_LEN_COMMON_6_CLICK_BIN                  0x6d7

#define UI_BUF_COMMON_8_CLICK_BIN                  0x1cc98a
#define UI_LEN_COMMON_8_CLICK_BIN                  0x727

#define UI_BUF_COMMON_BG_BIN                       0x1cd0b1
#define UI_LEN_COMMON_BG_BIN                       0x690

#define UI_BUF_COMMON_BG1_BIN                      0x1cd741
#define UI_LEN_COMMON_BG1_BIN                      0x1d3

#define UI_BUF_COMMON_BG2_BIN                      0x1cd914
#define UI_LEN_COMMON_BG2_BIN                      0x70

#define UI_BUF_COMMON_BUTTON_BIN                   0x1cd984
#define UI_LEN_COMMON_BUTTON_BIN                   0x87f

#define UI_BUF_COMMON_BUTTON_CLICK_BIN             0x1ce203
#define UI_LEN_COMMON_BUTTON_CLICK_BIN             0xe00

#define UI_BUF_COMMON_COLON_NUM_16_24_BIN          0x1cf003
#define UI_LEN_COMMON_COLON_NUM_16_24_BIN          0xb7

#define UI_BUF_COMMON_COLON_NUM_30_46_BIN          0x1cf0ba
#define UI_LEN_COMMON_COLON_NUM_30_46_BIN          0x1cd

#define UI_BUF_COMMON_INCREASE_BIN                 0x1cf287
#define UI_LEN_COMMON_INCREASE_BIN                 0x470

#define UI_BUF_COMMON_INCREASE_CLICK_BIN           0x1cf6f7
#define UI_LEN_COMMON_INCREASE_CLICK_BIN           0x704

#define UI_BUF_COMMON_NO_BIN                       0x1cfdfb
#define UI_LEN_COMMON_NO_BIN                       0x993

#define UI_BUF_COMMON_NO_CLICK_BIN                 0x1d078e
#define UI_LEN_COMMON_NO_CLICK_BIN                 0xe38

#define UI_BUF_COMMON_NUM_16_24_BIN                0x1d15c6
#define UI_LEN_COMMON_NUM_16_24_BIN                0x1a0f

#define UI_BUF_COMMON_NUM_24_38_BIN                0x1d2fd5
#define UI_LEN_COMMON_NUM_24_38_BIN                0x2abe

#define UI_BUF_COMMON_NUM_30_46_BIN                0x1d5a93
#define UI_LEN_COMMON_NUM_30_46_BIN                0x359b

#define UI_BUF_COMMON_NUM_LEFT_18_18_BIN           0x1d902e
#define UI_LEN_COMMON_NUM_LEFT_18_18_BIN           0xf1a

#define UI_BUF_COMMON_NUM_RIGHT_18_18_BIN          0x1d9f48
#define UI_LEN_COMMON_NUM_RIGHT_18_18_BIN          0xef4

#define UI_BUF_COMMON_OFF_BIN                      0x1dae3c
#define UI_LEN_COMMON_OFF_BIN                      0x2aa

#define UI_BUF_COMMON_ON_BIN                       0x1db0e6
#define UI_LEN_COMMON_ON_BIN                       0x2c7

#define UI_BUF_COMMON_PAUSE_BIN                    0x1db3ad
#define UI_LEN_COMMON_PAUSE_BIN                    0x90b

#define UI_BUF_COMMON_PAUSE_CLICK_BIN              0x1dbcb8
#define UI_LEN_COMMON_PAUSE_CLICK_BIN              0xc93

#define UI_BUF_COMMON_PERCENT_BIN                  0x1dc94b
#define UI_LEN_COMMON_PERCENT_BIN                  0x4fb

#define UI_BUF_COMMON_POINT_NUM_16_24_BIN          0x1dce46
#define UI_LEN_COMMON_POINT_NUM_16_24_BIN          0x37

#define UI_BUF_COMMON_POINT_NUM_30_46_BIN          0x1dce7d
#define UI_LEN_COMMON_POINT_NUM_30_46_BIN          0x85

#define UI_BUF_COMMON_REDUCE_BIN                   0x1dcf02
#define UI_LEN_COMMON_REDUCE_BIN                   0x333

#define UI_BUF_COMMON_REDUCE_CLICK_BIN             0x1dd235
#define UI_LEN_COMMON_REDUCE_CLICK_BIN             0x594

#define UI_BUF_COMMON_SELECT_BIN                   0x1dd7c9
#define UI_LEN_COMMON_SELECT_BIN                   0x4d1

#define UI_BUF_COMMON_SELECT_ON_BIN                0x1ddc9a
#define UI_LEN_COMMON_SELECT_ON_BIN                0x43d

#define UI_BUF_COMMON_START_BIN                    0x1de0d7
#define UI_LEN_COMMON_START_BIN                    0xaec

#define UI_BUF_COMMON_START_CLICK_BIN              0x1debc3
#define UI_LEN_COMMON_START_CLICK_BIN              0xe01

#define UI_BUF_DIALPLATE_1_BIN                     0x1df9c4
#define UI_LEN_DIALPLATE_1_BIN                     0xaccb

#define UI_BUF_DIALPLATE_2_BIN                     0x1ea68f
#define UI_LEN_DIALPLATE_2_BIN                     0x3791

#define UI_BUF_DIALPLATE_3_BIN                     0x1ede20
#define UI_LEN_DIALPLATE_3_BIN                     0xd4d6

#define UI_BUF_DIALPLATE_4_BIN                     0x1fb2f6
#define UI_LEN_DIALPLATE_4_BIN                     0xec3c

#define UI_BUF_DIALPLATE_5_BIN                     0x209f32
#define UI_LEN_DIALPLATE_5_BIN                     0x3791

#define UI_BUF_DIALPLATE_6_BIN                     0x20d6c3
#define UI_LEN_DIALPLATE_6_BIN                     0x131e1

#define UI_BUF_DIALPLATE_7_BIN                     0x2208a4
#define UI_LEN_DIALPLATE_7_BIN                     0x9db24

#define UI_BUF_DIALPLATE_8_BIN                     0x2be3c8
#define UI_LEN_DIALPLATE_8_BIN                     0x2dd63

#define UI_BUF_DROPDOWN_CONNECT_OFF_BIN            0x2ec12b
#define UI_LEN_DROPDOWN_CONNECT_OFF_BIN            0xc4f

#define UI_BUF_DROPDOWN_CONNECT_ON_BIN             0x2ecd7a
#define UI_LEN_DROPDOWN_CONNECT_ON_BIN             0xbf1

#define UI_BUF_DROPDOWN_DISTURB_OFF_BIN            0x2ed96b
#define UI_LEN_DROPDOWN_DISTURB_OFF_BIN            0xb2d

#define UI_BUF_DROPDOWN_DISTURB_ON_BIN             0x2ee498
#define UI_LEN_DROPDOWN_DISTURB_ON_BIN             0xb2e

#define UI_BUF_DROPDOWN_FIND_PHONE_OFF_BIN         0x2eefc6
#define UI_LEN_DROPDOWN_FIND_PHONE_OFF_BIN         0xeba

#define UI_BUF_DROPDOWN_FIND_PHONE_ON_BIN          0x2efe80
#define UI_LEN_DROPDOWN_FIND_PHONE_ON_BIN          0xf08

#define UI_BUF_DROPDOWN_FLASHLIGHT_OFF_BIN         0x2f0d88
#define UI_LEN_DROPDOWN_FLASHLIGHT_OFF_BIN         0xc28

#define UI_BUF_DROPDOWN_FLASHLIGHT_ON_BIN          0x2f19b0
#define UI_LEN_DROPDOWN_FLASHLIGHT_ON_BIN          0xc2e

#define UI_BUF_DROPDOWN_LIGHT_1_BIN                0x2f25de
#define UI_LEN_DROPDOWN_LIGHT_1_BIN                0xe5a

#define UI_BUF_DROPDOWN_LIGHT_2_BIN                0x2f3438
#define UI_LEN_DROPDOWN_LIGHT_2_BIN                0xe91

#define UI_BUF_DROPDOWN_MUTE_OFF_BIN               0x2f42c9
#define UI_LEN_DROPDOWN_MUTE_OFF_BIN               0xcf3

#define UI_BUF_DROPDOWN_MUTE_ON_BIN                0x2f4fbc
#define UI_LEN_DROPDOWN_MUTE_ON_BIN                0xe75

#define UI_BUF_DROPDOWN_POWER1_BIN                 0x2f5e31
#define UI_LEN_DROPDOWN_POWER1_BIN                 0x21f

#define UI_BUF_DROPDOWN_POWER2_BIN                 0x2f6050
#define UI_LEN_DROPDOWN_POWER2_BIN                 0x29b

#define UI_BUF_DROPDOWN_POWER3_BIN                 0x2f62eb
#define UI_LEN_DROPDOWN_POWER3_BIN                 0x311

#define UI_BUF_DROPDOWN_POWER4_BIN                 0x2f65fc
#define UI_LEN_DROPDOWN_POWER4_BIN                 0x3b9

#define UI_BUF_DROPDOWN_POWER5_BIN                 0x2f69b5
#define UI_LEN_DROPDOWN_POWER5_BIN                 0x430

#define UI_BUF_DROPDOWN_POWER6_BIN                 0x2f6de5
#define UI_LEN_DROPDOWN_POWER6_BIN                 0x282

#define UI_BUF_DROPDOWN_POWER_BG_BIN               0x2f7067
#define UI_LEN_DROPDOWN_POWER_BG_BIN               0xd17

#define UI_BUF_DROPDOWN_SCAN_1_BIN                 0x2f7d7e
#define UI_LEN_DROPDOWN_SCAN_1_BIN                 0xbe1

#define UI_BUF_DROPDOWN_SCAN_2_BIN                 0x2f895f
#define UI_LEN_DROPDOWN_SCAN_2_BIN                 0xbdb

#define UI_BUF_HEART_RATE_CHART_BG_BIN             0x2f953a
#define UI_LEN_HEART_RATE_CHART_BG_BIN             0x229f

#define UI_BUF_HEART_RATE_DOWN_BIN                 0x2fb7d9
#define UI_LEN_HEART_RATE_DOWN_BIN                 0x162

#define UI_BUF_HEART_RATE_HR_BIN                   0x2fb93b
#define UI_LEN_HEART_RATE_HR_BIN                   0xc92

#define UI_BUF_HEART_RATE_HR_BG_BIN                0x2fc5cd
#define UI_LEN_HEART_RATE_HR_BG_BIN                0xfa8

#define UI_BUF_HEART_RATE_UP_BIN                   0x2fd575
#define UI_LEN_HEART_RATE_UP_BIN                   0x162

#define UI_BUF_ICON_ACTIVITY_BIN                   0x2fd6d7
#define UI_LEN_ICON_ACTIVITY_BIN                   0x12af

#define UI_BUF_ICON_ADDRESS_BOOK_BIN               0x2fe986
#define UI_LEN_ICON_ADDRESS_BOOK_BIN               0xc87

#define UI_BUF_ICON_ALARM_CLOCK_BIN                0x2ff60d
#define UI_LEN_ICON_ALARM_CLOCK_BIN                0xd08

#define UI_BUF_ICON_ALIPAY_BIN                     0x300315
#define UI_LEN_ICON_ALIPAY_BIN                     0xc68

#define UI_BUF_ICON_ALTITUDE_BIN                   0x300f7d
#define UI_LEN_ICON_ALTITUDE_BIN                   0xea4

#define UI_BUF_ICON_BLOODSUGAR_BIN                 0x301e21
#define UI_LEN_ICON_BLOODSUGAR_BIN                 0xca8

#define UI_BUF_ICON_BLOOD_OXYGEN_BIN               0x302ac9
#define UI_LEN_ICON_BLOOD_OXYGEN_BIN               0xeaf

#define UI_BUF_ICON_BLOOD_PRESSURE_BIN             0x303978
#define UI_LEN_ICON_BLOOD_PRESSURE_BIN             0xcca

#define UI_BUF_ICON_BREATHE_BIN                    0x304642
#define UI_LEN_ICON_BREATHE_BIN                    0xa37

#define UI_BUF_ICON_CALCULATOR_BIN                 0x305079
#define UI_LEN_ICON_CALCULATOR_BIN                 0x10b6

#define UI_BUF_ICON_CALENDAR_BIN                   0x30612f
#define UI_LEN_ICON_CALENDAR_BIN                   0xc70

#define UI_BUF_ICON_CALL_BIN                       0x306d9f
#define UI_LEN_ICON_CALL_BIN                       0xa02

#define UI_BUF_ICON_CAMERA_BIN                     0x3077a1
#define UI_LEN_ICON_CAMERA_BIN                     0xf4a

#define UI_BUF_ICON_CLOCK_BIN                      0x3086eb
#define UI_LEN_ICON_CLOCK_BIN                      0xbb9

#define UI_BUF_ICON_CLOCK_BG_BIN                   0x3092a4
#define UI_LEN_ICON_CLOCK_BG_BIN                   0x866

#define UI_BUF_ICON_CLOCK_H_BIN                    0x309b0a
#define UI_LEN_ICON_CLOCK_H_BIN                    0x9a

#define UI_BUF_ICON_CLOCK_M_BIN                    0x309ba4
#define UI_LEN_ICON_CLOCK_M_BIN                    0xeb

#define UI_BUF_ICON_CLOCK_S_BIN                    0x309c8f
#define UI_LEN_ICON_CLOCK_S_BIN                    0xda

#define UI_BUF_ICON_COMPASS_BIN                    0x309d69
#define UI_LEN_ICON_COMPASS_BIN                    0x10b1

#define UI_BUF_ICON_CONNECT_PHONE_BIN              0x30ae1a
#define UI_LEN_ICON_CONNECT_PHONE_BIN              0xb7c

#define UI_BUF_ICON_FINDPHONE_BIN                  0x30b996
#define UI_LEN_ICON_FINDPHONE_BIN                  0xe36

#define UI_BUF_ICON_FLASHLIGHT_BIN                 0x30c7cc
#define UI_LEN_ICON_FLASHLIGHT_BIN                 0xd2b

#define UI_BUF_ICON_GAME_BIN                       0x30d4f7
#define UI_LEN_ICON_GAME_BIN                       0xfc9

#define UI_BUF_ICON_HEART_RATE_BIN                 0x30e4c0
#define UI_LEN_ICON_HEART_RATE_BIN                 0xc80

#define UI_BUF_ICON_LANGUAGE_BIN                   0x30f140
#define UI_LEN_ICON_LANGUAGE_BIN                   0x1251

#define UI_BUF_ICON_LIGHT_BIN                      0x310391
#define UI_LEN_ICON_LIGHT_BIN                      0xee6

#define UI_BUF_ICON_MAP_BIN                        0x311277
#define UI_LEN_ICON_MAP_BIN                        0xe63

#define UI_BUF_ICON_MENU_BIN                       0x3120da
#define UI_LEN_ICON_MENU_BIN                       0xb1b

#define UI_BUF_ICON_MESSAGE_BIN                    0x312bf5
#define UI_LEN_ICON_MESSAGE_BIN                    0xa2c

#define UI_BUF_ICON_MUSIC_BIN                      0x313621
#define UI_LEN_ICON_MUSIC_BIN                      0xc47

#define UI_BUF_ICON_OFF_BIN                        0x314268
#define UI_LEN_ICON_OFF_BIN                        0xdca

#define UI_BUF_ICON_RESTART_BIN                    0x315032
#define UI_LEN_ICON_RESTART_BIN                    0xccf

#define UI_BUF_ICON_RESTORE_FACTORY_BIN            0x315d01
#define UI_LEN_ICON_RESTORE_FACTORY_BIN            0xc15

#define UI_BUF_ICON_SCAN_BIN                       0x316916
#define UI_LEN_ICON_SCAN_BIN                       0xb04

#define UI_BUF_ICON_SETTING_BIN                    0x31741a
#define UI_LEN_ICON_SETTING_BIN                    0xc45

#define UI_BUF_ICON_SLEEP_BIN                      0x31805f
#define UI_LEN_ICON_SLEEP_BIN                      0xb1a

#define UI_BUF_ICON_SPORT_BIN                      0x318b79
#define UI_LEN_ICON_SPORT_BIN                      0xca3

#define UI_BUF_ICON_STEP_BIN                       0x31981c
#define UI_LEN_ICON_STEP_BIN                       0xc30

#define UI_BUF_ICON_STOPWATCH_BIN                  0x31a44c
#define UI_LEN_ICON_STOPWATCH_BIN                  0xb46

#define UI_BUF_ICON_TIMER_BIN                      0x31af92
#define UI_LEN_ICON_TIMER_BIN                      0xf02

#define UI_BUF_ICON_VOICE_BIN                      0x31be94
#define UI_LEN_ICON_VOICE_BIN                      0x1054

#define UI_BUF_ICON_VOLUME_BIN                     0x31cee8
#define UI_LEN_ICON_VOLUME_BIN                     0xd3e

#define UI_BUF_ICON_WEATHER_BIN                    0x31dc26
#define UI_LEN_ICON_WEATHER_BIN                    0xc9a

#define UI_BUF_MUSIC_NEXT_BIN                      0x31e8c0
#define UI_LEN_MUSIC_NEXT_BIN                      0x3f9

#define UI_BUF_MUSIC_NEXT_CLICK_BIN                0x31ecb9
#define UI_LEN_MUSIC_NEXT_CLICK_BIN                0x5c9

#define UI_BUF_MUSIC_PAUSE_BIN                     0x31f282
#define UI_LEN_MUSIC_PAUSE_BIN                     0x952

#define UI_BUF_MUSIC_PAUSE_CLICK_BIN               0x31fbd4
#define UI_LEN_MUSIC_PAUSE_CLICK_BIN               0xe3a

#define UI_BUF_MUSIC_PLAY_BIN                      0x320a0e
#define UI_LEN_MUSIC_PLAY_BIN                      0x8fa

#define UI_BUF_MUSIC_PREV_BIN                      0x321308
#define UI_LEN_MUSIC_PREV_BIN                      0x3fb

#define UI_BUF_MUSIC_PREV_CLICK_BIN                0x321703
#define UI_LEN_MUSIC_PREV_CLICK_BIN                0x8de

#define UI_BUF_MUSIC_VOLUME1_BIN                   0x321fe1
#define UI_LEN_MUSIC_VOLUME1_BIN                   0x55

#define UI_BUF_MUSIC_VOLUME2_BIN                   0x322036
#define UI_LEN_MUSIC_VOLUME2_BIN                   0x55

#define UI_BUF_MUSIC_VOLUME3_BIN                   0x32208b
#define UI_LEN_MUSIC_VOLUME3_BIN                   0x59

#define UI_BUF_MUSIC_VOLUME4_BIN                   0x3220e4
#define UI_LEN_MUSIC_VOLUME4_BIN                   0x67

#define UI_BUF_MUSIC_VOLUME5_BIN                   0x32214b
#define UI_LEN_MUSIC_VOLUME5_BIN                   0x67

#define UI_BUF_MUSIC_VOLUME_BG_BIN                 0x3221b2
#define UI_LEN_MUSIC_VOLUME_BG_BIN                 0x6f

#define UI_BUF_MUSIC_VOLUME_DOWN_BIN               0x322221
#define UI_LEN_MUSIC_VOLUME_DOWN_BIN               0x2f6

#define UI_BUF_MUSIC_VOLUME_DOWN_CLICK_BIN         0x322517
#define UI_LEN_MUSIC_VOLUME_DOWN_CLICK_BIN         0x78b

#define UI_BUF_MUSIC_VOLUME_UP_BIN                 0x322ca2
#define UI_LEN_MUSIC_VOLUME_UP_BIN                 0x3be

#define UI_BUF_MUSIC_VOLUME_UP_CLICK_BIN           0x323060
#define UI_LEN_MUSIC_VOLUME_UP_CLICK_BIN           0x82e

#define UI_BUF_SETTING_ABOUT_BIN                   0x32388e
#define UI_LEN_SETTING_ABOUT_BIN                   0x3f5

#define UI_BUF_SETTING_ABOUT_CLICK_BIN             0x323c83
#define UI_LEN_SETTING_ABOUT_CLICK_BIN             0x3f5

#define UI_BUF_SETTING_BREATHING_SCREEN_BIN        0x324078
#define UI_LEN_SETTING_BREATHING_SCREEN_BIN        0x56f

#define UI_BUF_SETTING_BREATHING_SCREEN_CLICK_BIN    0x3245e7
#define UI_LEN_SETTING_BREATHING_SCREEN_CLICK_BIN    0x556

#define UI_BUF_SETTING_CALENDAR_BIN                0x324b3d
#define UI_LEN_SETTING_CALENDAR_BIN                0x416

#define UI_BUF_SETTING_CALENDAR_CLICK_BIN          0x324f53
#define UI_LEN_SETTING_CALENDAR_CLICK_BIN          0x41b

#define UI_BUF_SETTING_DISTURB_BIN                 0x32536e
#define UI_LEN_SETTING_DISTURB_BIN                 0x429

#define UI_BUF_SETTING_DISTURB_CLICK_BIN           0x325797
#define UI_LEN_SETTING_DISTURB_CLICK_BIN           0x418

#define UI_BUF_SETTING_LANGUAGE_BIN                0x325baf
#define UI_LEN_SETTING_LANGUAGE_BIN                0x535

#define UI_BUF_SETTING_LANGUAGE_CLICK_BIN          0x3260e4
#define UI_LEN_SETTING_LANGUAGE_CLICK_BIN          0x51c

#define UI_BUF_SETTING_LIGHT_BIN                   0x326600
#define UI_LEN_SETTING_LIGHT_BIN                   0x4ed

#define UI_BUF_SETTING_LIGHT_CLICK_BIN             0x326aed
#define UI_LEN_SETTING_LIGHT_CLICK_BIN             0x4eb

#define UI_BUF_SETTING_OFF_BIN                     0x326fd8
#define UI_LEN_SETTING_OFF_BIN                     0x4da

#define UI_BUF_SETTING_OFF_CLICK_BIN               0x3274b2
#define UI_LEN_SETTING_OFF_CLICK_BIN               0x4d5

#define UI_BUF_SETTING_PASSWORD_BIN                0x327987
#define UI_LEN_SETTING_PASSWORD_BIN                0x438

#define UI_BUF_SETTING_PASSWORD_CLICK_BIN          0x327dbf
#define UI_LEN_SETTING_PASSWORD_CLICK_BIN          0x432

#define UI_BUF_SETTING_RESTART_BIN                 0x3281f1
#define UI_LEN_SETTING_RESTART_BIN                 0x44f

#define UI_BUF_SETTING_RESTART_CLICK_BIN           0x328640
#define UI_LEN_SETTING_RESTART_CLICK_BIN           0x449

#define UI_BUF_SETTING_RESTORE_FACTORY_BIN         0x328a89
#define UI_LEN_SETTING_RESTORE_FACTORY_BIN         0x48d

#define UI_BUF_SETTING_RESTORE_FACTORY_CLICK_BIN    0x328f16
#define UI_LEN_SETTING_RESTORE_FACTORY_CLICK_BIN    0x483

#define UI_BUF_SETTING_SOUND_AND_VIBRATION_BIN     0x329399
#define UI_LEN_SETTING_SOUND_AND_VIBRATION_BIN     0x414

#define UI_BUF_SETTING_SOUND_AND_VIBRATION_CLICK_BIN    0x3297ad
#define UI_LEN_SETTING_SOUND_AND_VIBRATION_CLICK_BIN    0x40d

#define UI_BUF_SETTING_TIME_BIN                    0x329bba
#define UI_LEN_SETTING_TIME_BIN                    0x400

#define UI_BUF_SETTING_TIME_CLICK_BIN              0x329fba
#define UI_LEN_SETTING_TIME_CLICK_BIN              0x3ff

#define UI_BUF_SETTING_WRIST_BIN                   0x32a3b9
#define UI_LEN_SETTING_WRIST_BIN                   0x46f

#define UI_BUF_SETTING_WRIST_CLICK_BIN             0x32a828
#define UI_LEN_SETTING_WRIST_CLICK_BIN             0x456

#define UI_BUF_SETTING_LIGHT_LIGHT_BIN             0x32ac7e
#define UI_LEN_SETTING_LIGHT_LIGHT_BIN             0x1204

#define UI_BUF_SETTING_PASSWORD_7_CLICK_BIN        0x32be82
#define UI_LEN_SETTING_PASSWORD_7_CLICK_BIN        0x56e

#define UI_BUF_SETTING_PASSWORD_9_CLICK_BIN        0x32c3f0
#define UI_LEN_SETTING_PASSWORD_9_CLICK_BIN        0x715

#define UI_BUF_SETTING_PASSWORD_BG_BIN             0x32cb05
#define UI_LEN_SETTING_PASSWORD_BG_BIN             0x42ca

#define UI_BUF_SETTING_PASSWORD_BG_NUM_BIN         0x330dcf
#define UI_LEN_SETTING_PASSWORD_BG_NUM_BIN         0x477

#define UI_BUF_SETTING_PASSWORD_DEL_CLICK_BIN      0x331246
#define UI_LEN_SETTING_PASSWORD_DEL_CLICK_BIN      0x78c

#define UI_BUF_SETTING_PASSWORD_FRAME_755_BIN      0x3319d2
#define UI_LEN_SETTING_PASSWORD_FRAME_755_BIN      0x6d1

#define UI_BUF_SETTING_PASSWORD_NUM_BIN            0x3320a3
#define UI_LEN_SETTING_PASSWORD_NUM_BIN            0x188

#define UI_BUF_SETTING_PASSWORD_OPEN_BIN           0x33222b
#define UI_LEN_SETTING_PASSWORD_OPEN_BIN           0x1a7

#define UI_BUF_SIDEBAR_BG_146_146_BIN              0x3323d2
#define UI_LEN_SIDEBAR_BG_146_146_BIN              0x6f9

#define UI_BUF_SIDEBAR_BG_308_156_BIN              0x332acb
#define UI_LEN_SIDEBAR_BG_308_156_BIN              0xb1d

#define UI_BUF_SIDEBAR_DEGREE_BIN                  0x3335e8
#define UI_LEN_SIDEBAR_DEGREE_BIN                  0x3ad

#define UI_BUF_SIDEBAR_SLAS_BIN                    0x333995
#define UI_LEN_SIDEBAR_SLAS_BIN                    0x1cc

#define UI_BUF_SIDEBAR_TOP_308_50_BIN              0x333b61
#define UI_LEN_SIDEBAR_TOP_308_50_BIN              0x429

#define UI_BUF_SLEEP_CHART_BG_BIN                  0x333f8a
#define UI_LEN_SLEEP_CHART_BG_BIN                  0x2ecc

#define UI_BUF_SLEEP_DEEP_ALEEP_BIN                0x336e56
#define UI_LEN_SLEEP_DEEP_ALEEP_BIN                0x433

#define UI_BUF_SLEEP_LIGHT_SLEEP_BIN               0x337289
#define UI_LEN_SLEEP_LIGHT_SLEEP_BIN               0x39d

#define UI_BUF_SLEEP_SLEEP_BIN                     0x337626
#define UI_LEN_SLEEP_SLEEP_BIN                     0xb78

#define UI_BUF_SPORT_BEFORE_EXERCISE_BG_BIN        0x33819e
#define UI_LEN_SPORT_BEFORE_EXERCISE_BG_BIN        0x132c

#define UI_BUF_SPORT_BEFORE_EXERCISE_FOOTBALL_BIN    0x3394ca
#define UI_LEN_SPORT_BEFORE_EXERCISE_FOOTBALL_BIN    0x9bc

#define UI_BUF_SPORT_BEFORE_EXERCISE_INDOOR_CYCLING_BIN    0x339e86
#define UI_LEN_SPORT_BEFORE_EXERCISE_INDOOR_CYCLING_BIN    0xc23

#define UI_BUF_SPORT_BEFORE_EXERCISE_INDOOR_RUNNING_BIN    0x33aaa9
#define UI_LEN_SPORT_BEFORE_EXERCISE_INDOOR_RUNNING_BIN    0xb6e

#define UI_BUF_SPORT_BEFORE_EXERCISE_KCAL_BG_BIN    0x33b617
#define UI_LEN_SPORT_BEFORE_EXERCISE_KCAL_BG_BIN    0x1a9c

#define UI_BUF_SPORT_BEFORE_EXERCISE_KCAL_NUM_BIN    0x33d0b3
#define UI_LEN_SPORT_BEFORE_EXERCISE_KCAL_NUM_BIN    0xd71

#define UI_BUF_SPORT_BEFORE_EXERCISE_KM_BG_BIN     0x33de24
#define UI_LEN_SPORT_BEFORE_EXERCISE_KM_BG_BIN     0x1a22

#define UI_BUF_SPORT_BEFORE_EXERCISE_KM_NUM_BIN    0x33f846
#define UI_LEN_SPORT_BEFORE_EXERCISE_KM_NUM_BIN    0xd71

#define UI_BUF_SPORT_BEFORE_EXERCISE_OUTDOOR_CYCLING_BIN    0x3405b7
#define UI_LEN_SPORT_BEFORE_EXERCISE_OUTDOOR_CYCLING_BIN    0xdda

#define UI_BUF_SPORT_BEFORE_EXERCISE_RUN_BIN       0x341391
#define UI_LEN_SPORT_BEFORE_EXERCISE_RUN_BIN       0x938

#define UI_BUF_SPORT_BEFORE_EXERCISE_STEP_BG_BIN    0x341cc9
#define UI_LEN_SPORT_BEFORE_EXERCISE_STEP_BG_BIN    0x1849

#define UI_BUF_SPORT_BEFORE_EXERCISE_STEP_NUM_BIN    0x343512
#define UI_LEN_SPORT_BEFORE_EXERCISE_STEP_NUM_BIN    0xff5

#define UI_BUF_SPORT_BEFORE_EXERCISE_SWIM_BIN      0x344507
#define UI_LEN_SPORT_BEFORE_EXERCISE_SWIM_BIN      0x940

#define UI_BUF_SPORT_BEFORE_EXERCISE_TIME_BG_BIN    0x344e47
#define UI_LEN_SPORT_BEFORE_EXERCISE_TIME_BG_BIN    0x19c0

#define UI_BUF_SPORT_BEFORE_EXERCISE_TIME_NUM_BIN    0x346807
#define UI_LEN_SPORT_BEFORE_EXERCISE_TIME_NUM_BIN    0xd6f

#define UI_BUF_SPORT_BEFORE_EXERCISE_WALK_BIN      0x347576
#define UI_LEN_SPORT_BEFORE_EXERCISE_WALK_BIN      0x957

#define UI_BUF_SPORT_EXERCISING_1_BIN              0x347ecd
#define UI_LEN_SPORT_EXERCISING_1_BIN              0x28bd

#define UI_BUF_SPORT_EXERCISING_2_BIN              0x34a78a
#define UI_LEN_SPORT_EXERCISING_2_BIN              0x27d9

#define UI_BUF_SPORT_EXERCISING_3_BIN              0x34cf63
#define UI_LEN_SPORT_EXERCISING_3_BIN              0x263d

#define UI_BUF_SPORT_EXERCISING_BG_HR_BIN          0x34f5a0
#define UI_LEN_SPORT_EXERCISING_BG_HR_BIN          0x518

#define UI_BUF_SPORT_EXERCISING_CANCEL_BIN         0x34fab8
#define UI_LEN_SPORT_EXERCISING_CANCEL_BIN         0xce5

#define UI_BUF_SPORT_EXERCISING_CANCEL_CLICK_BIN    0x35079d
#define UI_LEN_SPORT_EXERCISING_CANCEL_CLICK_BIN    0xfe9

#define UI_BUF_SPORT_EXERCISING_COMPLETE_BIN       0x351786
#define UI_LEN_SPORT_EXERCISING_COMPLETE_BIN       0x2c1f

#define UI_BUF_SPORT_EXERCISING_DOU1_BIN           0x3543a5
#define UI_LEN_SPORT_EXERCISING_DOU1_BIN           0x15d

#define UI_BUF_SPORT_EXERCISING_DOU2_BIN           0x354502
#define UI_LEN_SPORT_EXERCISING_DOU2_BIN           0x15d

#define UI_BUF_SPORT_EXERCISING_DOU3_BIN           0x35465f
#define UI_LEN_SPORT_EXERCISING_DOU3_BIN           0x15d

#define UI_BUF_SPORT_EXERCISING_HR1_BIN            0x3547bc
#define UI_LEN_SPORT_EXERCISING_HR1_BIN            0x185

#define UI_BUF_SPORT_EXERCISING_HR2_BIN            0x354941
#define UI_LEN_SPORT_EXERCISING_HR2_BIN            0x185

#define UI_BUF_SPORT_EXERCISING_HR3_BIN            0x354ac6
#define UI_LEN_SPORT_EXERCISING_HR3_BIN            0x185

#define UI_BUF_SPORT_EXERCISING_HR4_BIN            0x354c4b
#define UI_LEN_SPORT_EXERCISING_HR4_BIN            0x185

#define UI_BUF_SPORT_EXERCISING_KCAL_BIN           0x354dd0
#define UI_LEN_SPORT_EXERCISING_KCAL_BIN           0x7b7

#define UI_BUF_SPORT_EXERCISING_KM_BIN             0x355587
#define UI_LEN_SPORT_EXERCISING_KM_BIN             0x6fa

#define UI_BUF_SPORT_EXERCISING_LOCK_BIN           0x355c81
#define UI_LEN_SPORT_EXERCISING_LOCK_BIN           0xce7

#define UI_BUF_SPORT_EXERCISING_LOCK_CLICK_BIN     0x356968
#define UI_LEN_SPORT_EXERCISING_LOCK_CLICK_BIN     0x10f5

#define UI_BUF_SPORT_EXERCISING_OFF_BIN            0x357a5d
#define UI_LEN_SPORT_EXERCISING_OFF_BIN            0xb60

#define UI_BUF_SPORT_EXERCISING_ON_BIN             0x3585bd
#define UI_LEN_SPORT_EXERCISING_ON_BIN             0xcd7

#define UI_BUF_SPORT_EXERCISING_PAUSE_BIN          0x359294
#define UI_LEN_SPORT_EXERCISING_PAUSE_BIN          0xbed

#define UI_BUF_SPORT_EXERCISING_PAUSE_CLICK_BIN    0x359e81
#define UI_LEN_SPORT_EXERCISING_PAUSE_CLICK_BIN    0x1056

#define UI_BUF_SPORT_EXERCISING_STEP_BIN           0x35aed7
#define UI_LEN_SPORT_EXERCISING_STEP_BIN           0x4fa

#define UI_BUF_SPORT_EXERCISING_TIME_BIN           0x35b3d1
#define UI_LEN_SPORT_EXERCISING_TIME_BIN           0x648

#define UI_BUF_STOPWATCH_AFRESH_BIN                0x35ba19
#define UI_LEN_STOPWATCH_AFRESH_BIN                0x4d7

#define UI_BUF_STOPWATCH_AFRESH_CLICK_BIN          0x35bef0
#define UI_LEN_STOPWATCH_AFRESH_CLICK_BIN          0x445

#define UI_BUF_STOPWATCH_NUM1_16_24_BIN            0x35c335
#define UI_LEN_STOPWATCH_NUM1_16_24_BIN            0x12c8

#define UI_BUF_STOPWATCH_NUM1_16_24_CLICK_BIN      0x35d5fd
#define UI_LEN_STOPWATCH_NUM1_16_24_CLICK_BIN      0x11fb

#define UI_BUF_STOPWATCH_RECORD_BIN                0x35e7f8
#define UI_LEN_STOPWATCH_RECORD_BIN                0x5eb

#define UI_BUF_STOPWATCH_RECORD1_BIN               0x35ede3
#define UI_LEN_STOPWATCH_RECORD1_BIN               0x4e4

#define UI_BUF_STOPWATCH_RECORD1_CLICK_BIN         0x35f2c7
#define UI_LEN_STOPWATCH_RECORD1_CLICK_BIN         0x4a3

#define UI_BUF_STOPWATCH_RECORD_CLICK_BIN          0x35f76a
#define UI_LEN_STOPWATCH_RECORD_CLICK_BIN          0x596

#define UI_BUF_TIMER_AGAIN_BIN                     0x35fd00
#define UI_LEN_TIMER_AGAIN_BIN                     0xc1b

#define UI_BUF_TIMER_BG_BIN                        0x36091b
#define UI_LEN_TIMER_BG_BIN                        0x485

#define UI_BUF_VOICE_320_86_BIN                    0x360da0
#define UI_LEN_VOICE_320_86_BIN                    0x32a0

#define UI_BUF_WEATHER_CLOUDY_BIN                  0x364040
#define UI_LEN_WEATHER_CLOUDY_BIN                  0xc93

#define UI_BUF_WEATHER_OVERCAST_BIN                0x364cd3
#define UI_LEN_WEATHER_OVERCAST_BIN                0xa70

#define UI_BUF_WEATHER_RAIN_BIN                    0x365743
#define UI_LEN_WEATHER_RAIN_BIN                    0x14bd

#define UI_BUF_WEATHER_SAND_DUST_BIN               0x366c00
#define UI_LEN_WEATHER_SAND_DUST_BIN               0x16a5

#define UI_BUF_WEATHER_SMOG_BIN                    0x3682a5
#define UI_LEN_WEATHER_SMOG_BIN                    0xf42

#define UI_BUF_WEATHER_SNOWY_BIN                   0x3691e7
#define UI_LEN_WEATHER_SNOWY_BIN                   0x1b2a

#define UI_BUF_WEATHER_SUNNY_BIN                   0x36ad11
#define UI_LEN_WEATHER_SUNNY_BIN                   0x1137

#define UI_BUF_WEATHER_WINDY_BIN                   0x36be48
#define UI_LEN_WEATHER_WINDY_BIN                   0xbbb

#endif
