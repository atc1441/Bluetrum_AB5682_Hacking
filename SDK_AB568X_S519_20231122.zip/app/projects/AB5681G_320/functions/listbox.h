#ifndef _LISTBOX_H
#define _LISTBOX_H

//列表框消息处理
bool compo_listbox_message(compo_listbox_t *listbox, size_msg_t msg);

#endif
