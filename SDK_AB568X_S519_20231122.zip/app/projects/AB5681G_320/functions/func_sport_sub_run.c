#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_sport_sub_run_t_ {
    u8 sta;
    u8 min;                 //分
    u8 sec;                 //秒
    u8 msec;                //毫秒
    u32 total_msec;         //总毫秒
} f_sport_sub_run_t;

enum {
	COMPO_ID_NUM_STOPWATCH_MIN = 1,         //分
	COMPO_ID_NUM_STOPWATCH_SEC,         //秒
	COMPO_ID_NUM_STOPWATCH_MSEC,        //毫秒
};

typedef struct stopwatch_num_item_t_ {
    u32 res_addr;
    int num_cnt;
    u16 num_id;
    int val;
    s16 x;
    s16 y;
    bool zfill_en;
    bool visible_en;
} stopwatch_num_item_t;

#define STOPWATCH_NUM_ITEM_CNT                       ((int)(sizeof(tbl_stopwatch_num_item) / sizeof(tbl_stopwatch_num_item[0])))

//搞个数字item，创建时遍历一下
static const stopwatch_num_item_t tbl_stopwatch_num_item[] = {
    /*   res_addr,                          num_cnt,           num_id,                       val,   x,     y,  zfill_en, visible_en*/
    {UI_BUF_COMMON_NUM_30_46_BIN,               2,         COMPO_ID_NUM_STOPWATCH_MSEC,       0,   238,    79,   true,   true},
    {UI_BUF_COMMON_NUM_30_46_BIN,               2,         COMPO_ID_NUM_STOPWATCH_MIN,        0,   84,     79,   true,   true},
    {UI_BUF_COMMON_NUM_30_46_BIN,               2,         COMPO_ID_NUM_STOPWATCH_SEC,        0,   162,    79,   true,   true},
};


//创建室内跑步窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_sport_sub_run_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);
    compo_form_add_image(frm, UI_BUF_SPORT_EXERCISING_BG_HR_BIN, 160, 160);
    compo_form_add_image(frm, UI_BUF_SPORT_EXERCISING_DOU2_BIN, 160, 340);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_INDOOR_RUN]);

	//创建数字
    compo_number_t *num;
    u8 min, sec, msec;
    min = ((sys_cb.stopwatch_total_msec / 100) % 3600) / 60;
    sec = (sys_cb.stopwatch_total_msec / 100) % 60;
    msec = sys_cb.stopwatch_total_msec % 100;

    for (u8 idx = 0; idx < STOPWATCH_NUM_ITEM_CNT; idx++) {
        num = compo_number_create(frm, tbl_stopwatch_num_item[idx].res_addr, tbl_stopwatch_num_item[idx].num_cnt);
        compo_setid(num, tbl_stopwatch_num_item[idx].num_id);
        compo_number_set_pos(num, tbl_stopwatch_num_item[idx].x, tbl_stopwatch_num_item[idx].y);
        compo_number_set_zfill(num, tbl_stopwatch_num_item[idx].zfill_en);
        compo_number_set_visible(num, tbl_stopwatch_num_item[idx].visible_en);

        if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_MIN) {
            compo_number_set(num, min);
        } else if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_SEC) {
            compo_number_set(num, sec);
        } else if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_MSEC) {
            compo_number_set(num, msec);
        }
    }

    return frm;
}

//室内跑步功能事件处理
static void func_sport_sub_run_process(void)
{
    f_sport_sub_run_t *f_stopwatch = (f_sport_sub_run_t *)func_cb.f_cb;
    //获取数字组件的地址
    compo_number_t *num_min = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_MIN);
    compo_number_t *num_sec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_SEC);
    compo_number_t *num_msec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_MSEC);

    static u32 stopwatch_ticks = 0;

    if (tick_check_expire(stopwatch_ticks, 10)) {
        stopwatch_ticks = tick_get();

        f_stopwatch->total_msec++;
        f_stopwatch->min = ((f_stopwatch->total_msec / 100) % 3600) / 60;
        f_stopwatch->sec = (f_stopwatch->total_msec / 100) % 60;
        f_stopwatch->msec = f_stopwatch->total_msec % 100;

        compo_number_set(num_min, f_stopwatch->min);
        compo_number_set(num_sec, f_stopwatch->sec);
        compo_number_set(num_msec, f_stopwatch->msec);
  }

    func_process();
}

//室内跑步功能消息处理
static void func_sport_sub_run_message(size_msg_t msg)
{
    compo_form_t *frm = NULL;
    bool res = false;

    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    case MSG_QDEC_FORWARD:
    case MSG_QDEC_BACKWARD:
        break;

    case MSG_CTP_SHORT_LEFT:
        break;

    case KU_BACK:
    case MSG_CTP_SHORT_RIGHT:

        frm = func_create_form(FUNC_SPORT);
        res = func_switching(FUNC_SWITCH_LR_ZOOM_RIGHT,NULL);
        compo_form_destroy(frm);             //切换完成或取消，销毁窗体
        if (res) {
            func_cb.sta = FUNC_SPORT;
        }
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入室内跑步功能
static void func_sport_sub_run_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_sport_sub_run_t));
    func_cb.frm_main = func_sport_sub_run_form_create();
}

//退出室内跑步功能
static void func_sport_sub_run_exit(void)
{
    func_cb.last = FUNC_SPORT_SUB_RUN;
}

//室内跑步功能
void func_sport_sub_run(void)
{
    printf("%s\n", __func__);
    func_sport_sub_run_enter();
    while (func_cb.sta == FUNC_SPORT_SUB_RUN) {
        func_sport_sub_run_process();
        func_sport_sub_run_message(msg_dequeue());
    }
    func_sport_sub_run_exit();
}
