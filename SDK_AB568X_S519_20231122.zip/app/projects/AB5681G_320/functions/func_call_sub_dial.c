#include "include.h"
#include "func.h"

enum {

    COMPO_ID_BTN_NUM0 = 1,
	COMPO_ID_BTN_NUM1,
	COMPO_ID_BTN_NUM2,
	COMPO_ID_BTN_NUM3,
	COMPO_ID_BTN_NUM4,
	COMPO_ID_BTN_NUM5,
	COMPO_ID_BTN_NUM6,
	COMPO_ID_BTN_NUM7,
	COMPO_ID_BTN_NUM8,
	COMPO_ID_BTN_NUM9,
    COMPO_ID_BTN_CALL,
	COMPO_ID_BTN_DEL,
    COMPO_ID_NUM_DISP_ZERO,
	COMPO_ID_NUM_DISP_ONE,
	COMPO_ID_NUM_DISP_TWS,
	COMPO_ID_NUM_DISP_THR,
	COMPO_ID_NUM_DISP_FOUR,
	COMPO_ID_NUM_DISP_FIVE,
	COMPO_ID_NUM_DISP_SIX,
	COMPO_ID_NUM_DISP_SEV,
	COMPO_ID_NUM_DISP_EIG,
	COMPO_ID_NUM_DISP_NIN,
	COMPO_ID_NUM_DISP_TEN,
	COMPO_ID_NUM_DISP_ELE,
	COMPO_ID_BTN_INCOMING,
	COMPO_ID_BTN_REJECT,
	COMPO_ID_BTN_MSG,

	COMPO_ID_PIC_NUM,
};

typedef struct password_num_item_t_ {
    u32 res_addr;
    int num_cnt;
    u16 num_id;
    int val;
    s16 x;
    s16 y;
    bool zfill_en;
    bool visible_en;
} call_num_item_t;

#define CALL_NUM_ITEM_CNT                       ((int)(sizeof(tbl_call_num_item) / sizeof(tbl_call_num_item[0])))

//搞个数字item，创建时遍历一下
static const call_num_item_t tbl_call_num_item[] = {
    /*   res_addr,                           num_cnt,       num_id,                      val,   x,     y,  zfill_en, visible_en*/
    {UI_BUF_COMMON_NUM_16_24_BIN,               8,         COMPO_ID_NUM_DISP_ZERO,         0,   136,  34,   false,   false},
    {UI_BUF_COMMON_NUM_16_24_BIN,               1,         COMPO_ID_NUM_DISP_ONE,          0,   220,  34,   false,   false},
    {UI_BUF_COMMON_NUM_16_24_BIN,               1,         COMPO_ID_NUM_DISP_TWS,          0,   240,  34,   false,   false},
    {UI_BUF_COMMON_NUM_16_24_BIN,               1,         COMPO_ID_NUM_DISP_THR,          0,   256,  34,   false,   false},
};

#define CALL_DISP_BTN_ITEM_CNT    ((int)(sizeof(tbl_call_disp_btn_item) / sizeof(tbl_call_disp_btn_item[0])))

typedef struct password_disp_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
} call_disp_btn_item_t;

//按钮item，创建时遍历一下
static const call_disp_btn_item_t tbl_call_disp_btn_item[] = {
    {UI_BUF_COMMON_1_CLICK_BIN,             COMPO_ID_BTN_NUM1,         61,     110},
    {UI_BUF_COMMON_2_CLICK_BIN,             COMPO_ID_BTN_NUM2,         160,    110},
    {UI_BUF_COMMON_3_CLICK_BIN,             COMPO_ID_BTN_NUM3,         259,    110},
    {UI_BUF_COMMON_4_CLICK_BIN,             COMPO_ID_BTN_NUM4,         61,     183},
    {UI_BUF_COMMON_5_CLICK_BIN,             COMPO_ID_BTN_NUM5,         160,    183},
    {UI_BUF_COMMON_6_CLICK_BIN,             COMPO_ID_BTN_NUM6,         259,    183},
    {UI_BUF_CALL_7_CLICK_BIN,               COMPO_ID_BTN_NUM7,         61,     256},
    {UI_BUF_COMMON_8_CLICK_BIN,             COMPO_ID_BTN_NUM8,         160,    256},
    {UI_BUF_CALL_9_CLICK_BIN,               COMPO_ID_BTN_NUM9,         259,    256},
    {UI_BUF_CALL_0_CLICK_BIN,               COMPO_ID_BTN_NUM0,         160,    329},
    {UI_BUF_SETTING_PASSWORD_DEL_CLICK_BIN, COMPO_ID_BTN_DEL,          259,    329},
    {UI_BUF_CALL_CALL_CLICK_BIN,            COMPO_ID_BTN_CALL,         61,    329},
};

typedef struct f_call_sub_dial_t_ {
    u8 phone_number_cnt;
    u8 phone_number[11];
} f_call_sub_dial_t;

//打电话页面
compo_form_t *func_call_sub_dial_form_create(void)
{

    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //创建按钮
    compo_button_t *btn;
    for (u8 idx_btn = 0; idx_btn < CALL_DISP_BTN_ITEM_CNT; idx_btn++) {
        btn = compo_button_create_by_image(frm, tbl_call_disp_btn_item[idx_btn].res_addr);
        compo_setid(btn, tbl_call_disp_btn_item[idx_btn].btn_id);
        compo_button_set_pos(btn, tbl_call_disp_btn_item[idx_btn].x, tbl_call_disp_btn_item[idx_btn].y);
    }

    //创建文本
    compo_textbox_t *txt_title = compo_textbox_create(frm, 11);
    compo_setid(txt_title, COMPO_ID_PIC_NUM);
    compo_textbox_set_align_center(txt_title, false);
    compo_textbox_set_pos(txt_title, 60, 22);
    compo_textbox_set(txt_title, "请输入电话号码！");

    //创建数字
    compo_number_t *num;
    for (u8 idx = 0; idx < CALL_NUM_ITEM_CNT; idx++) {
       num = compo_number_create(frm, tbl_call_num_item[idx].res_addr, tbl_call_num_item[idx].num_cnt);
       compo_setid(num, tbl_call_num_item[idx].num_id);
       compo_number_set_pos(num, tbl_call_num_item[idx].x, tbl_call_num_item[idx].y);
       compo_number_set_zfill(num, tbl_call_num_item[idx].zfill_en);
       compo_number_set_visible(num, tbl_call_num_item[idx].visible_en);
        if (tbl_call_num_item[idx].num_id ==  (idx + 1)) {
           compo_number_set(num, 0);
        }
    }
    return frm;
}

//创建来电窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_call_answer_form_create(void)
{
    compo_button_t *btn;

    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //来电按钮
    btn = compo_button_create_by_image(frm, UI_BUF_CALL_ANSWER_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_INCOMING);
    compo_button_set_pos(btn, 70, 279);

    //挂电话按钮
    btn = compo_button_create_by_image(frm, UI_BUF_CALL_REJECT_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_REJECT);
    compo_button_set_pos(btn, 250, 279);

    //信息按钮
    btn = compo_button_create_by_image(frm, UI_BUF_CALL_MES_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_MSG);
    compo_button_set_pos(btn, 160, 315);

    //创建消息文本
    compo_textbox_t *txt = compo_textbox_create(frm, 2);
    compo_textbox_set_pos(txt, 160, 335);
    compo_textbox_set(txt,"信息");
    return frm;
}

//创建接通窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_calling_form_create(void)
{
    compo_button_t *btn;

    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //新建按钮
    btn = compo_button_create_by_image(frm, UI_BUF_CALL_MUTE_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_CALL);
    compo_button_set_pos(btn, 49, 313);

    btn = compo_button_create_by_image(frm, UI_BUF_CALL_REJECT_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_REJECT);
    compo_button_set_pos(btn, 160, 313);

    return frm;
}


//进入打电话界面
static void func_call_sub_dial_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_call_sub_dial_t));
    func_cb.frm_main = func_call_sub_dial_form_create();
}

//电话功能事件处理
static void func_call_sub_dial_process(void)
{
    func_process();                                  //刷新UI
}

//退出电话表盘功能
static void func_call_sub_dial_exit(void)
{
    func_cb.last = FUNC_CALL_SUB_DIAL;
}

//计算前八位的数字显示。
u32 func_calculate_number(u8 cnt, u8 *data)
{
    if(cnt == 8) {
        return data[0]*10000000+data[1]*1000000+data[2]*100000+data[3]*10000+data[4]*1000+data[5]*100+data[6]*10+data[7]*1;
    }else if(cnt == 7) {
        return data[0]*1000000+data[1]*100000+data[2]*10000+data[3]*1000+data[4]*100+data[5]*10+data[6]*1;
    }else if(cnt == 6) {
        return data[0]*100000+data[1]*10000+data[2]*1000+data[3]*100+data[4]*10+data[5]*1;
    }else if(cnt == 5) {
        return data[0]*10000+data[1]*1000+data[2]*100+data[3]*10+data[4]*1;
    }else if(cnt == 4) {
        return data[0]*1000+data[1]*100+data[2]*10+data[3]*1;
    }else if(cnt == 3) {
        return data[0]*100+data[1]*10+data[2]*1;
    }else if(cnt == 2) {
        return data[0]*10+data[1]*1;
    }else if(cnt == 1) {
        return data[0]*1;
    }
    return 0;
}

static void func_call_sub_dial_button_click(void)
{
    int id = compo_get_button_id();
    //获取文本组件的地址
    compo_textbox_t *txt = compo_getobj_byid(COMPO_ID_PIC_NUM);

    //获取数字组件地址
    compo_number_t *num_zer  = compo_getobj_byid(COMPO_ID_NUM_DISP_ZERO);
    compo_number_t *num_one  = compo_getobj_byid(COMPO_ID_NUM_DISP_ONE);
    compo_number_t *num_tws  = compo_getobj_byid(COMPO_ID_NUM_DISP_TWS);
    compo_number_t *num_thr  = compo_getobj_byid(COMPO_ID_NUM_DISP_THR);

    f_call_sub_dial_t *call = (f_call_sub_dial_t *)func_cb.f_cb;

    switch (id) {
    case COMPO_ID_BTN_NUM0...COMPO_ID_BTN_NUM9:
        compo_textbox_set_visible(txt, false);
        if(call->phone_number_cnt < 11) {
            call->phone_number[call->phone_number_cnt++] = id - 1;
        }
         break;

    case COMPO_ID_BTN_CALL:
        break;

    case COMPO_ID_BTN_DEL:
        compo_textbox_set_visible(txt, false);
        if(call->phone_number_cnt > 0) {
           call->phone_number_cnt--;
        }
        break;

    default:
        break;
    }

    if(call->phone_number_cnt == 1) {
        compo_number_set(num_zer, func_calculate_number(1,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 2) {
        compo_number_set(num_zer, func_calculate_number(2,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 3) {
        compo_number_set(num_zer, func_calculate_number(3,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 4) {
        compo_number_set(num_zer, func_calculate_number(4,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 5) {
        compo_number_set(num_zer, func_calculate_number(5,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }
    else if(call->phone_number_cnt == 6) {
        compo_number_set(num_zer, func_calculate_number(6,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }
    else if(call->phone_number_cnt == 7) {
        compo_number_set(num_zer, func_calculate_number(7,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 8) {
        compo_number_set(num_zer, func_calculate_number(8,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set_visible(num_one, false);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 9) {
        compo_number_set(num_zer, func_calculate_number(8,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set(num_one, call->phone_number[8]);
        compo_number_set_visible(num_one, true);

        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 10) {
        compo_number_set(num_zer, func_calculate_number(8,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set(num_one, call->phone_number[8]);
        compo_number_set_visible(num_one, true);

        compo_number_set(num_tws, call->phone_number[9]);
        compo_number_set_visible(num_tws, true);
        compo_number_set_visible(num_thr, false);
    }else if(call->phone_number_cnt == 11) {
        compo_number_set(num_zer, func_calculate_number(8,&call->phone_number[0]));
        compo_number_set_visible(num_zer, true);
        compo_number_set(num_one, call->phone_number[8]);
        compo_number_set_visible(num_one, true);

        compo_number_set(num_tws, call->phone_number[9]);
        compo_number_set_visible(num_tws, true);
        compo_number_set(num_thr, call->phone_number[10]);
        compo_number_set_visible(num_thr, true);
    }else {
        compo_number_set_visible(num_zer, false);
        compo_number_set_visible(num_one, false);
        compo_number_set_visible(num_tws, false);
        compo_number_set_visible(num_thr, false);
    }

}

//电话消息处理
static void func_call_sub_dial_message(size_msg_t msg)
{
    compo_form_t *frm = NULL;
    bool res = false;

    switch (msg) {
    case MSG_CTP_CLICK:
        func_call_sub_dial_button_click();
        break;

  case MSG_CTP_SHORT_RIGHT:
      if(func_cb.last == FUNC_CALL) {
        frm = func_create_form(FUNC_CALL);
        res = func_switching(FUNC_SWITCH_LR_ZOOM_RIGHT,NULL);
        compo_form_destroy(frm);             //切换完成或取消，销毁窗体
        if (res) {
            func_cb.sta = FUNC_CALL;
            }
        }else {
            func_switching_to_menu();
        }
        break;

    case MSG_QDEC_FORWARD:
    case MSG_QDEC_BACKWARD:
    break;

    default:
        func_message(msg);
        break;
    }
}

//电话显示界面
void func_call_sub_dial(void)
{
    printf("%s\n", __func__);
    func_call_sub_dial_enter();
    while (func_cb.sta == FUNC_CALL_SUB_DIAL) {
        func_call_sub_dial_process();
        func_call_sub_dial_message(msg_dequeue());
    }
    func_call_sub_dial_exit();
}
