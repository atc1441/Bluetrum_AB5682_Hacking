#include "include.h"
#include "func_menu.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define FUNC_CREATE_CNT                       ((int)(sizeof(tbl_func_create) / sizeof(tbl_func_create[0])))
#define FUNC_ENTRY_CNT                        ((int)(sizeof(tbl_func_entry) / sizeof(tbl_func_entry[0])))

typedef struct func_t_ {
    int func_idx;
    void *func;
} func_t;

extern void func_menu(void);
extern void func_clock(void);
extern void func_clock_sub_sidebar(void);
extern void func_heartrate(void);
extern void func_alarm_clock(void);
extern void func_alarm_clock_sub_set(void);
extern void func_alarm_clock_sub_repeat(void);
extern void func_alarm_clock_sub_edit(void);
extern void func_blood_oxygen(void);
extern void func_breathe(void);
extern void func_calculator(void);
extern void func_camera(void);
extern void func_light(void);
extern void func_timer(void);
extern void func_timer_sub_disp(void);
extern void func_timer_sub_custom(void);
extern void func_sleep(void);
extern void func_stopwatch(void);
extern void func_stopwatch_sub_record(void);
extern void func_weather(void);
extern void func_sport(void);
extern void func_sport_config(void);
extern void func_sport_sub_run(void);
extern void func_calendar(void);
extern void func_call(void);
extern void func_call_sub_record(void);
extern void func_call_sub_dial(void);
extern void func_game(void);
extern void func_style(void);
extern void func_findphone(void);
extern void func_altitude(void);
extern void func_map(void);
extern void func_message_info(void);
extern void func_scan(void);
extern void func_voice(void);
extern void func_alipay(void);
extern void func_compass(void);
extern void func_address_book(void);
extern void func_set_sub_list(void);
extern void func_set_sub_sav(void);
extern void func_set_sub_dousing(void);
extern void func_set_sub_disturd(void);
extern void func_set_sub_language(void);
extern void func_set_sub_wrist(void);
extern void func_set_sub_time(void);
extern void func_time_sub_custom(void);
extern void func_set_sub_password(void);
extern void func_password_sub_disp(void);
extern void func_password_sub_select(void);
extern void func_set_sub_about(void);
extern void func_set_sub_restart(void);
extern void func_set_sub_rstfy(void);
extern void func_set_sub_off(void);
extern void func_switching_to_menu(void);
extern void func_volume(void);
extern void func_activity(void);
extern void func_bloodsugar(void);
extern void func_bloodpressure(void);
extern void func_flashlight(void);
extern void func_charge(void);

extern void func_music(void);
extern void func_idle(void);
extern void func_bt(void);
extern void func_bthid(void);
extern void func_usbdev(void);
extern void func_aux(void);

compo_form_t *func_menu_form_create(void);
compo_form_t *func_clock_form_create(void);
compo_form_t *func_clock_sub_sidebar_form_create(void);
compo_form_t *func_heartrate_form_create(void);
compo_form_t *func_bt_form_create(void);
compo_form_t *func_alarm_clock_form_create(void);
compo_form_t *func_alarm_clock_sub_set_form_create(void);
compo_form_t *func_alarm_clock_sub_repeat_form_create(void);
compo_form_t *func_alarm_clock_sub_edit_form_create(void);
compo_form_t *func_blood_oxygen_form_create(void);
compo_form_t *func_breathe_form_create(void);
compo_form_t *func_calculator_form_create(void);
compo_form_t *func_camera_form_create(void);
compo_form_t *func_light_form_create(void);
compo_form_t *func_timer_form_create(void);
compo_form_t *func_timer_sub_disp_form_create(void);
compo_form_t *func_timer_sub_custom_form_create(void);
compo_form_t *func_sleep_form_create(void);
compo_form_t *func_stopwatch_form_create(void);
compo_form_t *func_stopwatch_sub_record_form_create(void);
compo_form_t *func_weather_form_create(void);
compo_form_t *func_sport_form_create(void);
compo_form_t *func_sport_config_form_create(void);
compo_form_t *func_sport_sub_run_form_create(void);
compo_form_t *func_set_sub_disturd_form_create(void);
compo_form_t *func_call_form_create(void);
compo_form_t *func_call_sub_record_form_create(void);
compo_form_t *func_call_sub_dial_form_create(void);
compo_form_t *func_game_form_create(void);
compo_form_t *func_style_form_create(void);
compo_form_t *func_findphone_form_create(void);
compo_form_t *func_altitude_form_create(void);
compo_form_t *func_map_form_create(void);
compo_form_t *func_message_form_create(void);
compo_form_t *func_scan_form_create(void);
compo_form_t *func_voice_form_create(void);
compo_form_t *func_alipay_form_create(void);
compo_form_t *func_compass_form_create(void);
compo_form_t *func_address_book_form_create(void);
compo_form_t *func_set_sub_list_form_create(void);
compo_form_t *func_set_sub_wrist_form_create(void);
compo_form_t *func_set_sub_sav_form_create(void);
compo_form_t *func_set_sub_dousing_form_create(void);
compo_form_t *func_set_sub_language_form_create(void);
compo_form_t *func_set_sub_time_form_create(void);
compo_form_t *func_time_sub_custom_form_create(void);
compo_form_t *func_set_sub_password_form_create(void);
compo_form_t *func_password_sub_disp_form_create(void);
compo_form_t *func_password_sub_select_form_create(void);
compo_form_t *func_set_sub_about_form_create(void);
compo_form_t *func_set_sub_restart_form_create(void);
compo_form_t *func_set_sub_rstfy_form_create(void);
compo_form_t *func_set_sub_off_form_create(void);
compo_form_t *func_calender_form_create(void);
compo_form_t *func_volume_form_create(void);
compo_form_t *func_activity_form_create(void);
compo_form_t *func_bloodsugar_form_create(void);
compo_form_t *func_bloodpressure_form_create(void);
compo_form_t *func_flashlight_form_create(void);
compo_form_t *func_charge_form_create(void);

func_cb_t func_cb AT(.buf.func_cb);

const func_t tbl_func_create[] = {
    {FUNC_MENU,                         func_menu_form_create},
    {FUNC_CLOCK,                        func_clock_form_create},
    {FUNC_SIDEBAR,                      func_clock_sub_sidebar_form_create},
    {FUNC_HEARTRATE,                    func_heartrate_form_create},
    {FUNC_BT,                           func_bt_form_create},
    {FUNC_ALARM_CLOCK,                  func_alarm_clock_form_create},
    {FUNC_ALARM_CLOCK_SUB_SET,          func_alarm_clock_sub_set_form_create},
    {FUNC_ALARM_CLOCK_SUB_REPEAT,       func_alarm_clock_sub_repeat_form_create},
    {FUNC_ALARM_CLOCK_SUB_EDIT,         func_alarm_clock_sub_edit_form_create},
    {FUNC_BLOOD_OXYGEN,                 func_blood_oxygen_form_create},
    {FUNC_BLOODSUGAR,                   func_bloodsugar_form_create},
    {FUNC_BLOOD_PRESSURE,               func_bloodpressure_form_create},
    {FUNC_BREATHE,                      func_breathe_form_create},
    {FUNC_CALCULATOR,                   func_calculator_form_create},
    {FUNC_CAMERA,                       func_camera_form_create},
    {FUNC_TIMER,                        func_timer_form_create},
    {FUNC_TIMER_SUB_DISP,               func_timer_sub_disp_form_create},
    {FUNC_TIMER_SUB_CUSTOM,             func_timer_sub_custom_form_create},
    {FUNC_SLEEP,                        func_sleep_form_create},
    {FUNC_STOPWATCH,                    func_stopwatch_form_create},
    {FUNC_STOPWATCH_SUB_RECORD,         func_stopwatch_sub_record_form_create},
    {FUNC_WEATHER,                      func_weather_form_create},
    {FUNC_SPORT,                        func_sport_form_create},
    {FUNC_SPORT_CONFIG,                 func_sport_config_form_create},
    {FUNC_SPORT_SUB_RUN,                func_sport_sub_run_form_create},
    {FUNC_GAME,                         func_game_form_create},
    {FUNC_STYLE,                        func_style_form_create},
    {FUNC_FINDPHONE,                    func_findphone_form_create},
    {FUNC_ALTITUDE,                     func_altitude_form_create},
    {FUNC_MAP,                          func_map_form_create},
    {FUNC_MESSAGE,                      func_message_form_create},
    {FUNC_SCAN,                         func_scan_form_create},
    {FUNC_VOICE,                        func_voice_form_create},
    {FUNC_ALIPAY,                       func_alipay_form_create},
    {FUNC_COMPASS,                      func_compass_form_create},
    {FUNC_ADDRESS_BOOK,                 func_address_book_form_create},
    {FUNC_CALL,                         func_call_form_create},
    {FUNC_CALL_SUB_RECORD,              func_call_sub_record_form_create},
    {FUNC_CALL_SUB_DIAL,                func_call_sub_dial_form_create},
    {FUNC_SETTING,                      func_set_sub_list_form_create},
    {FUNC_CALENDAER,                    func_calender_form_create},
    {FUNC_VOLUME,                       func_volume_form_create},
    {FUNC_ACTIVITY,                     func_activity_form_create},
    {FUNC_FLASHLIGHT,                   func_flashlight_form_create},
    {FUNC_LIGHT,                        func_light_form_create},
    {FUNC_SET_SUB_DOUSING,              func_set_sub_dousing_form_create},
    {FUNC_SET_SUB_WRIST,                func_set_sub_wrist_form_create},
    {FUNC_SET_SUB_DISTURD,              func_set_sub_disturd_form_create},
    {FUNC_SET_SUB_LANGUAGE,             func_set_sub_language_form_create},
    {FUNC_SET_SUB_TIME,                 func_set_sub_time_form_create},
    {FUNC_TIME_SUB_CUSTOM,              func_time_sub_custom_form_create},
    {FUNC_SET_SUB_PASSWORD,             func_set_sub_password_form_create},
    {FUNC_PASSWORD_SUB_DISP,            func_password_sub_disp_form_create},
    {FUNC_PASSWORD_SUB_SELECT,          func_password_sub_select_form_create},
    {FUNC_SET_SUB_SAV,                  func_set_sub_sav_form_create},
    {FUNC_SET_SUB_ABOUT,                func_set_sub_about_form_create},
    {FUNC_SET_SUB_RESTART,              func_set_sub_restart_form_create},
    {FUNC_SET_SUB_RSTFY,                func_set_sub_rstfy_form_create},
    {FUNC_SET_SUB_OFF,                  func_set_sub_off_form_create},
    {FUNC_CHARGE,                       func_charge_form_create},

};

const func_t tbl_func_entry[] = {
    {FUNC_MENU,                         func_menu},                     //主菜单(蜂窝)
    {FUNC_CLOCK,                        func_clock},                    //时钟表盘
    {FUNC_SIDEBAR,                      func_clock_sub_sidebar},        //表盘右滑
    {FUNC_HEARTRATE,                    func_heartrate},                //心率
    {FUNC_ALARM_CLOCK,                  func_alarm_clock},              //闹钟
    {FUNC_ALARM_CLOCK_SUB_SET,          func_alarm_clock_sub_set},      //闹钟--设置
    {FUNC_ALARM_CLOCK_SUB_REPEAT,       func_alarm_clock_sub_repeat},   //闹钟--重复
    {FUNC_ALARM_CLOCK_SUB_EDIT,         func_alarm_clock_sub_edit},     //闹钟--编辑
    {FUNC_BLOOD_OXYGEN,                 func_blood_oxygen},             //血氧
    {FUNC_BLOODSUGAR,                   func_bloodsugar},               //血糖
    {FUNC_BLOOD_PRESSURE,               func_bloodpressure},            //血压
    {FUNC_BREATHE,                      func_breathe},                  //呼吸
    {FUNC_CALCULATOR,                   func_calculator},               //计算器
    {FUNC_CAMERA,                       func_camera},                   //相机
    {FUNC_LIGHT,                        func_light},                    //亮度调节
    {FUNC_TIMER,                        func_timer},                    //定时器
    {FUNC_TIMER_SUB_DISP,               func_timer_sub_disp},           //定时器--计时显示
    {FUNC_TIMER_SUB_CUSTOM,             func_timer_sub_custom},         //定时器--自定义
    {FUNC_SLEEP,                        func_sleep},                    //睡眠
    {FUNC_STOPWATCH,                    func_stopwatch},                //秒表
    {FUNC_STOPWATCH_SUB_RECORD,         func_stopwatch_sub_record},     //秒表--秒表记录
    {FUNC_WEATHER,                      func_weather},                  //天气
    {FUNC_SPORT,                        func_sport},                    //运动
    {FUNC_SPORT_CONFIG,                 func_sport_config},             //运动配置
    {FUNC_SPORT_SUB_RUN,                func_sport_sub_run},            //运动--室内跑步
    {FUNC_GAME,                         func_game},                     //游戏
    {FUNC_STYLE,                        func_style},                    //菜单风格
    {FUNC_ALTITUDE,                     func_altitude},                 //海拔
    {FUNC_FINDPHONE,                    func_findphone},                //寻找手机
    {FUNC_MAP,                          func_map},                      //地图
    {FUNC_MESSAGE,                      func_message_info},             //消息
    {FUNC_SCAN,                         func_scan},                     //扫一扫
    {FUNC_VOICE,                        func_voice},                    //语音助手
    {FUNC_ALIPAY,                       func_alipay},                   //支付宝
    {FUNC_COMPASS,                      func_compass},                  //指南针
    {FUNC_ADDRESS_BOOK,                 func_address_book},             //电话簿
    {FUNC_CALENDAER,                    func_calendar},                 //日历
    {FUNC_CALL,                         func_call},                     //电话
    {FUNC_CALL_SUB_RECORD,              func_call_sub_record},          //电话--最近通话
    {FUNC_CALL_SUB_DIAL,                func_call_sub_dial},            //电话--拨号
    {FUNC_VOLUME,                       func_volume},                   //音量调节
    {FUNC_ACTIVITY,                     func_activity},                 //活动记录
    {FUNC_FLASHLIGHT,                   func_flashlight},               //手电筒
    {FUNC_SETTING,                      func_set_sub_list},             //设置
    {FUNC_SET_SUB_DOUSING,              func_set_sub_dousing},          //设置--熄屏
    {FUNC_SET_SUB_WRIST,                func_set_sub_wrist},            //设置--抬腕
    {FUNC_SET_SUB_DISTURD,              func_set_sub_disturd},          //设置--勿扰
    {FUNC_SET_SUB_SAV,                  func_set_sub_sav},              //设置--声音与振动
    {FUNC_SET_SUB_LANGUAGE,             func_set_sub_language},         //设置--语言
    {FUNC_SET_SUB_TIME,                 func_set_sub_time},             //设置--时间
    {FUNC_TIME_SUB_CUSTOM,              func_time_sub_custom},          //设置--自定义时间
    {FUNC_SET_SUB_PASSWORD,             func_set_sub_password},         //设置--密码锁
    {FUNC_PASSWORD_SUB_DISP,            func_password_sub_disp},        //设置--新密码锁设置
    {FUNC_PASSWORD_SUB_SELECT,          func_password_sub_select},      //设置--密码锁确认
    {FUNC_SET_SUB_ABOUT,                func_set_sub_about},            //设置--关于
    {FUNC_SET_SUB_RESTART,              func_set_sub_restart},          //设置--重启
    {FUNC_SET_SUB_RSTFY,                func_set_sub_rstfy},            //设置--恢复出厂
    {FUNC_SET_SUB_OFF,                  func_set_sub_off},              //设置--关机
    {FUNC_CHARGE,                       func_charge},                   //充电
#if FUNC_BT_EN
    {FUNC_BT,                           func_bt},
#endif // FUNC_BT_EN
#if FUNC_BT_DUT_EN
    {FUNC_BT_DUT,                       func_bt_dut},
#endif // FUNC_BT_DUT_EN
#if FUNC_IDLE_EN
    {FUNC_IDLE,                         func_idle},
#endif // FUNC_IDLE_EN

};

void print_info(void)
{
    static u32 ticks = 0;
    if (tick_check_expire(ticks, 1000)) {
        ticks = tick_get();
//         printf("func_cb.sta[%d]", func_cb.sta);
    }
}

AT(.text.func.process)
void func_process(void)
{
    WDT_CLR();
//    print_info();

    tft_bglight_frist_set_check();
    compo_update();                                     //更新组件
    gui_process();                                      //刷新UI

    co_timer_pro(false);
    bsp_sensor_step_pro_isr();

    mp3_res_process();                                 //提示音后台处理

    if (sleep_process(bt_is_sleep)) {
        bt_cb.disp_status = 0xff;
    }

#if VBAT_DETECT_EN
    bsp_vbat_lpwr_process();
#endif

#if BT_BACKSTAGE_EN
    if (func_cb.sta != FUNC_BT) {
        bsp_bt_warning();
        uint status = bt_get_status();
        if (status > BT_STA_PLAYING) {          //来电切换
            func_cb.sta_break = func_cb.sta;
            func_cb.sta = FUNC_BT;
        }
    }
#endif

    //PWRKEY模拟硬开关关机处理
    if ((PWRKEY_2_HW_PWRON) && (sys_cb.pwrdwn_hw_flag)) {
        func_cb.sta = FUNC_PWROFF;
        sys_cb.pwrdwn_hw_flag = 0;
    }

#if CHARGE_EN
    if (xcfg_cb.charge_en) {
        charge_detect(1);
    }
#endif // CHARGE_EN

#if LE_EN
    ble_app_process();
#endif

#if FOT_EN
    bsp_fot_process();
#endif

}

//根据任务名创建窗体。此处调用的创建窗体函数不要调用子任务的控制结构体
compo_form_t *func_create_form(u8 sta)
{
    compo_form_t *frm = NULL;
    compo_form_t *(*func_create)(void) = NULL;
    for (int i = 0; i < FUNC_CREATE_CNT; i++) {
        if (tbl_func_create[i].func_idx == sta) {
            func_create = tbl_func_create[i].func;
            frm = func_create();
            break;
        }
    }
    if (frm == NULL) {
        halt(HALT_FUNC_SORT);
    }
    return frm;

}

//获取当前任务顺序
static int func_get_order(u8 sta)
{
    int i;
    for (i=0; i<func_cb.sort_cnt; i++) {
        if (sta == func_cb.tbl_sort[i]) {
            return i;
        }
    }
    return -1;
}

//切换到上一个任务
void func_switch_prev(bool flag_auto)
{
    u16 switch_mode = flag_auto ? (FUNC_SWITCH_LR_ZOOM_RIGHT | FUNC_SWITCH_AUTO) : FUNC_SWITCH_LR_ZOOM_RIGHT;
    u8 idx = func_get_order(func_cb.sta);
    if (idx <= 0) {
        return;
    }
    u8 sta = func_cb.tbl_sort[idx - 1];
    compo_form_t *frm = func_create_form(sta);                                  //创建下一个任务的窗体
    bool res = func_switching(switch_mode, NULL);                               //切换动画
    compo_form_destroy(frm);                                                    //切换完成或取消，销毁窗体
    if (res) {
        func_cb.sta = sta;
    }
}

//切换到下一个任务
void func_switch_next(bool flag_auto)
{
    u16 switch_mode = flag_auto ? (FUNC_SWITCH_LR_ZOOM_LEFT | FUNC_SWITCH_AUTO) : FUNC_SWITCH_LR_ZOOM_LEFT;
    u8 idx = func_get_order(func_cb.sta);
    if (idx < 0 || idx >= func_cb.sort_cnt - 1) {
        return;
    }
    u8 sta = func_cb.tbl_sort[idx + 1];
    compo_form_t *frm = func_create_form(sta);                                  //创建下一个任务的窗体
    bool res = func_switching(switch_mode, NULL);                               //切换动画
    compo_form_destroy(frm);                                                    //切换完成或取消，销毁窗体
    if (res) {
        func_cb.sta = sta;
    }
}


//切换
void func_switch_to(u8 sta, u16 switch_mode)
{
    compo_form_t *frm = func_create_form(sta);                          		//创建下一个任务的窗体
    func_switching(switch_mode, NULL);         									//切换动画
    compo_form_destroy(frm);                                                    //切换完成或取消，销毁窗体
    func_cb.sta = sta;
}

//切换回主时钟
void func_switch_to_clock(void)
{
    func_switch_to(FUNC_CLOCK, FUNC_SWITCH_LR_ZOOM_RIGHT | FUNC_SWITCH_AUTO);
}


//退回到主菜单
void func_switch_to_menu(void)
{
    u16 switch_mode;
    bool flag_frm_menu;                                                         //是否需要创建菜单窗体
    flag_frm_menu = true;
    if (func_cb.sta != FUNC_CLOCK || func_cb.menu_style == MENU_STYLE_HONEYCOMB) {
        switch_mode = FUNC_SWITCH_ZOOM_EXIT | FUNC_SWITCH_AUTO;
    } else if (func_cb.menu_style == MENU_STYLE_WATERFALL) {
        switch_mode = FUNC_SWITCH_FADE_OUT | FUNC_SWITCH_AUTO;
        func_cb.flag_animation = true;                                          //淡出后进入入场动画
        flag_frm_menu = false;
    } else {
        switch_mode = FUNC_SWITCH_ZOOM_FADE_EXIT | FUNC_SWITCH_AUTO;
    }
    if (flag_frm_menu) {
        widget_icon_t *icon;
        compo_form_t *frm = func_create_form(FUNC_MENU);                        //创建下一个任务的窗体
        component_t *compo = compo_get_next((component_t *)frm);
        if (compo->type == COMPO_TYPE_ICONLIST) {
            compo_iconlist_t *iconlist = (compo_iconlist_t *)compo;
            icon = compo_iconlist_select_byidx(iconlist, func_cb.menu_idx);
        } else if (compo->type == COMPO_TYPE_LISTBOX) {
            compo_listbox_t *listbox = (compo_listbox_t *)compo;
            icon = compo_listbox_select_byidx(listbox, func_cb.menu_idx);
        } else if(compo->type == COMPO_TYPE_GRIDBOX) {
            compo_gridbox_t *gridbox = (compo_gridbox_t *)compo;
            icon = compo_gridbox_select_byidx(gridbox, func_cb.menu_idx);
        } else if (compo->type == COMPO_TYPE_DISKLIST) {
            compo_disklist_t *disklist = (compo_disklist_t *)compo;
            icon = compo_disklist_select_byidx(disklist, func_cb.menu_idx);
        } else if (compo->type == COMPO_TYPE_KALEIDOSCOPE) {
            compo_kaleidoscope_t *kale = (compo_kaleidoscope_t *)compo;
            icon = compo_kale_select_byidx(kale, func_cb.menu_idx);
        } else if (compo->type == COMPO_TYPE_RINGS) {
            compo_rings_t *rings = (compo_rings_t *)compo;
            icon = compo_rings_select_byidx(rings, func_cb.menu_idx);
        } else {
            halt(HALT_GUI_COMPO_ICONLIST_TYPE);
            return;
        }
        func_switching(switch_mode, icon);                                      //退出动画
        compo_form_destroy(frm);                                                //切换完成或取消，销毁窗体
    } else {
        func_switching(switch_mode, NULL);                                      //退出动画
    }
    func_cb.sta = FUNC_MENU;
}

//手动退回到主菜单
void func_switching_to_menu(void)
{
    widget_icon_t *icon;
    u16 switch_mode;
    compo_form_t *frm = func_create_form(FUNC_MENU);                            //创建下一个任务的窗体
    component_t *compo = compo_get_next((component_t *)frm);
    if (compo->type == COMPO_TYPE_ICONLIST) {
        compo_iconlist_t *iconlist = (compo_iconlist_t *)compo;
        icon = compo_iconlist_select_byidx(iconlist, func_cb.menu_idx);
    } else if (compo->type == COMPO_TYPE_LISTBOX) {
        compo_listbox_t *listbox = (compo_listbox_t *)compo;
        icon = compo_listbox_select_byidx(listbox, func_cb.menu_idx);
    } else if(compo->type == COMPO_TYPE_GRIDBOX) {
        compo_gridbox_t *gridbox = (compo_gridbox_t *)compo;
        icon = compo_gridbox_select_byidx(gridbox, func_cb.menu_idx);
    } else if (compo->type == COMPO_TYPE_DISKLIST) {
        compo_disklist_t *disklist = (compo_disklist_t *)compo;
        icon = compo_disklist_select_byidx(disklist, func_cb.menu_idx);
    } else if (compo->type == COMPO_TYPE_KALEIDOSCOPE) {
        compo_kaleidoscope_t *kale = (compo_kaleidoscope_t *)compo;
        icon = compo_kale_select_byidx(kale, func_cb.menu_idx);
    } else if (compo->type == COMPO_TYPE_RINGS) {
            compo_rings_t *rings = (compo_rings_t *)compo;
            icon = compo_rings_select_byidx(rings, func_cb.menu_idx);
    } else {
        halt(HALT_GUI_COMPO_ICONLIST_TYPE);
        return;
    }
    if (func_cb.sta != FUNC_CLOCK || func_cb.menu_style == MENU_STYLE_HONEYCOMB) {
        switch_mode = FUNC_SWITCH_ZOOM_EXIT;
    } else {
        switch_mode = FUNC_SWITCH_ZOOM_FADE_EXIT;
    }
    bool res = func_switching(switch_mode, icon);                               //退出动画
    compo_form_destroy(frm);                                                    //切换完成或取消，销毁窗体
    if (res) {
        func_cb.sta = FUNC_MENU;
    }
}

void evt_message(size_msg_t msg)
{
    switch (msg) {
        case EVT_HFP_SET_VOL:
            if(sys_cb.incall_flag & INCALL_FLAG_SCO){
                bsp_change_volume(bsp_bt_get_hfp_vol(sys_cb.hfp_vol));
                printf("HFP SET VOL: %d\n", sys_cb.hfp_vol);
            }
            break;

        case EVT_A2DP_SET_VOL:
            if ((sys_cb.incall_flag & INCALL_FLAG_SCO) == 0) {
                printf("A2DP SET VOL: %d\n", sys_cb.vol);
                bsp_change_volume(sys_cb.vol);
//                gui_box_show_vol();
                param_sys_vol_write();
                sys_cb.cm_times = 0;
                sys_cb.cm_vol_change = 1;
            }
            break;

        case EVT_A2DP_MUSIC_PLAY:
            if (!sbc_is_bypass()) {
                dac_fade_in();
            }
            break;

        case EVT_A2DP_MUSIC_STOP:
            if (!sbc_is_bypass()) {
                dac_fade_out();
            }
            break;

        case EVT_UDE_SET_VOL:
            bsp_change_volume(sys_cb.vol);
//            gui_box_show_vol();
            param_sys_vol_write();
            sys_cb.cm_times = 0;
            sys_cb.cm_vol_change = 1;
            break;

        case EVT_BT_SCAN_START:
            if (bt_get_status() < BT_STA_SCANNING) {
                bt_scan_enable();
            }
            break;
#if EQ_DBG_IN_UART || EQ_DBG_IN_SPP
        case EVT_ONLINE_SET_EQ:
            eq_parse_cmd();
            break;
#endif

#if EQ_MODE_EN
        case EVT_BT_SET_EQ:
            music_set_eq_by_num(sys_cb.eq_mode);
            break;
#endif
    }
}

//func common message process
void func_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_SHORT_LEFT:
        if (func_cb.sta == FUNC_CLOCK || func_cb.last != FUNC_MENU) {
            func_switch_next(false);                    //切到下一个任务
        }
        break;

    case MSG_CTP_SHORT_RIGHT:
        if (func_cb.last == FUNC_CLOCK){
            func_switch_to(FUNC_CLOCK, FUNC_SWITCH_LR_ZOOM_RIGHT);
        } else if (func_cb.sta == FUNC_CLOCK || func_cb.last != FUNC_MENU) {
            func_switch_prev(false);                    //切到上一个任务
        } else /*if (ctp_get_sxy().x <= 32)*/ {
            func_switching_to_menu();                   //右滑缓慢退出任务
        }
        break;

    case MSG_CTP_COVER:
        sys_cb.sleep_delay = 1; //100ms后进入休眠
        break;

    case MSG_QDEC_FORWARD:
        if (func_cb.sta == FUNC_CLOCK || func_cb.last != FUNC_MENU) {
            func_switch_next(true);                     //切到下一个任务
        }
        break;

    case MSG_QDEC_BACKWARD:
        if (func_cb.sta == FUNC_CLOCK || func_cb.last != FUNC_MENU) {
            func_switch_prev(true);                     //切到下一个任务
        }
        break;

    case KU_BACK:
        if (func_cb.sta != FUNC_CLOCK && func_cb.last != FUNC_MENU && func_get_order(func_cb.sta) >= 0) {
            func_switch_to_clock();                     //切换回主时钟
        } else {
            func_switch_to_menu();                      //退回到主菜单
        }
        break;

#if SOFT_POWER_ON_OFF
        case KLH_BACK:
        case KLH_LEFT:
        case KLH_RIGHT:
            func_cb.sta = FUNC_PWROFF;
            break;
#endif

        case KU_MODE:
            func_cb.sta = FUNC_NULL;
            break;

//        case KU_LEFT:
//            ble_bt_connect();               //ios一键双连测试
//            printf("send sm req\n");
//            break;

//#if EQ_MODE_EN
//        case KU_EQ:
//            sys_set_eq();
//            break;
//#endif // EQ_MODE_EN
//
//        case KU_MUTE:
//            if (sys_cb.mute) {
//                bsp_sys_unmute();
//            } else {
//                bsp_sys_mute();
//            }
//            break;
//
        case MSG_SYS_500MS:
            break;

        case MSG_SYS_1S:
#if BT_HFP_BAT_REPORT_EN
            bt_hfp_report_bat();
#endif
            bat_percent_update();
            break;

        default:
            evt_message(msg);
            break;
    }
    //调节音量，3秒后写入flash
    if ((sys_cb.cm_vol_change) && (sys_cb.cm_times >= 6)) {
        sys_cb.cm_vol_change = 0;
        cm_sync();
    }
}

///进入一个功能的总入口
AT(.text.func)
void func_enter(void)
{
    //检查Func Heap
    u32 heap_size = func_heap_get_free_size();
    if (heap_size != HEAP_FUNC_SIZE) {
        TRACE("Func heap leak (%d -> %d): %d\n", func_cb.last, func_cb.sta, heap_size);
        halt(HALT_FUNC_HEAP);
    }

//    gui_box_clear();
    param_sync();
    reset_sleep_delay_all();
    reset_pwroff_delay();
    func_cb.mp3_res_play = NULL;
    func_cb.set_vol_callback = NULL;
    bsp_clr_mute_sta();
    sys_cb.voice_evt_brk_en = 1;    //播放提示音时，快速响应事件。
    AMPLIFIER_SEL_D();
}

AT(.text.func)
void func_exit(void)
{
    //销毁窗体
    if (func_cb.frm_main != NULL) {
        compo_form_destroy(func_cb.frm_main);
    }
    //释放FUNC控制结构体
    if (func_cb.f_cb != NULL) {
        func_free(func_cb.f_cb);
    }
    func_cb.frm_main = NULL;
    func_cb.f_cb = NULL;
}

AT(.text.func)
void func_run(void)
{
    void (*func_entry)(void) = NULL;
    printf("%s\n", __func__);
    memset(func_cb.tbl_sort, 0, sizeof(func_cb.tbl_sort));
    func_cb.tbl_sort[0] = FUNC_CLOCK;
    func_cb.tbl_sort[1] = FUNC_HEARTRATE;
    func_cb.tbl_sort[2] = FUNC_BT;
    func_cb.sort_cnt = 3;
    func_cb.sta = FUNC_CLOCK;
    for (;;) {
        func_enter();
        for (int i = 0; i < FUNC_ENTRY_CNT; i++) {
            if (tbl_func_entry[i].func_idx == func_cb.sta) {
                func_entry = tbl_func_entry[i].func;
                func_entry();
                break;
            }
        }
        if (func_cb.sta == FUNC_PWROFF) {
            func_pwroff(1);
        }
        func_exit();
    }
}
