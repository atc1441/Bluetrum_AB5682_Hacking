#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define TXT_CNT     181

typedef struct f_game_t_ {
    bool flag_drag;                 //开始拖动
    s32 x_pos;
    s32 y_pos;
    s32 x;
    s32 y;
    u8 flag_txt;
    const char *buf;
} f_game_t;

enum{
  COMPO_ID_TXT_NUM1 = 1,
  COMPO_ID_TXT_NUM2,
};

static const char txt_buf[] = "没错，唐三的父亲唐昊，就是一个铁匠，村子里唯一的铁匠 \
在这个世界之中，铁匠可以说是最低贱的职业之一，因为某种特殊的原因，这个世界的顶级武器都不是由铁匠锻造出来的。\
但是，作为这个村子里唯一的铁匠，原本唐三家是不应该这样贫穷的，但是，那点微薄的收入却大都……\
一进家门，唐三就已经闻到了扑鼻的饭香，那并不是唐昊为他做的早点，而是他为唐昊做的 \
从四岁开始，唐三的身高还够不到灶台的时候，做饭的任务就已经是他每天必须的工作。哪怕是要踩着凳子才能够到灶台上面。\
并不是唐昊要求他这么做的，而是因为不这样，唐三几乎就没有能吃饱的时候。\
来到灶台前，熟练的踩上木凳，掀开大铁锅的锅盖，扑鼻的米香传来，锅里的粥早已煮的烂熟。\
每天上山之前，唐三都会将米下锅，弄好柴火，等他回来时，粥也煮好了。\
拿起灶台旁已经破损了十个以上缺口的两个碗，唐三小心翼翼的盛了两碗粥，放在身后的桌子上。粥里的米粒几乎一眼就能数出来，对于正是长身体中的唐三，这点营养显然是不够的，这也是为什么他的身体如此纤瘦的原因。\
“爸爸，吃饭了。”唐三叫道。\
半晌后，里间的门帘掀起，一个高大的身影迈着有些踉跄的步伐走了出来。\
那是一名中年男子，看上去大约有接近五十岁的样子，但身材却非常高大魁梧，只是他的打扮却令人不敢恭维。\
破损的袍子穿在身上，上面甚至连补丁都没有，露出下面古铜色的皮肤，原本还算端正的五官却蒙着一层蜡黄色，一副睡眼朦胧的样子，头发乱糟糟的像鸟窝一般，一脸的胡子已经不知道有多少日子没有整理过了。目光呆滞而昏黄，尽管已经过去了一晚，但他身上那扑鼻的酒气还是令唐三不禁皱了皱眉头。\
这就是唐昊，唐三在这个世界的父亲。\
从小到大，唐三就不知道什么叫父爱，唐昊对他，从来都是不管不顾的，刚开始的时候，还会做点饭给他吃，但随着时间的推移，当唐三开始主动做饭之后，唐昊就更是什么都不管了。家里如此贫穷，甚至连像样的桌椅都没有，吃饭也成问题，最主要的原因就是唐昊将那份微薄的铁匠收入都换了酒喝。\
和唐三一边大的孩子，父亲一般也就是三十岁左右，结婚早的甚至还不到三十岁，可唐昊看起来却要比他们苍老的多，反倒像是唐三的爷爷一般。\
";

//创建游戏窗体
compo_form_t *func_game_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_GAME]);

    f_game_t *gm = (f_game_t *)func_cb.f_cb;
    gm->buf = txt_buf;

    //创建文本
    compo_textbox_t *txt_one = compo_textbox_create(frm, 180);
    compo_textbox_set_multiline(txt_one, true);
    compo_textbox_set_location(txt_one, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y, 320, 31);
    compo_setid(txt_one, COMPO_ID_TXT_NUM1);
    char text[TXT_CNT];
    strncpy(text, &gm->buf[0], TXT_CNT);
    compo_textbox_set(txt_one, text);

    compo_textbox_t *txt_tws = compo_textbox_create(frm, 180);
    compo_textbox_set_multiline(txt_tws, true);
    compo_textbox_set_location(txt_tws, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y, 320, 31);
    compo_setid(txt_tws, COMPO_ID_TXT_NUM2);
    compo_textbox_set_visible(txt_tws, false);

    return frm;
}

//游戏功能事件处理
static void func_game_process(void)
{
    func_process();
}

//游戏功能消息处理
static void func_game_message(size_msg_t msg)
{
    f_game_t *gm = (f_game_t *)func_cb.f_cb;
    char text[TXT_CNT];
    compo_textbox_t *txt_start = compo_getobj_byid(COMPO_ID_TXT_NUM1);
    compo_textbox_t *txt_end = compo_getobj_byid(COMPO_ID_TXT_NUM2);

    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
    case MSG_CTP_SHORT_DOWN:
        gm->flag_drag = true;
        break;

    case MSG_CTP_SHORT_LEFT:
            compo_textbox_set_visible(txt_start, false);
            widget_set_pos(txt_end->comm.txt, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y);
            gm->flag_txt++;
            strncpy(text, &gm->buf[TXT_CNT * (gm->flag_txt)], TXT_CNT);
            compo_textbox_set(txt_end, text);
            compo_textbox_set_visible(txt_end, true);
        break;

    case MSG_CTP_SHORT_RIGHT:
        if (gm->flag_txt > 0) {
            compo_textbox_set_visible(txt_end, false);
            widget_set_pos(txt_start->comm.txt, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y);
            gm->flag_txt--;
            strncpy(text, &gm->buf[TXT_CNT * (gm->flag_txt)], TXT_CNT);
            compo_textbox_set(txt_start, text);
            compo_textbox_set_visible(txt_start, true);
        }
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入游戏功能
static void func_game_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_game_t));
    func_cb.frm_main = func_game_form_create();
    f_game_t *gm = (f_game_t *)func_cb.f_cb;
    gm->flag_txt = 0;
}

//退出游戏功能
static void func_game_exit(void)
{
    func_cb.last = FUNC_GAME;
}

//游戏功能
void func_game(void)
{
    printf("%s\n", __func__);
    func_game_enter();
    while (func_cb.sta == FUNC_GAME) {
        func_game_process();
        func_game_message(msg_dequeue());
    }
    func_game_exit();
}
