#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif


//秒表状态
enum {
    STOPWATCH_STA_IDLE,
    STOPWATCH_STA_WORKING,
};

//组件ID
enum {
    //按键
    COMPO_ID_BTN_RECORD_VIEW = 1,       //查看记录
    COMPO_ID_BTN_RECORD,                //记录当前时间
    COMPO_ID_BTN_AFRESH,                //重新开始
    COMPO_ID_BTN_START_REC,             //开始计时

    //图像
	COMPO_ID_PIC_RECORD_VIEW_CLICK,     //按钮触摸效果图
	COMPO_ID_PIC_RECORD_CLICK,
	COMPO_ID_PIC_AFRESH_CLICK,
	COMPO_ID_PIC_START_REC,
	COMPO_ID_PIC_START_REC_CLICK,
	COMPO_ID_PIC_PAUSE_REC,
	COMPO_ID_PIC_PAUSE_REC_CLICK,

	//数字
	COMPO_ID_NUM_STOPWATCH_REC,         //记录数
	COMPO_ID_NUM_STOPWATCH_REC_CLICK,   //记录数
	COMPO_ID_NUM_STOPWATCH_MIN,         //分
	COMPO_ID_NUM_STOPWATCH_SEC,         //秒
	COMPO_ID_NUM_STOPWATCH_MSEC,        //毫秒

};

typedef struct f_stopwatch_t_ {
    u8 sta;
    u8 min;                 //分
    u8 sec;                 //秒
    u8 msec;                //毫秒
    u32 total_msec;         //总毫秒
    u32 total_rec;          //总计当前记录的个数
} f_stopwatch_t;

typedef struct stopwatch_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
    bool visible_en;
} stopwatch_btn_item_t;

#define STOPWATCH_BTN_ITEM_CNT                       ((int)(sizeof(tbl_stopwatch_btn_item) / sizeof(tbl_stopwatch_btn_item[0])))

//搞个按键item，创建时遍历一下
static const stopwatch_btn_item_t tbl_stopwatch_btn_item[] = {
    {UI_BUF_STOPWATCH_RECORD1_BIN,       COMPO_ID_BTN_RECORD_VIEW,      160,    93,     true},
    {UI_BUF_STOPWATCH_RECORD_BIN,        COMPO_ID_BTN_RECORD,           265,    321,    true},
    {UI_BUF_STOPWATCH_AFRESH_BIN,        COMPO_ID_BTN_AFRESH,           55,     321,    true},
};

typedef struct stopwatch_pic_item_t_ {
    u32 res_addr;
    u16 pic_id;
    s16 x;
    s16 y;
    bool visible_en;
} stopwatch_pic_item_t;

#define STOPWATCH_PIC_ITEM_CNT                       ((int)(sizeof(tbl_stopwatch_pic_item) / sizeof(tbl_stopwatch_pic_item[0])))

//搞个图片item，创建时遍历一下
static const stopwatch_pic_item_t tbl_stopwatch_pic_item[] = {
    {UI_BUF_STOPWATCH_RECORD1_CLICK_BIN,       COMPO_ID_PIC_RECORD_VIEW_CLICK,      160,    93,     false},
    {UI_BUF_STOPWATCH_RECORD_CLICK_BIN,        COMPO_ID_PIC_RECORD_CLICK,           265,    321,    false},
    {UI_BUF_STOPWATCH_AFRESH_CLICK_BIN,        COMPO_ID_PIC_AFRESH_CLICK,           55,     321,    false},
    {UI_BUF_COMMON_START_BIN,                  COMPO_ID_PIC_START_REC,              160,    321,    true},
    {UI_BUF_COMMON_START_CLICK_BIN,            COMPO_ID_PIC_START_REC_CLICK,        160,    321,    false},
    {UI_BUF_COMMON_PAUSE_BIN,                  COMPO_ID_PIC_PAUSE_REC,              160,    321,    false},
    {UI_BUF_COMMON_PAUSE_CLICK_BIN,            COMPO_ID_PIC_PAUSE_REC_CLICK,        160,    321,    false},
};

typedef struct stopwatch_num_item_t_ {
    u32 res_addr;
    int num_cnt;
    u16 num_id;
    int val;
    s16 x;
    s16 y;
    bool zfill_en;
    bool visible_en;
} stopwatch_num_item_t;

#define STOPWATCH_NUM_ITEM_CNT                       ((int)(sizeof(tbl_stopwatch_num_item) / sizeof(tbl_stopwatch_num_item[0])))

//搞个数字item，创建时遍历一下
static const stopwatch_num_item_t tbl_stopwatch_num_item[] = {
    /*   res_addr,                          num_cnt,           num_id,                       val,   x,     y,  zfill_en, visible_en*/
    {UI_BUF_STOPWATCH_NUM1_16_24_BIN,           2,         COMPO_ID_NUM_STOPWATCH_REC,        0,   177,    93,    true,   true},
    {UI_BUF_STOPWATCH_NUM1_16_24_CLICK_BIN,     2,         COMPO_ID_NUM_STOPWATCH_REC_CLICK,  0,   177,    93,    true,   false},
    {UI_BUF_COMMON_NUM_30_46_BIN,               2,         COMPO_ID_NUM_STOPWATCH_MSEC,       0,   238,    179,   true,   true},
    {UI_BUF_COMMON_NUM_30_46_BIN,               2,         COMPO_ID_NUM_STOPWATCH_MIN,        0,   84,     179,   true,   true},
    {UI_BUF_COMMON_NUM_30_46_BIN,               2,         COMPO_ID_NUM_STOPWATCH_SEC,        0,   162,    179,   true,   true},

};

//创建秒表窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_stopwatch_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);
	compo_form_add_image(frm, UI_BUF_COMMON_COLON_NUM_30_46_BIN, 122, 179);
	compo_form_add_image(frm, UI_BUF_COMMON_POINT_NUM_30_46_BIN, 198, 198);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_STOP_WATCH]);

	//新建按钮
    compo_button_t *btn;
    btn = compo_button_create(frm);
    compo_setid(btn, COMPO_ID_BTN_START_REC);
    compo_button_set_location(btn, 160, 321, 100, 100);

    for (u8 idx = 0; idx < STOPWATCH_BTN_ITEM_CNT; idx++) {
        btn = compo_button_create_by_image(frm, tbl_stopwatch_btn_item[idx].res_addr);
        compo_setid(btn, tbl_stopwatch_btn_item[idx].btn_id);
        compo_button_set_pos(btn, tbl_stopwatch_btn_item[idx].x, tbl_stopwatch_btn_item[idx].y);
        compo_button_set_visible(btn, tbl_stopwatch_btn_item[idx].visible_en);
    }

    //新建图像
    compo_picturebox_t *pic_click;
    for (u8 idx = 0; idx < STOPWATCH_PIC_ITEM_CNT; idx++) {
        pic_click = compo_picturebox_create(frm, tbl_stopwatch_pic_item[idx].res_addr);
        compo_setid(pic_click, tbl_stopwatch_pic_item[idx].pic_id);
        compo_picturebox_set_pos(pic_click, tbl_stopwatch_pic_item[idx].x, tbl_stopwatch_pic_item[idx].y);
        compo_picturebox_set_visible(pic_click, tbl_stopwatch_pic_item[idx].visible_en);
    }

	//创建数字
    compo_number_t *num;
    u8 min, sec, msec;
    min = ((sys_cb.stopwatch_total_msec / 100) % 3600) / 60;
    sec = (sys_cb.stopwatch_total_msec / 100) % 60;
    msec = sys_cb.stopwatch_total_msec % 100;
    for (u8 idx = 0; idx < STOPWATCH_NUM_ITEM_CNT; idx++) {
        num = compo_number_create(frm, tbl_stopwatch_num_item[idx].res_addr, tbl_stopwatch_num_item[idx].num_cnt);
        compo_setid(num, tbl_stopwatch_num_item[idx].num_id);
        compo_number_set_pos(num, tbl_stopwatch_num_item[idx].x, tbl_stopwatch_num_item[idx].y);
        compo_number_set_zfill(num, tbl_stopwatch_num_item[idx].zfill_en);
        compo_number_set_visible(num, tbl_stopwatch_num_item[idx].visible_en);

        if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_REC) {
            compo_number_set(num, sys_cb.stopwatch_rec_cnt);
        } else if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_MIN) {
            compo_number_set(num, min);
        } else if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_SEC) {
            compo_number_set(num, sec);
        } else if (tbl_stopwatch_num_item[idx].num_id == COMPO_ID_NUM_STOPWATCH_MSEC) {
            compo_number_set(num, msec);
        }
    }

    return frm;
}

//触摸按钮效果处理
static void func_stopwatch_button_touch_handle(void)
{
    int id = compo_get_button_id();
    f_stopwatch_t *f_stopwatch = (f_stopwatch_t *)func_cb.f_cb;

    //获取图片组件的地址
    compo_picturebox_t *pic_rec_view_click = compo_getobj_byid(COMPO_ID_PIC_RECORD_VIEW_CLICK);
    compo_picturebox_t *pic_rec_click = compo_getobj_byid(COMPO_ID_PIC_RECORD_CLICK);
    compo_picturebox_t *pic_afresh_click = compo_getobj_byid(COMPO_ID_PIC_AFRESH_CLICK);
    compo_picturebox_t *pic_start_click = compo_getobj_byid(COMPO_ID_PIC_START_REC_CLICK);
    compo_picturebox_t *pic_pause_click = compo_getobj_byid(COMPO_ID_PIC_PAUSE_REC_CLICK);

    //获取数字组件的地址
    compo_number_t *num_rec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_REC);
    compo_number_t *num_rec_click = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_REC_CLICK);

    switch (id) {
    case COMPO_ID_BTN_RECORD_VIEW:
        compo_picturebox_set_visible(pic_rec_view_click, true);
        compo_number_set_visible(num_rec, false);
        compo_number_set_visible(num_rec_click, true);
        break;

    case COMPO_ID_BTN_RECORD:
        compo_picturebox_set_visible(pic_rec_click, true);
        break;

    case COMPO_ID_BTN_AFRESH:
        compo_picturebox_set_visible(pic_afresh_click, true);
        break;

    case COMPO_ID_BTN_START_REC:
        if (f_stopwatch->sta == STOPWATCH_STA_IDLE) {
            compo_picturebox_set_visible(pic_start_click, true);
        } else if (f_stopwatch->sta == STOPWATCH_STA_WORKING) {
            compo_picturebox_set_visible(pic_pause_click, true);
        }
        break;

    default:
        break;
    }

}

//释放按钮效果处理
static void func_stopwatch_button_release_handle(void)
{
    //获取图片组件的地址
    compo_picturebox_t *pic_rec_view_click = compo_getobj_byid(COMPO_ID_PIC_RECORD_VIEW_CLICK);
    compo_picturebox_t *pic_rec_click = compo_getobj_byid(COMPO_ID_PIC_RECORD_CLICK);
    compo_picturebox_t *pic_afresh_click = compo_getobj_byid(COMPO_ID_PIC_AFRESH_CLICK);
    compo_picturebox_t *pic_start_click = compo_getobj_byid(COMPO_ID_PIC_START_REC_CLICK);
    compo_picturebox_t *pic_pause_click = compo_getobj_byid(COMPO_ID_PIC_PAUSE_REC_CLICK);

    compo_picturebox_set_visible(pic_rec_view_click, false);
    compo_picturebox_set_visible(pic_rec_click, false);
    compo_picturebox_set_visible(pic_afresh_click, false);
    compo_picturebox_set_visible(pic_start_click, false);
    compo_picturebox_set_visible(pic_pause_click, false);

    //获取数字组件的地址
    compo_number_t *num_rec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_REC);
    compo_number_t *num_rec_click = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_REC_CLICK);

    compo_number_set_visible(num_rec_click, false);
    compo_number_set_visible(num_rec, true);
}

//单击按钮
static void func_stopwatch_button_click(void)
{
    int id = compo_get_button_id();
    f_stopwatch_t *f_stopwatch = (f_stopwatch_t *)func_cb.f_cb;

    //获取图片组件的地址
    compo_picturebox_t *pic_pause = compo_getobj_byid(COMPO_ID_PIC_PAUSE_REC);
    compo_picturebox_t *pic_start = compo_getobj_byid(COMPO_ID_PIC_START_REC);

    //获取数字组件的地址
    compo_number_t *num_rec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_REC);
    compo_number_t *num_rec_click = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_REC_CLICK);
    compo_number_t *num_min = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_MIN);
    compo_number_t *num_sec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_SEC);
    compo_number_t *num_msec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_MSEC);


    switch (id) {
    case COMPO_ID_BTN_RECORD_VIEW:
        sys_cb.stopwatch_total_msec = f_stopwatch->total_msec;
        func_cb.sta = FUNC_STOPWATCH_SUB_RECORD;
        break;

    case COMPO_ID_BTN_RECORD:
        if (f_stopwatch->total_rec < STOPWATCH_REC_NUM_MAX) {
            f_stopwatch->total_rec++;
        } else {
            f_stopwatch->total_rec = 1;
            memset(sys_cb.stopwatch_rec_view, 0, sizeof(sys_cb.stopwatch_rec_view));
        }
        sys_cb.stopwatch_rec_cnt = f_stopwatch->total_rec;
        sys_cb.stopwatch_rec_view[f_stopwatch->total_rec - 1] = f_stopwatch->total_msec;

        compo_number_set(num_rec, f_stopwatch->total_rec);
        compo_number_set(num_rec_click, f_stopwatch->total_rec);
        break;

    case COMPO_ID_BTN_AFRESH:
        f_stopwatch->sta = STOPWATCH_STA_IDLE;
        f_stopwatch->min = 0;
        f_stopwatch->sec = 0;
        f_stopwatch->msec = 0;
        f_stopwatch->total_msec = 0;
        f_stopwatch->total_rec = 0;

        memset(sys_cb.stopwatch_rec_view, 0, sizeof(sys_cb.stopwatch_rec_view));
        sys_cb.stopwatch_rec_cnt = 0;
        sys_cb.stopwatch_total_msec = 0;

        compo_picturebox_set_visible(pic_pause, false);
        compo_picturebox_set_visible(pic_start, true);

        compo_number_set(num_min, f_stopwatch->min);
        compo_number_set(num_sec, f_stopwatch->sec);
        compo_number_set(num_msec, f_stopwatch->msec);
        compo_number_set(num_rec, f_stopwatch->total_rec);
        compo_number_set(num_rec_click, f_stopwatch->total_rec);
        break;

    case COMPO_ID_BTN_START_REC:
        if (f_stopwatch->sta == STOPWATCH_STA_IDLE) {
            f_stopwatch->sta = STOPWATCH_STA_WORKING;

            compo_picturebox_set_visible(pic_pause, true);
            compo_picturebox_set_visible(pic_start, false);
        } else if (f_stopwatch->sta == STOPWATCH_STA_WORKING) {
            f_stopwatch->sta = STOPWATCH_STA_IDLE;

            compo_picturebox_set_visible(pic_pause, false);
            compo_picturebox_set_visible(pic_start, true);
        }
        break;
    }

    func_stopwatch_button_release_handle();
}

//秒表功能事件处理
static void func_stopwatch_process(void)
{
    f_stopwatch_t *f_stopwatch = (f_stopwatch_t *)func_cb.f_cb;

    //获取数字组件的地址
    compo_number_t *num_min = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_MIN);
    compo_number_t *num_sec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_SEC);
    compo_number_t *num_msec = compo_getobj_byid(COMPO_ID_NUM_STOPWATCH_MSEC);

    static u32 stopwatch_ticks = 0;

    if (tick_check_expire(stopwatch_ticks, 10) && f_stopwatch->sta == STOPWATCH_STA_WORKING) {
        stopwatch_ticks = tick_get();

        f_stopwatch->total_msec++;
        f_stopwatch->min = ((f_stopwatch->total_msec / 100) % 3600) / 60;
        f_stopwatch->sec = (f_stopwatch->total_msec / 100) % 60;
        f_stopwatch->msec = f_stopwatch->total_msec % 100;

        compo_number_set(num_min, f_stopwatch->min);
        compo_number_set(num_sec, f_stopwatch->sec);
        compo_number_set(num_msec, f_stopwatch->msec);

//        printf("total_msec:%d, min:%d, sec:%d, msec:%d\n", f_stopwatch->total_msec, f_stopwatch->min, f_stopwatch->sec, f_stopwatch->msec);
    }

    func_process();
}

//秒表功能消息处理
static void func_stopwatch_message(size_msg_t msg)
{

    switch (msg) {
    case MSG_CTP_TOUCH:
        func_stopwatch_button_touch_handle();
        break;

    case MSG_CTP_CLICK:
        func_stopwatch_button_click();
        break;

    case MSG_CTP_SHORT_UP:
    case MSG_CTP_SHORT_DOWN:
    case MSG_CTP_SHORT_LEFT:
    case MSG_CTP_LONG:
        func_stopwatch_button_release_handle();
        break;

    case MSG_CTP_SHORT_RIGHT:
        func_stopwatch_button_release_handle();
        if (func_cb.last == FUNC_CLOCK){
            func_switch_to(FUNC_CLOCK, FUNC_SWITCH_LR_ZOOM_RIGHT);
        } else {
            func_switching_to_menu();
        }
        break;

    case MSG_QDEC_FORWARD:
    case MSG_QDEC_BACKWARD:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入秒表功能
static void func_stopwatch_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_stopwatch_t));
    func_cb.frm_main = func_stopwatch_form_create();

    //恢复上次的数据
    f_stopwatch_t *f_stopwatch = (f_stopwatch_t *)func_cb.f_cb;
    f_stopwatch->total_msec = sys_cb.stopwatch_total_msec;
    f_stopwatch->total_rec = sys_cb.stopwatch_rec_cnt;
}

//退出秒表功能
static void func_stopwatch_exit(void)
{
    //保存一下数据
    f_stopwatch_t *f_stopwatch = (f_stopwatch_t *)func_cb.f_cb;
    sys_cb.stopwatch_total_msec = f_stopwatch->total_msec;

    func_cb.last = FUNC_STOPWATCH;
}

//秒表功能
void func_stopwatch(void)
{
    printf("%s\n", __func__);
    func_stopwatch_enter();
    while (func_cb.sta == FUNC_STOPWATCH) {
        func_stopwatch_process();
        func_stopwatch_message(msg_dequeue());
    }
    func_stopwatch_exit();
}
