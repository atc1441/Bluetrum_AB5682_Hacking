#ifndef _FUNC_CLOCK_H
#define _FUNC_CLOCK_H


#define DP_HEADER_FORMAT   0x4657
#define DP_HEADER          10
#define DP_RES_HEADER      20
#define UI_BUF_WATCH_DIY    0xffffffff

enum {
    DP_TYPE_NULL,
    DP_TYPE_POINTER,
    DP_TYPE_IMAGE,
    DP_TYPE_TEXT,
    DP_TYPE_NUM,
    DP_TYPE_ANIMATION,
    DP_TYPE_AREA,

};

enum {
    FUNC_CLOCK_MAIN,
    FUNC_CLOCK_SUB_DROPDOWN,
    FUNC_CLOCK_SUB_PULLUP,
    FUNC_CLOCK_SUB_SIDE,
    FUNC_CLOCK_SUB_ROTARY,
};

typedef struct f_clock_t_ {
    u8 sta;
    u8 switch_to;
    compo_form_t *sub_frm;
    void *sub_cb;
    compo_shape_t *masklayer;
} f_clock_t;

//主窗体
void func_clock_sub_process(void);
void func_clock_sub_message(size_msg_t msg);

//子菜单
void func_clock_sub_dropdown(void);
void func_clock_sub_pullup(void);
void func_clock_sub_side(void);

//表盘转盘
void func_clock_sub_rotary(void);

#endif
