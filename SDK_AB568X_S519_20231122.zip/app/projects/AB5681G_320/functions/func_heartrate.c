#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_heartrate_t_ {

} f_heartrate_t;

//创建心率窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_heartrate_form_create(void)
{
    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_HEART_RATE]);

    //设置内容
    compo_form_add_image(frm, UI_BUF_HEART_RATE_HR_BIN, 160, 117);
    compo_form_add_image(frm, UI_BUF_HEART_RATE_HR_BG_BIN, 160, 226);

    compo_form_add_image(frm, UI_BUF_HEART_RATE_HR_BG_BIN, 160, 426);
    compo_form_add_image(frm, UI_BUF_HEART_RATE_HR_BIN, 160, 526);

    return frm;
}


//心率功能事件处理
static void func_heartrate_process(void)
{
    func_process();
}

//心率功能消息处理
static void func_heartrate_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入心率功能
static void func_heartrate_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_heartrate_t));
    func_cb.frm_main = func_heartrate_form_create();
}

//退出心率功能
static void func_heartrate_exit(void)
{
    func_cb.last = FUNC_HEARTRATE;
}

//心率功能
void func_heartrate(void)
{
    printf("%s\n", __func__);
    func_heartrate_enter();
    while (func_cb.sta == FUNC_HEARTRATE) {
        func_heartrate_process();
        func_heartrate_message(msg_dequeue());
    }
    func_heartrate_exit();
}
