#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_activity_t_ {

} f_activity_t;

//创建活动记录窗体
compo_form_t *func_activity_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);

	//设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_ACTIVITY_RECORD]);

    return frm;
}

//活动记录功能事件处理
static void func_activity_process(void)
{
    func_process();
}

//活动记录功能消息处理
static void func_activity_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入活动记录控制功能
static void func_activity_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_activity_t));
    func_cb.frm_main = func_activity_form_create();
}

//退出活动记录功能
static void func_activity_exit(void)
{
    func_cb.last = FUNC_ACTIVITY;
}

//活动记录功能
void func_activity(void)
{
    printf("%s\n", __func__);
    func_activity_enter();
    while (func_cb.sta == FUNC_ACTIVITY) {
        func_activity_process();
        func_activity_message(msg_dequeue());
    }
    func_activity_exit();
}
