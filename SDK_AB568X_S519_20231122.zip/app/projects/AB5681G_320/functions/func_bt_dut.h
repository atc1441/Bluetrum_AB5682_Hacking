#ifndef _FUNC_BT_DUT_H
#define _FUNC_BT_DUT_H

void func_bt_dut(void);
void func_bt_fcc(void);

#endif // _FUNC_BT_HID_H
