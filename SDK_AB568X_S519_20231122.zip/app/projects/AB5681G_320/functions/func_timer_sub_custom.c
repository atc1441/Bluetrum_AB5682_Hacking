#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

//组件ID
enum {
    //按键
	COMPO_ID_BTN_HOUR_INC = 1,  //时+
	COMPO_ID_BTN_MIN_INC,       //分+
	COMPO_ID_BTN_SEC_INC,       //秒+
	COMPO_ID_BTN_HOUR_RED,      //时-
	COMPO_ID_BTN_MIN_RED,       //分-
	COMPO_ID_BTN_SEC_RED,       //秒-
	COMPO_ID_BTN_OK,            //ok

    //数字
	COMPO_ID_NUM_CUSTOM_HOUR,
	COMPO_ID_NUM_CUSTOM_MIN,
	COMPO_ID_NUM_CUSTOM_SEC,
};

typedef struct f_timer_sub_custom_t_ {
    u8 hour;
    u8 min;
    u8 sec;
    u32 total_sec;
} f_timer_sub_custom_t;

typedef struct timer_custom_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
    bool visible_en;
} timer_custom_btn_item_t;

#define TIMER_CUSTOM_BTN_ITEM_CNT                       ((int)(sizeof(tbl_timer_custom_btn_item) / sizeof(tbl_timer_custom_btn_item[0])))

//搞个按键item，创建时遍历一下
static const timer_custom_btn_item_t tbl_timer_custom_btn_item[] = {
    {UI_BUF_COMMON_INCREASE_BIN,        COMPO_ID_BTN_HOUR_INC,      54,     100,    true},
    {UI_BUF_COMMON_INCREASE_BIN,        COMPO_ID_BTN_MIN_INC,       160,    100,    true},
    {UI_BUF_COMMON_INCREASE_BIN,        COMPO_ID_BTN_SEC_INC,       266,    100,    true},
    {UI_BUF_COMMON_REDUCE_BIN,          COMPO_ID_BTN_HOUR_RED,      54,     239,    true},
    {UI_BUF_COMMON_REDUCE_BIN,          COMPO_ID_BTN_MIN_RED,       160,    239,    true},
    {UI_BUF_COMMON_REDUCE_BIN,          COMPO_ID_BTN_SEC_RED,       266,    239,    true},
    {UI_BUF_COMMON_BUTTON_BIN,          COMPO_ID_BTN_OK,            160,    336,    true},
};

//创建定时器--自定义窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_timer_sub_custom_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_TIMER]);

	//创建按钮
    compo_button_t *btn;
    for (u8 idx = 0; idx < TIMER_CUSTOM_BTN_ITEM_CNT; idx++) {
        btn = compo_button_create_by_image(frm, tbl_timer_custom_btn_item[idx].res_addr);
        compo_setid(btn, tbl_timer_custom_btn_item[idx].btn_id);
        compo_button_set_pos(btn, tbl_timer_custom_btn_item[idx].x, tbl_timer_custom_btn_item[idx].y);
        compo_button_set_visible(btn, tbl_timer_custom_btn_item[idx].visible_en);
    }

    //创建数字
    compo_number_t *num;

    num = compo_number_create(frm, UI_BUF_COMMON_NUM_30_46_BIN, 2);
    compo_setid(num, COMPO_ID_NUM_CUSTOM_HOUR);
    compo_number_set(num, 0);
    compo_number_set_zfill(num, true);
    compo_number_set_pos(num, 52, 170);

    num = compo_number_create(frm, UI_BUF_COMMON_NUM_30_46_BIN, 2);
    compo_setid(num, COMPO_ID_NUM_CUSTOM_MIN);
    compo_number_set(num, 0);
    compo_number_set_zfill(num, true);
    compo_number_set_pos(num, 160, 170);

    num = compo_number_create(frm, UI_BUF_COMMON_NUM_30_46_BIN, 2);
    compo_setid(num, COMPO_ID_NUM_CUSTOM_SEC);
    compo_number_set(num, 0);
    compo_number_set_zfill(num, true);
    compo_number_set_pos(num, 268, 170);

    //创建文本
    compo_textbox_t *txt_ok = compo_textbox_create(frm, 3);
    compo_textbox_set_pos(txt_ok, 160, 336);
    compo_textbox_set(txt_ok, "OK");

    return frm;
}

//单击按钮
static void func_timer_sub_custom_button_click(void)
{
    int id = compo_get_button_id();
    f_timer_sub_custom_t *f_timer_sub_custom = (f_timer_sub_custom_t *)func_cb.f_cb;

    //获取数字组件的地址
    compo_number_t *num_hour = compo_getobj_byid(COMPO_ID_NUM_CUSTOM_HOUR);
    compo_number_t *num_min = compo_getobj_byid(COMPO_ID_NUM_CUSTOM_MIN);
    compo_number_t *num_sec = compo_getobj_byid(COMPO_ID_NUM_CUSTOM_SEC);

//    printf("%s-->id:%x\n",__func__,id);
//    printf("total_sec:%d, hour:%d, min:%d, sec:%d\n", f_timer_sub_custom->total_sec, f_timer_sub_custom->hour, f_timer_sub_custom->min, f_timer_sub_custom->sec);
    switch (id) {
    case COMPO_ID_BTN_HOUR_INC:
        if (f_timer_sub_custom->hour < 24) {
            f_timer_sub_custom->hour++;
        } else {
            f_timer_sub_custom->hour = 0;
        }
        break;

    case COMPO_ID_BTN_MIN_INC:
        if (f_timer_sub_custom->min < 60) {
            f_timer_sub_custom->min++;
        } else {
            f_timer_sub_custom->min = 0;
        }
        break;

    case COMPO_ID_BTN_SEC_INC:
        if (f_timer_sub_custom->sec < 60) {
            f_timer_sub_custom->sec++;
        } else {
            f_timer_sub_custom->sec = 0;
        }
        break;

    case COMPO_ID_BTN_HOUR_RED:
        if (f_timer_sub_custom->hour > 0) {
            f_timer_sub_custom->hour--;
        } else {
            f_timer_sub_custom->hour = 23;
        }
        break;

    case COMPO_ID_BTN_MIN_RED:
        if (f_timer_sub_custom->min > 0) {
            f_timer_sub_custom->min--;
        } else {
            f_timer_sub_custom->min = 59;
        }
        break;

    case COMPO_ID_BTN_SEC_RED:
        if (f_timer_sub_custom->sec > 0) {
            f_timer_sub_custom->sec--;
        } else {
            f_timer_sub_custom->sec = 59;
        }
        break;

    case COMPO_ID_BTN_OK:
        func_cb.sta = FUNC_TIMER_SUB_DISP;
        sys_cb.timer_total_sec = f_timer_sub_custom->hour * 3600 + f_timer_sub_custom->min * 60 + f_timer_sub_custom->sec;
        break;

    default:
        break;
    }

    f_timer_sub_custom->total_sec = f_timer_sub_custom->hour * 3600 + f_timer_sub_custom->min * 60 + f_timer_sub_custom->sec;
    f_timer_sub_custom->hour = f_timer_sub_custom->total_sec / 3600;
    f_timer_sub_custom->min = (f_timer_sub_custom->total_sec % 3600) / 60;
    f_timer_sub_custom->sec = f_timer_sub_custom->total_sec % 60;

    compo_number_set(num_hour, f_timer_sub_custom->hour);
    compo_number_set(num_min, f_timer_sub_custom->min);
    compo_number_set(num_sec, f_timer_sub_custom->sec);
}

//定时器--自定义功能事件处理
static void func_timer_sub_custom_process(void)
{
    func_process();
}

//定时器--自定义功能消息处理
static void func_timer_sub_custom_message(size_msg_t msg)
{
    compo_form_t *frm = NULL;
    bool res = false;

    switch (msg) {
    case MSG_CTP_CLICK:
        func_timer_sub_custom_button_click();
        break;

    case KU_BACK:
        func_cb.sta = FUNC_TIMER;
        break;

    case MSG_CTP_SHORT_RIGHT:
        frm = func_create_form(FUNC_TIMER);
        res = func_switching(FUNC_SWITCH_LR_ZOOM_RIGHT, NULL);
        compo_form_destroy(frm);             //切换完成或取消，销毁窗体
        if (res) {
            func_cb.sta = FUNC_TIMER;
        }
        break;

    case MSG_QDEC_FORWARD:
    case MSG_QDEC_BACKWARD:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入定时器--自定义功能
static void func_timer_sub_custom_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_timer_sub_custom_t));
    func_cb.frm_main = func_timer_sub_custom_form_create();
}

//退出定时器--自定义功能
static void func_timer_sub_custom_exit(void)
{
    func_cb.last = FUNC_TIMER_SUB_CUSTOM;
}

//定时器--自定义功能
void func_timer_sub_custom(void)
{
    printf("%s\n", __func__);
    func_timer_sub_custom_enter();
    while (func_cb.sta == FUNC_TIMER_SUB_CUSTOM) {
        func_timer_sub_custom_process();
        func_timer_sub_custom_message(msg_dequeue());
    }
    func_timer_sub_custom_exit();
}
