#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

//创建查找手机窗体
compo_form_t *func_findphone_form_create(void)
{
    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_FIND_PHONE]);

	//创建按键
    compo_button_t *btn = compo_button_create_by_image(frm, UI_BUF_ICON_FINDPHONE_BIN);
    compo_button_set_pos(btn, 160, 180);

    return frm;
}

//查找手机功能事件处理
static void func_findphone_process(void)
{
    func_process();
}

//查找手机功能消息处理
static void func_findphone_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入查找手机功能
static void func_findphone_enter(void)
{
    func_cb.frm_main = func_findphone_form_create();
}

//退出查找手机功能
static void func_findphone_exit(void)
{
    func_cb.last = FUNC_FINDPHONE;
}

//查找手机功能
void func_findphone(void)
{
    printf("%s\n", __func__);
    func_findphone_enter();
    while (func_cb.sta == FUNC_FINDPHONE) {
        func_findphone_process();
        func_findphone_message(msg_dequeue());
    }
    func_findphone_exit();
}
