#include "include.h"
#include "func.h"
#include "func_bt.h"

enum {
    COMPO_ID_BTN_PREV = 1,
    COMPO_ID_BTN_NEXT,
    COMPO_ID_BTN_PLAY,
    COMPO_ID_BTN_VOL_UP,
    COMPO_ID_BTN_VOL_DOWN,
};

typedef struct f_bt_t_ {

} f_bt_t;

//创建蓝牙音乐播放器窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_bt_form_create(void)
{
    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_MUSIC]);

    //新建按钮
    compo_button_t *btn;
    btn = compo_button_create_by_image(frm, UI_BUF_MUSIC_PREV_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_PREV);
    compo_button_set_pos(btn, 53, 248);

    btn = compo_button_create_by_image(frm, UI_BUF_MUSIC_PAUSE_BIN);
    compo_setid(btn, COMPO_ID_BTN_PLAY);
    compo_button_set_pos(btn, 160, 245);

    btn = compo_button_create_by_image(frm, UI_BUF_MUSIC_NEXT_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_NEXT);
    compo_button_set_pos(btn, 267, 248);

    btn = compo_button_create_by_image(frm, UI_BUF_MUSIC_VOLUME_DOWN_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_VOL_DOWN);
    compo_button_set_pos(btn, 62, 340);

    btn = compo_button_create_by_image(frm, UI_BUF_MUSIC_VOLUME_UP_CLICK_BIN);
    compo_setid(btn, COMPO_ID_BTN_VOL_UP);
    compo_button_set_pos(btn, 258, 340);

    return frm;
}

void func_bt_mp3_res_play(u32 addr, u32 len)
{
    if (len == 0) {
        return;
    }

    bt_audio_bypass();
    mp3_res_play(addr, len);
    bt_audio_enable();
}

void func_bt_init(void)
{
    if (!bt_cb.bt_is_inited) {
        msg_queue_clear();
        dis_auto_pwroff();
        bsp_bt_init();
        bt_redial_init();
        bt_cb.bt_is_inited = 1;
    }
}

void func_bt_chk_off(void)
{
    if ((func_cb.sta != FUNC_BT) && (bt_cb.bt_is_inited)) {
        bt_disconnect(1);
        bt_off();
        bt_cb.bt_is_inited = 0;
    }
}

//单击按钮
static void func_bt_button_click(void)
{
    int id = compo_get_button_id();
    switch (id) {
    case COMPO_ID_BTN_PREV:
        bt_music_prev();
        break;

    case COMPO_ID_BTN_NEXT:
        bt_music_next();
        break;

    case COMPO_ID_BTN_PLAY:
        bt_music_play_pause();
        break;

    case COMPO_ID_BTN_VOL_UP:
        bt_volume_up();
        break;

    case COMPO_ID_BTN_VOL_DOWN:
        bt_volume_down();
        break;

    default:
        break;
    }
}

void func_bt_sub_process(void)
{
    bsp_bt_status();
}

void func_bt_process(void)
{
    func_process();
    func_bt_sub_process();

    if(bt_cb.disp_status == BT_STA_INCOMING) {
#if BT_HFP_RING_NUMBER_EN
        sfunc_bt_ring();
#endif
        reset_sleep_delay_all();
        reset_pwroff_delay();
    } else if(bt_cb.disp_status == BT_STA_OTA) {
        sfunc_bt_ota();
        reset_sleep_delay_all();
        reset_pwroff_delay();
    } else if(bt_cb.disp_status >= BT_STA_OUTGOING) {
        sfunc_bt_call();
        reset_sleep_delay_all();
        reset_pwroff_delay();
    }

    if(sys_cb.pwroff_delay == 0) {
        func_cb.sta = FUNC_PWROFF;
        return;
    }
//    if(sleep_process(bt_is_sleep)) {
//        bt_cb.disp_status = 0xff;
//    }
}

//蓝牙音乐消息处理
static void func_bt_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        func_bt_button_click();                         //单击按钮
        break;

    default:
        func_message(msg);
        break;
    }
}

void func_bt_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_bt_t));
    func_cb.frm_main = func_bt_form_create();

    func_cb.mp3_res_play = func_bt_mp3_res_play;

#if !BT_BACKSTAGE_MUSIC_EN
    func_bt_init();
    bt_audio_enable();
#if DAC_DNR_EN
    dac_dnr_set_sta(1);
    sys_cb.dnr_sta = 1;
#endif
#endif // !BT_BACKSTAGE_MUSIC_EN
}

void func_bt_exit(void)
{
#if !BT_BACKSTAGE_MUSIC_EN
    dac_fade_out();
#if DAC_DNR_EN
    dac_dnr_set_sta(0);
    sys_cb.dnr_sta = 0;
#endif
    bt_audio_bypass();

#if !BT_BACKSTAGE_EN
    bt_disconnect(1);
    bt_off();
    bt_cb.bt_is_inited = 0;
#else
    if (bt_get_status() == BT_STA_PLAYING && !bt_is_testmode()) {        //蓝牙退出停掉音乐
        delay_5ms(10);
        if(bt_get_status() == BT_STA_PLAYING) {     //再次确认play状态
            u32 timeout = 850; //8.5s
            bt_music_pause();
            while (bt_get_status() == BT_STA_PLAYING && timeout > 0) {
                timeout--;
                delay_5ms(2);
            }
        }
    }
#endif  // !BT_BACKSTAGE_EN
#endif  // !BT_BACKSTAGE_MUSIC_EN

    bt_cb.rec_pause = 0;
    func_cb.last = FUNC_BT;
}

void func_bt(void)
{
    printf("%s\n", __func__);
    func_bt_enter();
    while (func_cb.sta == FUNC_BT) {
        func_bt_process();
        func_bt_message(msg_dequeue());
    }
    func_bt_exit();
}
