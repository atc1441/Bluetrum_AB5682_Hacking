#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define FUNC_SLEEP_MOVE_DOWN            -10                         //长图下滑的最大坐标
#define FUNC_SLEEP_MOVE_UP              -460                        //长图上滑的最大坐标
#define FUNC_SLEEP_MOVE_AUTO_DOWN       -(GUI_SCREEN_HEIGHT / 8)    //长图下滑回弹的坐标
#define FUNC_SLEEP_MOVE_AUTO_UP         -420                        //长图上滑回弹的坐标
#define FUNC_SLEEP_MOVE_STEP            30                          //滚动距离

typedef struct f_sleep_t_ {
    bool flag_drag;
    bool flag_move_auto;
    u8 dir;             //自动移动方向 0：无，1：向上，2：向下回弹
    s32 y_pos;          //记录最后一次松手的y坐标
    s32 y;              //当前滑动的y坐标
} f_sleep_t;

//创建睡眠窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_sleep_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);
	compo_form_add_image(frm, UI_BUF_SLEEP_SLEEP_BIN, 160, 175);
	compo_form_add_image(frm, UI_BUF_SLEEP_DEEP_ALEEP_BIN, 82, 277);
	compo_form_add_image(frm, UI_BUF_SLEEP_LIGHT_SLEEP_BIN, 241, 277);
	compo_form_add_image(frm, UI_BUF_SLEEP_CHART_BG_BIN, 160, 600);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_SLEEP]);

    return frm;
}

//睡眠功能滑动处理
static void func_sleep_move()
{
    bool flag_press = false;
    static s32 dx = 0, dy = 0;     //坐标差量
    static u32 tick;
    f_sleep_t *f_sleep = (f_sleep_t *)func_cb.f_cb;

    if (f_sleep->flag_drag) {
        flag_press = ctp_get_dxy(&dx, &dy);
        if (flag_press) {
            f_sleep->y = f_sleep->y_pos + dy;
            if (f_sleep->y >= FUNC_SLEEP_MOVE_DOWN) {
                f_sleep->y = FUNC_SLEEP_MOVE_DOWN;
                f_sleep->dir = 1;
            } else if (f_sleep->y <= FUNC_SLEEP_MOVE_UP) {
                f_sleep->y = FUNC_SLEEP_MOVE_UP;
                f_sleep->dir = 2;
            }
            widget_page_set_client(func_cb.frm_main->page_body, 0, f_sleep->y);
        } else {                    //松手自动回弹
            f_sleep->y_pos = f_sleep->y;
            tick = tick_get();
            f_sleep->flag_move_auto = true;
            f_sleep->flag_drag = false;
        }
    }

    if (f_sleep->flag_move_auto) {
        if (tick_check_expire(tick, 3)) {
            tick = tick_get();
            if (f_sleep->dir == 1) {
                if (--f_sleep->y_pos <= FUNC_SLEEP_MOVE_AUTO_DOWN) {
                    f_sleep->flag_move_auto = false;
                    f_sleep->dir = 0;
                }
            } else if (f_sleep->dir == 2) {
                if (++f_sleep->y_pos >= FUNC_SLEEP_MOVE_AUTO_UP) {
                    f_sleep->flag_move_auto = false;
                    f_sleep->dir = 0;
                }
            } else {
                f_sleep->flag_move_auto = false;
            }
            widget_page_set_client(func_cb.frm_main->page_body, 0, f_sleep->y_pos);

        }
    }


}

//睡眠功能事件处理
static void func_sleep_process(void)
{
    func_sleep_move();
    func_process();
}

//睡眠功能消息处理
static void func_sleep_message(size_msg_t msg)
{
    f_sleep_t *f_sleep = (f_sleep_t *)func_cb.f_cb;
    switch (msg) {
    case MSG_CTP_CLICK:
        break;

    case MSG_CTP_SHORT_UP:
    case MSG_CTP_SHORT_DOWN:
        f_sleep->flag_drag = true;
        break;

    case MSG_QDEC_FORWARD:
        f_sleep->flag_move_auto = true;
        if (f_sleep->y_pos <= FUNC_SLEEP_MOVE_UP) {
            f_sleep->dir = 2;
        } else {
            f_sleep->y_pos -= FUNC_SLEEP_MOVE_STEP;
        }
        break;

    case MSG_QDEC_BACKWARD:
        f_sleep->flag_move_auto = true;
        if (f_sleep->y_pos >= FUNC_SLEEP_MOVE_DOWN) {
            f_sleep->dir = 1;
        } else {
            f_sleep->y_pos += FUNC_SLEEP_MOVE_STEP;
        }
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入睡眠功能
static void func_sleep_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_sleep_t));
    func_cb.frm_main = func_sleep_form_create();

    f_sleep_t *f_sleep = (f_sleep_t *)func_cb.f_cb;
    if (func_cb.frm_main->mode) {       //带标题时page body有偏移
        f_sleep->y_pos = FUNC_SLEEP_MOVE_AUTO_DOWN;
    }
}

//退出睡眠功能
static void func_sleep_exit(void)
{
    func_cb.last = FUNC_SLEEP;
}

//睡眠功能
void func_sleep(void)
{
    printf("%s\n", __func__);
    func_sleep_enter();
    while (func_cb.sta == FUNC_SLEEP) {
        func_sleep_process();
        func_sleep_message(msg_dequeue());
    }
    func_sleep_exit();
}
