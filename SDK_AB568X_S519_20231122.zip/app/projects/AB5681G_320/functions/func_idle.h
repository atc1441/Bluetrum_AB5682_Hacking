#ifndef _FUNC_IDLE_H
#define _FUNC_IDLE_H

void func_idle_message(u16 msg);

#endif // _FUNC_IDLE_H
