#include "include.h"
#include "func.h"

#define TRACE_EN    1

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

#define SIDEBAR_PAGE_HEIGHT 1082//(956+78+48)  //长图总高度
#define SIDEBAR_DRAG_OFFS   80  //拖动页面超出边界允许值
#define SIDEBAR_Y_MIN       (-SIDEBAR_PAGE_HEIGHT + GUI_SCREEN_HEIGHT) //底部pos_y值
#define SIDEBAR_Y_MAX       0  //顶部pos_y值
#define SIDEBAR_DRAG_MIN    (SIDEBAR_Y_MIN - SIDEBAR_DRAG_OFFS)  //拖动超出底部时的pos_y值
#define SIDEBAR_DRAG_MAX    (SIDEBAR_Y_MAX + SIDEBAR_DRAG_OFFS)  //拖动超出顶部时的pos_y值
#define SIDEBAR_BTN_CNT     ((int)((sizeof(table_btn_jump) / sizeof(table_btn_jump[0]))))  //按钮数量

#define TEMPERATURE_GET()   29  //温度获取接口
#define LATEST_FUNC_GET(i)  FUNC_CLOCK  //历史任务序号获取接口（i=0为最近）
#define TIMER_HOUR          (sys_cb.timer_total_sec / 3600)
#define TIMER_MIN           ((sys_cb.timer_total_sec % 3600) / 60)
#define TIMER_SEC           ((sys_cb.timer_total_sec % 3600) % 60)
#define STOPWATCH_HOUR      (sys_cb.stopwatch_total_msec / 1000 / 3600)
#define STOPWATCH_MIN       (((sys_cb.stopwatch_total_msec / 1000) % 3600) / 60)
#define STOPWATCH_SEC       (((sys_cb.stopwatch_total_msec / 1000) % 3600) % 60)

enum{
    //按钮
    SIDEBAR_ID_BTN_WEATHER = 1,
    SIDEBAR_ID_BTN_TIMER,
    SIDEBAR_ID_BTN_STOPWATCH,
    SIDEBAR_ID_BTN_CALCULATOR,
    SIDEBAR_ID_BTN_CALENDAR,
    SIDEBAR_ID_BTN_GAME,
    SIDEBAR_ID_BTN_BREATHE,
    SIDEBAR_ID_BTN_LATEST0,
    SIDEBAR_ID_BTN_LATEST1,
    SIDEBAR_ID_BTN_LATEST2,
    //数字
    COMPO_ID_NUM_TIME_H,
    COMPO_ID_NUM_TIME_M,
    COMPO_ID_NUM_DATE_M,
    COMPO_ID_NUM_DATE_D,
    COMPO_ID_NUM_TEMPERATURE,
    COMPO_ID_NUM_TIMER_H,
    COMPO_ID_NUM_TIMER_M,
    COMPO_ID_NUM_TIMER_S,
    COMPO_ID_NUM_STOPWATCH_H,
    COMPO_ID_NUM_STOPWATCH_M,
    COMPO_ID_NUM_STOPWATCH_S,
    //文本
    COMPO_ID_TXT_WEEKDAY,
    //图像
    COMPO_ID_PIC_WEATHER,
};

typedef struct f_sidebar_t_ {
    s32 pos_y;
    s32 pos_y_cur;
    bool flag_drag;                 //开始拖动
//    bool flag_move_auto;            //自动移到坐标
//    s32 moveto_y;                   //设定自动移到的坐标
//    u32 tick;
} f_sidebar_t;

typedef struct sidebar_btn_jump_t_ {
    u8 id;
    u8 func_sta;
    s16 x;
    s16 y;
    s16 wid;
    s16 hei;
} sidebar_btn_jump_t;

const sidebar_btn_jump_t table_btn_jump[] = {
    {SIDEBAR_ID_BTN_WEATHER,    FUNC_WEATHER,       245, 126, 130, 150},
    {SIDEBAR_ID_BTN_TIMER,      FUNC_TIMER,         160, 296, 308, 156},
    {SIDEBAR_ID_BTN_STOPWATCH,  FUNC_STOPWATCH,     160, 466, 308, 156},
    {SIDEBAR_ID_BTN_CALCULATOR, FUNC_CALCULATOR,    81,  631, 146, 146},
    {SIDEBAR_ID_BTN_CALENDAR,   FUNC_CALENDAER,     241, 631, 146, 146},
    {SIDEBAR_ID_BTN_GAME,       FUNC_GAME,          81,  791, 146, 146},
    {SIDEBAR_ID_BTN_BREATHE,    FUNC_BREATHE,       241, 791, 146, 146},
    {SIDEBAR_ID_BTN_LATEST0,    0,                  60,  979, 72,  72},
    {SIDEBAR_ID_BTN_LATEST1,    1,                  160, 979, 72,  72},
    {SIDEBAR_ID_BTN_LATEST2,    2,                  260, 979, 72,  72},
};

//根据当前天气获取图标资源地址
static u32 func_clock_sub_sidebar_get_weather_icon(void)
{
    return UI_BUF_WEATHER_CLOUDY_BIN;
}

//根据最近应用序号获取图标资源地址
static u32 func_clock_sub_sidebar_get_latest_icon(u8 idx)
{
    u32 addr = 0;
    switch (idx) {
    case 0:
        addr = UI_BUF_ICON_SLEEP_BIN;
        break;
    case 1:
        addr = UI_BUF_ICON_SPORT_BIN;
        break;
    case 2:
        addr = UI_BUF_ICON_HEART_RATE_BIN;
        break;
    }
    return addr;
}

//创建右滑菜单
compo_form_t * func_clock_sub_sidebar_form_create(void)
{
    compo_picturebox_t *pic;
    compo_button_t *btn;
    compo_number_t *num;
    compo_textbox_t *txt;

    widget_image_t *img;
    widget_text_t *text;

    compo_form_t *frm = compo_form_create(true);

    //创建背景图
//    pic = compo_picturebox_create(frm, UI_BUF_SIDEBAR_BG_308_156_BIN);  //时间天气
//    compo_picturebox_set_pos(pic, 160, 126);
//    pic = compo_picturebox_create(frm, UI_BUF_SIDEBAR_BG_308_156_BIN);  //最近应用
//    compo_picturebox_set_pos(pic, 160, 956);
//    pic = compo_picturebox_create(frm, UI_BUF_SIDEBAR_TOP_308_50_BIN);
//    compo_picturebox_set_pos(pic, 160, 903);

    img = widget_image_create(frm->page_body, UI_BUF_COMMON_COLON_NUM_30_46_BIN);  //时间
    widget_set_pos(img,  95, 93);
    img = widget_image_create(frm->page_body, UI_BUF_SIDEBAR_BG_308_156_BIN);  //时间天气
    widget_set_pos(img, 160, 126);
    img = widget_image_create(frm->page_body, UI_BUF_SIDEBAR_BG_308_156_BIN);  //最近应用
    widget_set_pos(img, 160, 956);
    img = widget_image_create(frm->page_body, UI_BUF_SIDEBAR_TOP_308_50_BIN);
    widget_set_pos(img, 160, 903);
    //创建按钮
    btn = compo_button_create(frm);  //天气
    compo_button_set_location(btn, 245, 126, 130, 150);
    compo_setid(btn, SIDEBAR_ID_BTN_WEATHER);
    btn = compo_button_create_by_image(frm, UI_BUF_SIDEBAR_BG_308_156_BIN);  //计时器
    compo_button_set_pos(btn, 160, 296);
    compo_setid(btn, SIDEBAR_ID_BTN_TIMER);
    btn = compo_button_create_by_image(frm, UI_BUF_SIDEBAR_BG_308_156_BIN);  //秒表
    compo_button_set_pos(btn, 160, 466);
    compo_setid(btn, SIDEBAR_ID_BTN_STOPWATCH);
    btn = compo_button_create_by_image(frm, UI_BUF_SIDEBAR_BG_146_146_BIN);  //计算器
    compo_button_set_pos(btn, 81, 631);
    compo_setid(btn, SIDEBAR_ID_BTN_CALCULATOR);
    btn = compo_button_create_by_image(frm, UI_BUF_SIDEBAR_BG_146_146_BIN);  //日历
    compo_button_set_pos(btn, 241, 631);
    compo_setid(btn, SIDEBAR_ID_BTN_CALENDAR);
    btn = compo_button_create_by_image(frm, UI_BUF_SIDEBAR_BG_146_146_BIN);  //游戏
    compo_button_set_pos(btn, 81, 791);
    compo_setid(btn, SIDEBAR_ID_BTN_GAME);
    btn = compo_button_create_by_image(frm, UI_BUF_SIDEBAR_BG_146_146_BIN);  //呼吸
    compo_button_set_pos(btn, 241, 791);
    compo_setid(btn, SIDEBAR_ID_BTN_BREATHE);
    btn = compo_button_create(frm);  //最近应用
    compo_button_set_location(btn, 60, 979, 72, 72);
    compo_setid(btn, SIDEBAR_ID_BTN_LATEST0);
    btn = compo_button_create(frm);
    compo_button_set_location(btn, 160, 979, 72, 72);
    compo_setid(btn, SIDEBAR_ID_BTN_LATEST1);
    btn = compo_button_create(frm);
    compo_button_set_location(btn, 260, 979, 72, 72);
    compo_setid(btn, SIDEBAR_ID_BTN_LATEST2);
    //创建图片
//    pic = compo_picturebox_create(frm, UI_BUF_COMMON_COLON_NUM_30_46_BIN);  //时间
//    compo_picturebox_set_pos(pic, 95, 93);
//    pic = compo_picturebox_create(frm, UI_BUF_SIDEBAR_SLAS_BIN);  //日期
//    compo_picturebox_set_pos(pic, 94, 149);
    pic = compo_picturebox_create(frm, func_clock_sub_sidebar_get_weather_icon());  //天气
    compo_picturebox_set_pos(pic, 245, 111);
    compo_picturebox_set_size(pic, 108, 99);
//    pic = compo_picturebox_create(frm, UI_BUF_SIDEBAR_DEGREE_BIN);  //温度
//    compo_picturebox_set_pos(pic, 263, 171);
//    pic = compo_picturebox_create(frm, UI_BUF_ICON_TIMER_BIN);  //计时器
//    compo_picturebox_set_pos(pic, 54, 270);
//    compo_picturebox_set_size(pic, 64, 64);
//    pic = compo_picturebox_create(frm, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
//    compo_picturebox_set_pos(pic, 160, 334);
//    pic = compo_picturebox_create(frm, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
//    compo_picturebox_set_pos(pic, 222, 334);
//    pic = compo_picturebox_create(frm, UI_BUF_ICON_STOPWATCH_BIN);  //秒表
//    compo_picturebox_set_pos(pic, 54, 430);
//    compo_picturebox_set_size(pic, 64, 64);
//    pic = compo_picturebox_create(frm, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
//    compo_picturebox_set_pos(pic, 160, 504);
//    pic = compo_picturebox_create(frm, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
//    compo_picturebox_set_pos(pic, 222, 504);
//    pic = compo_picturebox_create(frm, UI_BUF_ICON_CALCULATOR_BIN);  //计算器
//    compo_picturebox_set_pos(pic, 60, 612);
//    compo_picturebox_set_size(pic, 72, 72);
//    pic = compo_picturebox_create(frm, UI_BUF_ICON_CALENDAR_BIN);  //日历
//    compo_picturebox_set_pos(pic, 220, 612);
//    compo_picturebox_set_size(pic, 72, 72);
//    pic = compo_picturebox_create(frm, UI_BUF_ICON_GAME_BIN);  //游戏
//    compo_picturebox_set_pos(pic, 60, 772);
//    compo_picturebox_set_size(pic, 72, 72);
//    pic = compo_picturebox_create(frm, UI_BUF_ICON_BREATHE_BIN);  //呼吸
//    compo_picturebox_set_pos(pic, 220, 772);
//    compo_picturebox_set_size(pic, 72, 72);
//    pic = compo_picturebox_create(frm, func_clock_sub_sidebar_get_latest_icon(0));  //最近应用
//    compo_picturebox_set_pos(pic, 60, 979);
//    compo_picturebox_set_size(pic, 72, 72);
//    pic = compo_picturebox_create(frm, func_clock_sub_sidebar_get_latest_icon(1));
//    compo_picturebox_set_pos(pic, 160, 979);
//    compo_picturebox_set_size(pic, 72, 72);
//    pic = compo_picturebox_create(frm, func_clock_sub_sidebar_get_latest_icon(2));
//    compo_picturebox_set_pos(pic, 260, 979);
//    compo_picturebox_set_size(pic, 72, 72);

    img = widget_image_create(frm->page_body, UI_BUF_COMMON_COLON_NUM_30_46_BIN);  //时间
    widget_set_pos(img, 95, 93);
    img = widget_image_create(frm->page_body, UI_BUF_SIDEBAR_SLAS_BIN);  //日期
    widget_set_pos(img, 94, 145);
//    img = widget_image_create(frm->page_body, func_clock_sub_sidebar_get_weather_icon());  //天气
//    widget_set_pos(img, 245, 111);
    img = widget_image_create(frm->page_body, UI_BUF_SIDEBAR_DEGREE_BIN);  //温度
    widget_set_pos(img, 263, 171);
    img = widget_image_create(frm->page_body, UI_BUF_ICON_TIMER_BIN);  //计时器
    widget_set_pos(img, 54, 270);
    widget_set_size(img, 64, 64);
    img = widget_image_create(frm->page_body, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
    widget_set_pos(img, 160, 334);
    img = widget_image_create(frm->page_body, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
    widget_set_pos(img, 222, 334);
    img = widget_image_create(frm->page_body, UI_BUF_ICON_STOPWATCH_BIN);  //秒表
    widget_set_pos(img, 54, 440);
    widget_set_size(img, 64, 64);
    img = widget_image_create(frm->page_body, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
    widget_set_pos(img, 160, 504);
    img = widget_image_create(frm->page_body, UI_BUF_COMMON_COLON_NUM_16_24_BIN);
    widget_set_pos(img, 222, 504);
    img = widget_image_create(frm->page_body, UI_BUF_ICON_CALCULATOR_BIN);  //计算器
    widget_set_pos(img, 60, 612);
    widget_set_size(img, 72, 72);
    img = widget_image_create(frm->page_body, UI_BUF_ICON_CALENDAR_BIN);  //日历
    widget_set_pos(img, 220, 612);
    widget_set_size(img, 72, 72);
    img = widget_image_create(frm->page_body, UI_BUF_ICON_GAME_BIN);  //游戏
    widget_set_pos(img, 60, 772);
    widget_set_size(img, 72, 72);
    img = widget_image_create(frm->page_body, UI_BUF_ICON_BREATHE_BIN);  //呼吸
    widget_set_pos(img, 220, 772);
    widget_set_size(img, 72, 72);
    img = widget_image_create(frm->page_body, func_clock_sub_sidebar_get_latest_icon(0));  //最近应用
    widget_set_pos(img, 60, 979);
    widget_set_size(img, 72, 72);
    img = widget_image_create(frm->page_body, func_clock_sub_sidebar_get_latest_icon(1));
    widget_set_pos(img, 160, 979);
    widget_set_size(img, 72, 72);
    img = widget_image_create(frm->page_body, func_clock_sub_sidebar_get_latest_icon(2));
    widget_set_pos(img, 260, 979);
    widget_set_size(img, 72, 72);
    //创建数字
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_30_46_BIN, 2);  //时间hour
    compo_setid(num, COMPO_ID_NUM_TIME_H);
    compo_number_set_pos(num, 52, 93);
    compo_number_set_zfill(num, true);
    compo_number_set(num, compo_cb.tm.hour);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_30_46_BIN, 2);  //时间min
    compo_setid(num, COMPO_ID_NUM_TIME_M);
    compo_number_set_pos(num, 138, 93);
    compo_number_set_zfill(num, true);
    compo_number_set(num, compo_cb.tm.min);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_16_24_BIN, 2);  //月
    compo_number_set_pos(num, 67, 145);
    compo_number_set_zfill(num, true);
    compo_number_set(num, compo_cb.tm.mon);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_16_24_BIN, 2);  //日
    compo_number_set_pos(num, 120, 145);
    compo_number_set_zfill(num, true);
    compo_number_set(num, compo_cb.tm.mon);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_16_24_BIN, 2);  //温度
    compo_number_set_pos(num, 228, 171);
    compo_number_set_zfill(num, true);
    compo_number_set(num, TEMPERATURE_GET());
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, 2);  //计时器hour
    compo_number_set_pos(num, 129, 334);
    compo_number_set_zfill(num, true);
    compo_number_set(num, TIMER_HOUR);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, 2);  //计时器min
    compo_number_set_pos(num, 191, 334);
    compo_number_set_zfill(num, true);
    compo_number_set(num, TIMER_MIN);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, 2);  //计时器sec
    compo_number_set_pos(num, 253, 334);
    compo_number_set_zfill(num, true);
    compo_number_set(num, TIMER_SEC);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, 2);  //秒表hour
    compo_number_set_pos(num, 129, 504);
    compo_number_set_zfill(num, true);
    compo_number_set(num, STOPWATCH_HOUR);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, 2);  //秒表min
    compo_number_set_pos(num, 191, 504);
    compo_number_set_zfill(num, true);
    compo_number_set(num, STOPWATCH_MIN);
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, 2);  //秒表sec
    compo_number_set_pos(num, 253, 504);
    compo_number_set_zfill(num, true);
    compo_number_set(num, STOPWATCH_SEC);
    //创建文本
    txt = compo_textbox_create(frm, 8);  //星期
    compo_textbox_set_pos(txt, 92, 181);
    compo_textbox_set(txt, i18n[STR_SUNDAY + compo_cb.tm.weekday]);
//    txt = compo_textbox_create(frm, 8);  //计时器
//    compo_textbox_set_pos(txt, 140, 270);
//    compo_textbox_set(txt, i18n[STR_TIMER]);
//    txt = compo_textbox_create(frm, 8);  //秒表
//    compo_textbox_set_pos(txt, 129, 430);
//    compo_textbox_set(txt, i18n[STR_STOP_WATCH]);
//    txt = compo_textbox_create(frm, 8);  //计算器
//    compo_textbox_set_pos(txt, 100, 670);
//    compo_textbox_set(txt, i18n[STR_CALCULATOR]);
//    txt = compo_textbox_create(frm, 8);  //日历
//    compo_textbox_set_pos(txt, 275, 670);
//    compo_textbox_set(txt, i18n[STR_CALENDAR]);
//    txt = compo_textbox_create(frm, 8);  //游戏
//    compo_textbox_set_pos(txt, 115, 830);
//    compo_textbox_set(txt, i18n[STR_GAME]);
//    txt = compo_textbox_create(frm, 8);  //呼吸
//    compo_textbox_set_pos(txt, 275, 830);
//    compo_textbox_set(txt, i18n[STR_BREATHE]);
//    txt = compo_textbox_create(frm, 8);  //最近应用
//    compo_textbox_set_pos(txt, 160, 903);
//    compo_textbox_set(txt, i18n[STR_LATEST_APP]);

//    text = widget_text_create(frm->page_body, 8);  //星期
//    widget_set_pos(text, 96, 181);
//    widget_text_set(text, i18n[STR_SUNDAY + compo_cb.tm.weekday]);
//    widget_text_set_autosize(text, true);
    text = widget_text_create(frm->page_body, 8);  //计时器
    widget_set_pos(text, 140, 270);
    widget_text_set_autosize(text, true);
    widget_text_set(text, i18n[STR_TIMER]);
    text = widget_text_create(frm->page_body, 8);  //秒表
    widget_set_pos(text, 129, 440);
    widget_text_set(text, i18n[STR_STOP_WATCH]);
    widget_text_set_autosize(text, true);
    text = widget_text_create(frm->page_body, 8);  //计算器
    widget_set_pos(text, 100, 675);
    widget_text_set(text, i18n[STR_CALCULATOR]);
    widget_text_set_autosize(text, true);
    text = widget_text_create(frm->page_body, 8);  //日历
    widget_set_pos(text, 275, 675);
    widget_text_set(text, i18n[STR_CALENDAR]);
    widget_text_set_autosize(text, true);
    text = widget_text_create(frm->page_body, 8);  //游戏
    widget_set_pos(text, 115, 835);
    widget_text_set(text, i18n[STR_GAME]);
    widget_text_set_autosize(text, true);
    text = widget_text_create(frm->page_body, 8);  //呼吸
    widget_set_pos(text, 275, 835);
    widget_text_set(text, i18n[STR_BREATHE]);
    widget_text_set_autosize(text, true);
    text = widget_text_create(frm->page_body, 8);  //最近应用
    widget_set_pos(text, 160, 903);
    widget_text_set(text, i18n[STR_LATEST_APP]);
    widget_text_set_autosize(text, true);

    return frm;
}

//时钟表盘右滑菜单点击处理
static void func_clock_sub_sidebar_click_handler(void)
{
    f_sidebar_t *f_sidebar = (f_sidebar_t *)func_cb.f_cb;

    int i = 0;
    u8 func_sta  = 0;
    sidebar_btn_jump_t btn_cur;
    point_t pt = ctp_get_sxy();
    for(; i<SIDEBAR_BTN_CNT; i++) {
        btn_cur = table_btn_jump[i];
//        TRACE("click %d.[%d %d][%d %d %d %d][%d %d]\n", i, btn_cur.id, btn_cur.func_sta, btn_cur.x, btn_cur.y + f_sidebar->pos_y, btn_cur.wid, btn_cur.hei, pt.x, pt.y);
        if (abs_s(pt.x - btn_cur.x) * 2 <= btn_cur.wid && abs_s(pt.y - (btn_cur.y + f_sidebar->pos_y)) * 2 <= btn_cur.hei) {
            TRACE("CLICK_ID:%d\n", btn_cur.id);
            if (btn_cur.id < SIDEBAR_ID_BTN_LATEST0) {
                func_sta = btn_cur.func_sta;
            } else {
                func_sta = LATEST_FUNC_GET(btn_cur.func_sta);
            }
//            compo_form_t *frm = func_create_form(func_sta);
//            func_switching(FUNC_SWITCH_FADE_OUT | FUNC_SWITCH_AUTO, NULL);
//            compo_form_destroy(frm);
            func_cb.sta = func_sta;
            break;
        }
    }
}

//时钟表盘右滑菜单主要事件流程处理
static void func_clock_sub_sidebar_process(void)
{
    f_sidebar_t *f_sidebar = (f_sidebar_t *)func_cb.f_cb;

	if (f_sidebar->flag_drag) {
        s32 dx, dy;
        f_sidebar->flag_drag = ctp_get_dxy(&dx, &dy);
        if (f_sidebar->flag_drag) {
            //拖动页面
            f_sidebar->pos_y_cur = f_sidebar->pos_y + dy;
            f_sidebar->pos_y_cur = MIN(SIDEBAR_DRAG_MAX, MAX(SIDEBAR_DRAG_MIN, f_sidebar->pos_y_cur));
            widget_page_set_client(func_cb.frm_main->page, 0, f_sidebar->pos_y_cur);
        } else {
            //抬手
            f_sidebar->pos_y = f_sidebar->pos_y_cur;
            f_sidebar->pos_y = MIN(SIDEBAR_Y_MAX, MAX(SIDEBAR_Y_MIN, f_sidebar->pos_y));
            widget_page_set_client(func_cb.frm_main->page, 0, f_sidebar->pos_y);
            printf("pos_y:%d\n", f_sidebar->pos_y);
        }
    }

    func_process();
}

//时钟表盘右滑菜单功能消息处理
static void func_clock_sub_sidebar_message(size_msg_t msg)
{
    f_sidebar_t *f_sidebar = (f_sidebar_t *)func_cb.f_cb;
    compo_number_t *num;

    if (f_sidebar->flag_drag){
        evt_message(msg);
        return;
    }


    switch (msg) {
        case MSG_CTP_CLICK:
            func_clock_sub_sidebar_click_handler();
            break;

        case MSG_CTP_SHORT_UP:
        case MSG_CTP_SHORT_DOWN:
            f_sidebar->flag_drag = true;
            break;

        case MSG_CTP_SHORT_LEFT:
//            func_switching();                   //左滑缓慢回到表盘
            func_cb.sta = FUNC_CLOCK;
            break;

        case MSG_CTP_SHORT_RIGHT:
        case MSG_CTP_LONG:
            break;

        case MSG_QDEC_FORWARD:
            f_sidebar->pos_y -= 15;
            f_sidebar->pos_y = MIN(SIDEBAR_Y_MAX, MAX(SIDEBAR_Y_MIN, f_sidebar->pos_y));
            widget_page_set_client(func_cb.frm_main->page, 0, f_sidebar->pos_y);
            printf("pos_y:%d\n", f_sidebar->pos_y);
            break;

        case MSG_QDEC_BACKWARD:
            f_sidebar->pos_y += 15;
            f_sidebar->pos_y = MIN(SIDEBAR_Y_MAX, MAX(SIDEBAR_Y_MIN, f_sidebar->pos_y));
            widget_page_set_client(func_cb.frm_main->page, 0, f_sidebar->pos_y);
            printf("pos_y:%d\n", f_sidebar->pos_y);
            break;

        case KU_BACK:
            func_cb.sta = FUNC_CLOCK;
            break;

        case MSG_SYS_1S:
            if (compo_cb.tm.sec == 0) {
                num = compo_getobj_byid(COMPO_ID_NUM_TIME_M);
                compo_number_set(num, compo_cb.tm.min);  //时间min
                if (compo_cb.tm.min == 0) {
                    num = compo_getobj_byid(COMPO_ID_NUM_TIME_H);
                    compo_number_set(num, compo_cb.tm.hour);  //时间hour
                }
            }
            break;

        default:
            evt_message(msg);
            break;
    }
}

//时钟表盘右滑菜单进入处理
static void func_clock_sub_sidebar_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_sidebar_t));
    func_cb.frm_main = func_clock_sub_sidebar_form_create();

    f_sidebar_t *f_sidebar = (f_sidebar_t *)func_cb.f_cb;
    f_sidebar->pos_y = 0;
    widget_set_align_center(func_cb.frm_main->page, false);
    widget_set_align_center(func_cb.frm_main->page_body, false);
    widget_set_location(func_cb.frm_main->page, 0, 0, GUI_SCREEN_WIDTH, SIDEBAR_PAGE_HEIGHT);
    widget_set_location(func_cb.frm_main->page_body, 0, 0, GUI_SCREEN_WIDTH, SIDEBAR_PAGE_HEIGHT);
    widget_page_set_client(func_cb.frm_main->page, 0, f_sidebar->pos_y);
}

//时钟表盘右滑菜单退出处理
static void func_clock_sub_sidebar_exit(void)
{
//    func_cb.last = FUNC_SIDEBAR;
    func_cb.last = FUNC_CLOCK;
}

//时钟表盘右滑菜单
void func_clock_sub_sidebar(void)
{
    func_clock_sub_sidebar_enter();
    while (func_cb.sta == FUNC_SIDEBAR) {
        func_clock_sub_sidebar_process();
        func_clock_sub_sidebar_message(msg_dequeue());
    }
    func_clock_sub_sidebar_exit();
}
