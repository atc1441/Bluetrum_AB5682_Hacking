#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_sav_t_ {
    u8 vol_value;
    u8 shk_value;
} f_sav_t;

enum {
    //数字
    COMPO_ID_NUM_DISP_ONE = 1,
    COMPO_ID_NUM_DISP_TWS,

    //按键
    COMPO_ID_BIN_REDUCE,
    COMPO_ID_BIN_INCREASE,
	COMPO_ID_BIN_VOICE_OFF,
	COMPO_ID_BTN_SHAKE_OFF,

    //图片
    COMPO_ID_PIC_VOL_ON,
    COMPO_ID_PIC_SHK_ON,
    COMPO_ID_PIC_VOL_OFF,
    COMPO_ID_PIC_SHK_OFF,
};

#define SAV_DISP_BTN_ITEM_CNT    ((int)(sizeof(tbl_sav_disp_btn_item) / sizeof(tbl_sav_disp_btn_item[0])))

typedef struct sav_disp_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
    s16 h;
    s16 l;
} sav_disp_btn_item_t;

//按钮item，创建时遍历一下
static const sav_disp_btn_item_t tbl_sav_disp_btn_item[] = {
    {0,                                 COMPO_ID_BIN_VOICE_OFF,         264,     110,   80,  40},
    {0,                                 COMPO_ID_BTN_SHAKE_OFF,         264,     212,   80,  40},
    {UI_BUF_COMMON_REDUCE_CLICK_BIN,    COMPO_ID_BIN_REDUCE,            54,      309,   80,  40},
    {UI_BUF_COMMON_INCREASE_CLICK_BIN,  COMPO_ID_BIN_INCREASE,          266,     309,   80,  40},
};

typedef struct sav_disp_pic_item_t_ {
    u32 res_addr;
    u16 pic_id;
    s16 x;
    s16 y;
    bool visible_en;
} sav_disp_pic_item_t;

#define SAV_DISP_PIC_ITEM_CNT                       ((int)(sizeof(tbl_sav_disp_pic_item) / sizeof(tbl_sav_disp_pic_item[0])))

//图片item，创建时遍历一下
static const sav_disp_pic_item_t tbl_sav_disp_pic_item[] = {
    {UI_BUF_COMMON_ON_BIN,           COMPO_ID_PIC_VOL_ON,         264,    110,    false},
    {UI_BUF_COMMON_ON_BIN,           COMPO_ID_PIC_SHK_ON,         264,    212,    false},
    {UI_BUF_COMMON_OFF_BIN,          COMPO_ID_PIC_VOL_OFF,        264,    110,    true},
    {UI_BUF_COMMON_OFF_BIN,          COMPO_ID_PIC_SHK_OFF,        264,    212,    true},
};

//声音与振动页面
compo_form_t *func_set_sub_sav_form_create(void)
{
    //新建窗体
    compo_form_t *frm = compo_form_create(true);

    //设置标题栏
    compo_form_set_mode(frm, COMPO_FORM_MODE_SHOW_TITLE | COMPO_FORM_MODE_SHOW_TIME);
    compo_form_set_title(frm, i18n[STR_SETTING_SAV]);

    //创建文本
    compo_textbox_t *txt_voice = compo_textbox_create(frm, 2);
    compo_textbox_set_align_center(txt_voice, false);
    compo_textbox_set_pos(txt_voice, 30, 100);
    compo_textbox_set(txt_voice, i18n[STR_VOL]);

    compo_textbox_t *txt_shake = compo_textbox_create(frm, 2);
    compo_textbox_set_align_center(txt_shake, false);
    compo_textbox_set_pos(txt_shake, 30, 194);
    compo_textbox_set(txt_shake, i18n[STR_SHK]);


    //新建图像
    compo_picturebox_t *pic_click;
    for (u8 idx = 0; idx < SAV_DISP_PIC_ITEM_CNT; idx++) {
        pic_click = compo_picturebox_create(frm, tbl_sav_disp_pic_item[idx].res_addr);
        compo_setid(pic_click, tbl_sav_disp_pic_item[idx].pic_id);
        compo_picturebox_set_pos(pic_click, tbl_sav_disp_pic_item[idx].x, tbl_sav_disp_pic_item[idx].y);
        compo_picturebox_set_visible(pic_click, tbl_sav_disp_pic_item[idx].visible_en);
    }

    //创建按钮
    compo_button_t *btn;
    for (u8 idx_btn = 0; idx_btn < SAV_DISP_BTN_ITEM_CNT-2; idx_btn++) {
        btn = compo_button_create(frm);
        compo_setid(btn, tbl_sav_disp_btn_item[idx_btn].btn_id);
        compo_button_set_location(btn, tbl_sav_disp_btn_item[idx_btn].x, tbl_sav_disp_btn_item[idx_btn].y, tbl_sav_disp_btn_item[idx_btn].h, tbl_sav_disp_btn_item[idx_btn].l);
    }

    for (u8 idx = 2; idx < SAV_DISP_BTN_ITEM_CNT; idx++) {
        btn = compo_button_create_by_image(frm, tbl_sav_disp_btn_item[idx].res_addr);
        compo_setid(btn, tbl_sav_disp_btn_item[idx].btn_id);
        compo_button_set_pos(btn, tbl_sav_disp_btn_item[idx].x, tbl_sav_disp_btn_item[idx].y);
    }

    return frm;
}

//声音与振动事件处理
static void func_set_sub_sav_process(void)
{
    func_process();
}

//更新显示界面
static void func_set_sub_sav_disp(void)
{
    f_sav_t *sav = (f_sav_t *)func_cb.f_cb;

    //获取图片组件的地址
    compo_picturebox_t *pic_vol_on  = compo_getobj_byid(COMPO_ID_PIC_VOL_ON);
    compo_picturebox_t *pic_shk_on  = compo_getobj_byid(COMPO_ID_PIC_SHK_ON);
    compo_picturebox_t *pic_vol_off = compo_getobj_byid(COMPO_ID_PIC_VOL_OFF);
    compo_picturebox_t *pic_shk_off = compo_getobj_byid(COMPO_ID_PIC_SHK_OFF);

    if (sav->vol_value == COMPO_ID_NUM_DISP_TWS) {
        compo_picturebox_set_visible(pic_vol_on, true);
        compo_picturebox_set_visible(pic_vol_off, false);
    } else if (sav->vol_value == COMPO_ID_NUM_DISP_ONE){
        compo_picturebox_set_visible(pic_vol_on, false);
        compo_picturebox_set_visible(pic_vol_off, true);
    }

    if (sav->shk_value == COMPO_ID_NUM_DISP_TWS) {
        compo_picturebox_set_visible(pic_shk_on, true);
        compo_picturebox_set_visible(pic_shk_off, false);
    } else if (sav->shk_value == COMPO_ID_NUM_DISP_ONE) {
        compo_picturebox_set_visible(pic_shk_on, false);
        compo_picturebox_set_visible(pic_shk_off, true);
    }
}

//单击按钮
static void func_sav_button_click(void)
{
    u8 ret = 0;
    f_sav_t *sav = (f_sav_t *)func_cb.f_cb;
    int id = compo_get_button_id();

    switch(id) {
    case COMPO_ID_BIN_VOICE_OFF:
        ret = msgbox((char *)i18n[STR_VOL], NULL , COMPO_ID_NUM_DISP_ONE);

        if (ret == COMPO_ID_NUM_DISP_ONE) {
            if (sav->vol_value == COMPO_ID_NUM_DISP_ONE) {
                sav->vol_value = COMPO_ID_NUM_DISP_TWS;
            } else {
                sav->vol_value = COMPO_ID_NUM_DISP_ONE;
            }
        }
    break;

    case COMPO_ID_BTN_SHAKE_OFF:
        ret = msgbox((char *)i18n[STR_SHK], NULL , COMPO_ID_NUM_DISP_ONE);

        if (ret == COMPO_ID_NUM_DISP_ONE) {
            if(sav->shk_value == COMPO_ID_NUM_DISP_ONE) {
                sav->shk_value = COMPO_ID_NUM_DISP_TWS;
            } else {
                sav->shk_value = COMPO_ID_NUM_DISP_ONE;
            }
        }
    break;

    default:
    break;
    }
    func_set_sub_sav_disp();
}

//声音与振动功能消息处理
static void func_set_sub_sav_message(size_msg_t msg)
{
    compo_form_t *frm = NULL;
    bool res = false;
    switch (msg) {
    case MSG_CTP_SHORT_RIGHT:
        frm = func_create_form(FUNC_SETTING);
        res = func_switching(FUNC_SWITCH_LR_ZOOM_RIGHT,NULL);
        compo_form_destroy(frm);             //切换完成或取消，销毁窗体
        if (res) {
            func_cb.sta = FUNC_SETTING;
        }
        break;

    case MSG_CTP_CLICK:
        func_sav_button_click();
        break;

    default:
        break;
    }

}

//进入声音与振动功能
static void func_set_sub_sav_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_sav_t));
    func_cb.frm_main = func_set_sub_sav_form_create();

    f_sav_t *sav = (f_sav_t *)func_cb.f_cb;
    sav->shk_value = COMPO_ID_NUM_DISP_ONE;
    sav->vol_value = COMPO_ID_NUM_DISP_ONE;
}

//退出声音与振动功能
static void func_set_sub_sav_exit(void)
{
    func_cb.last = FUNC_SET_SUB_SAV;
}

//声音与振动功能
void func_set_sub_sav(void)
{
    printf("%s\n", __func__);
    func_set_sub_sav_enter();
    while (func_cb.sta == FUNC_SET_SUB_SAV) {
        func_set_sub_sav_process();
        func_set_sub_sav_message(msg_dequeue());
    }
    func_set_sub_sav_exit();
}
