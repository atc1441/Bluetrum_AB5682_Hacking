#ifndef _MSGBOX_H
#define _MSGBOX_H

enum {
    MSGBOX_MODE_BTN_OK,
    MSGBOX_MODE_BTN_OKCANCEL,
    MSGBOX_MODE_BTN_YESNO,
};

//msgbox返回值
enum {
    MSGBOX_RES_NONE,
    MSGBOX_RES_OK,          //确定
    MSGBOX_RES_CANCEL,      //取消
    MSGBOX_RES_ABORT,       //终止
    MSGBOX_RES_RETRY,       //重试
    MSGBOX_RES_INGNORE,     //忽略
    MSGBOX_RES_YES,         //是
    MSGBOX_RES_NO,          //否
};

int msgbox(char *msg, char *title, int mode);

#endif
