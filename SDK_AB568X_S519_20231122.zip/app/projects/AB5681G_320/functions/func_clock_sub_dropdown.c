#include "include.h"
#include "func.h"
#include "func_clock.h"

#define MENU_DROPDOWN_ALPHA             200

enum{
    //按键
    COMPO_ID_BTN_CON = 1,
    COMPO_ID_BTN_CONOFF,
    COMPO_ID_BTN_DISCURD,
    COMPO_ID_BTN_DISCURDOFF,
    COMPO_ID_BTN_FINDPHONE,
    COMPO_ID_BTN_FINDPHONEOFF,
    COMPO_ID_BTN_MUTE,
    COMPO_ID_BTN_MUTEOFF,
    COMPO_ID_BTN_FLASHLIGHT,
    COMPO_ID_BTN_FLASHLIGHTOFF,
    COMPO_ID_BTN_LIGHT,
    COMPO_ID_BTN_LIGHTOFF,
    COMPO_ID_BTN_SCAN,
    COMPO_ID_BTN_SCANOFF,
    COMPO_ID_BTN_POWER,
    COMPO_ID_BTN_POWEROFF,
};

#define DROPDOWN_DISP_BTN_ITEM_CNT    ((int)(sizeof(tbl_dropdown_disp_btn_item) / sizeof(tbl_dropdown_disp_btn_item[0])))

typedef struct dropdown_disp_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
    bool visible;
    bool sxl;
} dropdown_disp_btn_item_t;

//按钮item，创建时遍历一下
static  dropdown_disp_btn_item_t tbl_dropdown_disp_btn_item[] = {
    {UI_BUF_DROPDOWN_CONNECT_OFF_BIN,            COMPO_ID_BTN_CON,              84,  54,  true, false},
    {UI_BUF_DROPDOWN_CONNECT_ON_BIN,             COMPO_ID_BTN_CONOFF,           84,  54,  false, false},
    {UI_BUF_DROPDOWN_DISTURB_OFF_BIN,            COMPO_ID_BTN_DISCURD,          236, 54,  true, false},
    {UI_BUF_DROPDOWN_DISTURB_ON_BIN,             COMPO_ID_BTN_DISCURDOFF,       236, 54,  false, false},
    {UI_BUF_DROPDOWN_FIND_PHONE_OFF_BIN,         COMPO_ID_BTN_FINDPHONE,        84,  146, true, false},
    {UI_BUF_DROPDOWN_FIND_PHONE_ON_BIN,          COMPO_ID_BTN_FINDPHONEOFF,     84,  146, false, false},
    {UI_BUF_DROPDOWN_MUTE_ON_BIN,                COMPO_ID_BTN_MUTE,             236, 146, true, false},
    {UI_BUF_DROPDOWN_MUTE_OFF_BIN,               COMPO_ID_BTN_MUTEOFF,          236, 146, false, false},
    {UI_BUF_DROPDOWN_FLASHLIGHT_ON_BIN,          COMPO_ID_BTN_FLASHLIGHT,       84,  238, true, false},
    {UI_BUF_DROPDOWN_FLASHLIGHT_OFF_BIN,         COMPO_ID_BTN_FLASHLIGHTOFF,    84,  238, false, false},
    {UI_BUF_DROPDOWN_LIGHT_1_BIN,                COMPO_ID_BTN_LIGHT,            236, 238, true, false},
    {UI_BUF_DROPDOWN_LIGHT_2_BIN,                COMPO_ID_BTN_LIGHTOFF,         236, 238, false, false},
    {UI_BUF_DROPDOWN_SCAN_2_BIN,                 COMPO_ID_BTN_SCAN,             84,  330, true, false},
    {UI_BUF_DROPDOWN_SCAN_1_BIN,                 COMPO_ID_BTN_SCANOFF,          84,  330, false, false},
    {UI_BUF_DROPDOWN_POWER_BG_BIN,               COMPO_ID_BTN_POWER,            236, 330, true, false},

};

//创建下拉菜单
static void func_clock_sub_dropdown_form_create(void)
{
    compo_form_t *frm = compo_form_create(true);

    //创建遮罩层
    compo_shape_t *masklayer = compo_shape_create(frm, COMPO_SHAPE_TYPE_RECTANGLE);
    compo_shape_set_color(masklayer, COLOR_BLACK);
    compo_shape_set_location(masklayer, GUI_SCREEN_CENTER_X, GUI_SCREEN_CENTER_Y, GUI_SCREEN_WIDTH, GUI_SCREEN_HEIGHT);
    compo_shape_set_alpha(masklayer, 140);

    //创建按钮
    compo_button_t *btn;
    for (u8 idx_btn = 0; idx_btn < DROPDOWN_DISP_BTN_ITEM_CNT; idx_btn++) {
        btn = compo_button_create_by_image(frm, tbl_dropdown_disp_btn_item[idx_btn].res_addr);
        compo_setid(btn, tbl_dropdown_disp_btn_item[idx_btn].btn_id);
        compo_button_set_pos(btn, tbl_dropdown_disp_btn_item[idx_btn].x, tbl_dropdown_disp_btn_item[idx_btn].y);
        compo_button_set_alpha(btn, MENU_DROPDOWN_ALPHA);
        compo_button_set_visible(btn, tbl_dropdown_disp_btn_item[idx_btn].visible);
    }

    compo_form_add_image(frm, UI_BUF_DROPDOWN_POWER3_BIN, 233, 349);

    f_clock_t *f_clk = (f_clock_t *)func_cb.f_cb;
    f_clk->sub_frm = frm;
    f_clk->masklayer = masklayer;
}

//时钟表盘主要事件流程处理
static void func_clock_sub_dropdown_process(void)
{
    func_clock_sub_process();
}

static void func_clock_sub_dropdown_click_handler(void)
{
    int id = compo_get_button_id();

    //获取按键组件的地址
    compo_button_t *btn[16];
    for(int i=1;i<16;i++) {
        btn[i] = compo_getobj_byid(i);
    }
    switch(id) {
    case COMPO_ID_BTN_CON...COMPO_ID_BTN_SCANOFF:
        if(!tbl_dropdown_disp_btn_item[id].sxl) {
            compo_button_set_visible(btn[id], false);
            compo_button_set_visible(btn[id+1], true);
            tbl_dropdown_disp_btn_item[id].sxl = true;
        } else {
            compo_button_set_visible(btn[id], true);
            compo_button_set_visible(btn[id+1], false);
            tbl_dropdown_disp_btn_item[id].sxl = false;
        }
    break;

    case COMPO_ID_BTN_POWER:
        func_cb.sta = FUNC_CHARGE;
        break;

    default:
        break;
    }
}

//时钟表盘下拉菜单功能消息处理
static void func_clock_sub_dropdown_message(size_msg_t msg)
{
    f_clock_t *f_clk = (f_clock_t *)func_cb.f_cb;
    switch (msg) {
    case MSG_CTP_CLICK:
        func_clock_sub_dropdown_click_handler();
        break;

    case MSG_CTP_SHORT_UP:
        if (func_switching(FUNC_SWITCH_MENU_DROPDOWN_UP, NULL)) {
            f_clk->sta = FUNC_CLOCK_MAIN;                   //上滑返回到时钟主界面
        }
        break;

    case KU_BACK:
        func_switching(FUNC_SWITCH_MENU_DROPDOWN_UP | FUNC_SWITCH_AUTO, NULL);
        f_clk->sta = FUNC_CLOCK_MAIN;                       //单击BACK键返回到时钟主界面
        break;

    default:
        func_clock_sub_message(msg);
        break;
    }
}

//时钟表盘下拉菜单进入处理
static void func_clock_sub_dropdown_enter(void)
{
    func_clock_sub_dropdown_form_create();
    if (!func_switching(FUNC_SWITCH_MENU_DROPDOWN_DOWN, NULL)) {
        return;                                             //下拉到一半取消
    }
    f_clock_t *f_clk = (f_clock_t *)func_cb.f_cb;
    f_clk->sta = FUNC_CLOCK_SUB_DROPDOWN;                   //进入到下拉菜单
}

//时钟表盘下拉菜单退出处理
static void func_clock_sub_dropdown_exit(void)
{
    f_clock_t *f_clk = (f_clock_t *)func_cb.f_cb;
    compo_form_destroy(f_clk->sub_frm);
    f_clk->sub_frm = NULL;
}

//时钟表盘下拉菜单
void func_clock_sub_dropdown(void)
{
    func_clock_sub_dropdown_enter();
    while (func_cb.sta == FUNC_CLOCK && ((f_clock_t *)func_cb.f_cb)->sta == FUNC_CLOCK_SUB_DROPDOWN) {
        func_clock_sub_dropdown_process();
        func_clock_sub_dropdown_message(msg_dequeue());
    }
    func_clock_sub_dropdown_exit();
}
