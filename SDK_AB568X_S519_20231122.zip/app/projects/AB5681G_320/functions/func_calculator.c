#include "include.h"
#include "func.h"

#if TRACE_EN
#define TRACE(...)              printf(__VA_ARGS__)
#else
#define TRACE(...)
#endif

typedef struct f_calculator_t_ {
    u8 number_cnt[2];   //两个数字的位数
    u8 number_one[8];   //输入第一位数字
    u8 number_tws[8];   //输入第二位数字
    u32 cnt;            //总数
    u8 step[2];         //当前符号位状态
} f_calculator_t;

enum{
    //按键
    COMPO_ID_BTN_NUM0 = 1,
    COMPO_ID_BTN_NUM1,
    COMPO_ID_BTN_NUM2,
    COMPO_ID_BTN_NUM3,
    COMPO_ID_BTN_NUM4,
    COMPO_ID_BTN_NUM5,
    COMPO_ID_BTN_NUM6,
    COMPO_ID_BTN_NUM7,
    COMPO_ID_BTN_NUM8,
    COMPO_ID_BTN_NUM9,
    COMPO_ID_BTN_MINUS_CLICK,
    COMPO_ID_BTN_POINT_CLICK,
    COMPO_ID_BTN_CE_CLICK,
    COMPO_ID_BTN_C_CLICK,
    COMPO_ID_BTN_DEL_CLICK,
    COMPO_ID_BTN_DIVIDED_CLICK,
    COMPO_ID_BTN_MULTIPLY_CLICK,
    COMPO_ID_BTN_REDUCE_CLICK,
    COMPO_ID_BTN_ADD_CLICK,
    COMPO_ID_BTN_EQUAL_CLICK,
    COMPO_ID_NUM_DISP_ZERO,
};

#define CALCULATOR_DISP_BTN_ITEM_CNT    ((int)(sizeof(tbl_calculator_disp_btn_item) / sizeof(tbl_calculator_disp_btn_item[0])))
#define TEN_MILLION                 10000000
#define MILLION                     1000000
#define HUNDRED_THOUSAND            100000
#define TEN_THOUSAND                10000
#define THOUSAND                    1000
#define HUNDRED                     100
#define TEN                         10
#define ONE                         1
#define CALCULATOR_DISP_MAX         99999999          //显示最大数字
#define CALCULATOR_DISP_MIN         0                 //显示最小数字
#define CALCULATOR_DISP_NUMBER_MAX  8                 //显示最大位数

typedef struct calculator_disp_btn_item_t_ {
    u32 res_addr;
    u16 btn_id;
    s16 x;
    s16 y;
} calculator_disp_btn_item_t;

//按钮item，创建时遍历一下
static const calculator_disp_btn_item_t tbl_calculator_disp_btn_item[] = {
    {UI_BUF_CALCULATOR_1_CLICK_BIN,             COMPO_ID_BTN_NUM1,              43,     274},
    {UI_BUF_CALCULATOR_2_CLICK_BIN,             COMPO_ID_BTN_NUM2,              121,    274},
    {UI_BUF_CALCULATOR_3_CLICK_BIN,             COMPO_ID_BTN_NUM3,              199,    274},
    {UI_BUF_CALCULATOR_4_CLICK_BIN,             COMPO_ID_BTN_NUM4,              43,     216},
    {UI_BUF_CALCULATOR_5_CLICK_BIN,             COMPO_ID_BTN_NUM5,              121,    216},
    {UI_BUF_CALCULATOR_6_CLICK_BIN,             COMPO_ID_BTN_NUM6,              199,    216},
    {UI_BUF_CALCULATOR_7_CLICK_BIN,             COMPO_ID_BTN_NUM7,              43,     158},
    {UI_BUF_CALCULATOR_8_CLICK_BIN,             COMPO_ID_BTN_NUM8,              121,    158},
    {UI_BUF_CALCULATOR_9_CLICK_BIN,             COMPO_ID_BTN_NUM9,              199,    158},
    {UI_BUF_CALCULATOR_0_CLICK_BIN,             COMPO_ID_BTN_NUM0,              121,    332},
 // {UI_BUF_CALCULATOR_MINUS_CLICK_BIN,         COMPO_ID_BTN_MINUS_CLICK,     43,     332},
 // {UI_BUF_CALCULATOR_POINT_CLICK_BIN,         COMPO_ID_BTN_POINT_CLICK,     199,    332},
    {UI_BUF_CALCULATOR_CE_CLICK_BIN,            COMPO_ID_BTN_CE_CLICK,          43,     100},
    {UI_BUF_CALCULATOR_C_CLICK_BIN,             COMPO_ID_BTN_C_CLICK,           121,    100},
    {UI_BUF_CALCULATOR_DEL_CLICK_BIN,           COMPO_ID_BTN_DEL_CLICK,         199,    100},
    {UI_BUF_CALCULATOR_DIVIDED_CLICK_BIN,       COMPO_ID_BTN_DIVIDED_CLICK,     277,    100},
    {UI_BUF_CALCULATOR_MULTIPLY_CLICK_BIN,      COMPO_ID_BTN_MULTIPLY_CLICK,    277,    158},
    {UI_BUF_CALCULATOR_REDUCE_CLICK_BIN,        COMPO_ID_BTN_REDUCE_CLICK,      277,    216},
    {UI_BUF_CALCULATOR_ADD_CLICK_BIN,           COMPO_ID_BTN_ADD_CLICK,         277,    274},
    {UI_BUF_CALCULATOR_EQUAL_CLICK_BIN,         COMPO_ID_BTN_EQUAL_CLICK,       277,    332},
};

enum{
    calculator_one = 0,  //计算器第一个数据的有效位数
    calculator_tws,      //计算器第二个数据的有效位数

    //符号位
    calculator_divided,  //除
    calculator_multiply, //乘
    calculator_reduce,   //减
    calculator_add,      //加
    calculator_equal,    //等于
};


//创建计算器窗体，创建窗体中不要使用功能结构体 func_cb.f_cb
compo_form_t *func_calculator_form_create(void)
{
    //新建窗体和背景
    compo_form_t *frm = compo_form_create(true);

    //创建按钮
    compo_button_t *btn;
    for (u8 idx_btn = 0; idx_btn < CALCULATOR_DISP_BTN_ITEM_CNT; idx_btn++) {
        btn = compo_button_create_by_image(frm, tbl_calculator_disp_btn_item[idx_btn].res_addr);
        compo_setid(btn, tbl_calculator_disp_btn_item[idx_btn].btn_id);
        compo_button_set_pos(btn, tbl_calculator_disp_btn_item[idx_btn].x, tbl_calculator_disp_btn_item[idx_btn].y);
    }

    //创建数字
    compo_number_t *num;
    num = compo_number_create(frm, UI_BUF_COMMON_NUM_24_38_BIN, CALCULATOR_DISP_NUMBER_MAX);
    compo_setid(num, COMPO_ID_NUM_DISP_ZERO);
    compo_number_set_pos(num, 150, 34);
    compo_number_set_zfill(num, 0);
    compo_number_set_visible(num, 0);

    return frm;
}

//计算器功能事件处理
static void func_calculator_process(void)
{
    func_process();
}

//计算前八位的数字显示。
u32 func_calculator_number(u8 cnt, u8 *data)
{
    if (cnt == 8) {
        return data[calculator_one] * TEN_MILLION + data[1] * MILLION + data[2] * HUNDRED_THOUSAND + data[3] * TEN_THOUSAND + data[4] * THOUSAND + data[5] * HUNDRED + data[6] * TEN + data[7];
    } else if (cnt == 7) {
        return data[calculator_one] * MILLION + data[1] * HUNDRED_THOUSAND + data[2] * TEN_THOUSAND + data[3] * THOUSAND + data[4] * HUNDRED + data[5] * TEN + data[6];
    } else if (cnt == 6) {
        return data[calculator_one] * HUNDRED_THOUSAND + data[1] * TEN_THOUSAND + data[2] * THOUSAND + data[3] * HUNDRED + data[4] * TEN + data[5];
    } else if (cnt == 5) {
        return data[calculator_one] * TEN_THOUSAND + data[1] * THOUSAND + data[2] * HUNDRED + data[3] * TEN + data[4];
    } else if (cnt == 4) {
        return data[calculator_one] * THOUSAND+data[1] * HUNDRED + data[2] * TEN + data[3];
    } else if (cnt == 3) {
        return data[calculator_one] * HUNDRED + data[1] * TEN + data[2];
    } else if (cnt == 2) {
        return data[calculator_one] * TEN + data[1];
    } else if (cnt == 1) {
        return data[calculator_one];
    }
    return 0;
}

//计算数字换算到数组。
void func_calculator_array(u32 sum, u8 *data, u8 *data_cnt)
{
    if (sum / TEN_MILLION) {
        data_cnt[calculator_one] = 8;
    } else if (sum / MILLION) {
        data_cnt[calculator_one] = 7;
    } else if (sum / HUNDRED_THOUSAND) {
        data_cnt[calculator_one] = 6;
    } else if (sum / TEN_THOUSAND) {
        data_cnt[calculator_one] = 5;
    } else if (sum / THOUSAND) {
        data_cnt[calculator_one] = 4;
    } else if (sum / HUNDRED) {
        data_cnt[calculator_one] = 3;
    } else if (sum / TEN) {
        data_cnt[calculator_one] = 2;
    } else {
        data_cnt[calculator_one] = 1;
    }

    for (u8 i=data_cnt[calculator_one];i>0;i--) {
        data[i-1] = sum % 10;
        sum /= 10;
    }

    return;
}
//单击按钮
static void func_calculator_disp_button_click(void)
{
    int id = compo_get_button_id();
    f_calculator_t *nm = (f_calculator_t *)func_cb.f_cb;

    //获取数字组件的地址
    compo_number_t *num  = compo_getobj_byid(COMPO_ID_NUM_DISP_ZERO);

    switch (id) {
    case COMPO_ID_BTN_NUM0...COMPO_ID_BTN_NUM9:
        if ((nm->number_cnt[calculator_one]>=CALCULATOR_DISP_NUMBER_MAX) || (nm->number_cnt[calculator_tws]>=CALCULATOR_DISP_NUMBER_MAX)) {
            nm->number_cnt[calculator_one] = 0;
            nm->number_cnt[calculator_tws] = 0;
            nm->step[calculator_one] = 0;
            nm->step[calculator_tws] = 0;
        }

        if ((!nm->step[calculator_one]) && (nm->number_cnt[calculator_one]<CALCULATOR_DISP_NUMBER_MAX) && (nm->number_cnt[calculator_tws]<CALCULATOR_DISP_NUMBER_MAX)) {
            nm->number_one[nm->number_cnt[calculator_one]++] = (id - 1);
        } else {
            nm->number_tws[nm->number_cnt[calculator_tws]++] = (id - 1);
        }

        break;

    case COMPO_ID_BTN_DEL_CLICK:
        if ((!nm->step[calculator_one]) && nm->number_cnt[calculator_one]) {
            nm->number_cnt[calculator_one]--;
        } else if(nm->number_cnt[calculator_tws]) {
            nm->number_cnt[calculator_tws]--;
        }
        break;

    case COMPO_ID_BTN_C_CLICK:
        nm->number_cnt[calculator_one] = 0;
        nm->number_cnt[calculator_tws] = 0;
        nm->cnt = 0;
        nm->step[calculator_one] = 0;
        nm->step[calculator_tws] = 0;
        break;

    case COMPO_ID_BTN_CE_CLICK:
        if (nm->number_cnt[calculator_tws]) {
         nm->number_cnt[calculator_tws] = 0;
        } else {
         nm->number_cnt[calculator_one] = 0;
        }

        nm->step[calculator_one] = 0;
        nm->step[calculator_tws] = 0;
        break;

    case COMPO_ID_BTN_DIVIDED_CLICK:
        if (!nm->step[calculator_one] && nm->number_cnt[calculator_one]) {
            nm->step[calculator_one] = calculator_divided;
        } else if (nm->step[calculator_one] && nm->number_cnt[calculator_tws]){
            nm->step[calculator_tws] = calculator_divided;
        }
        break;

    case COMPO_ID_BTN_MULTIPLY_CLICK:
        if (!nm->step[calculator_one] && nm->number_cnt[calculator_one]) {
            nm->step[calculator_one] = calculator_multiply;
        } else if (nm->step[calculator_one] && nm->number_cnt[calculator_tws]){
            nm->step[calculator_tws] = calculator_multiply;
        }
        break;

    case COMPO_ID_BTN_ADD_CLICK:
        if (!nm->step[calculator_one] && nm->number_cnt[calculator_one]) {
            nm->step[calculator_one] = calculator_reduce;
        } else if (nm->step[calculator_one] && nm->number_cnt[calculator_tws]){
            nm->step[calculator_tws] = calculator_reduce;
        }

        break;

    case COMPO_ID_BTN_REDUCE_CLICK:
        if (!nm->step[calculator_one] && nm->number_cnt[calculator_one]) {
            nm->step[calculator_one] = calculator_add;
        } else if (nm->step[calculator_one] && nm->number_cnt[calculator_tws]){
            nm->step[calculator_tws] = calculator_add;
        }
        break;

    case COMPO_ID_BTN_EQUAL_CLICK:
        if (!nm->step[calculator_one] && nm->number_cnt[calculator_one]) {
            nm->step[calculator_one] = calculator_equal;
        } else if (nm->step[calculator_one] && nm->number_cnt[calculator_tws]){
            nm->step[calculator_tws] = calculator_equal;
        }
        break;

    default:
        break;
    }

    if (!nm->step[calculator_one] && !nm->number_cnt[calculator_tws]) {
        compo_number_set(num, func_calculator_number(nm->number_cnt[calculator_one], &nm->number_one[calculator_one]));
        compo_number_set_visible(num, true);

    } else if ((nm->step[calculator_one] == calculator_divided) && nm->number_cnt[calculator_one]) {
        if(!nm->number_cnt[calculator_tws]) {
            compo_number_set_visible(num, false);
        } else if (nm->number_cnt[calculator_tws]) {
        if(func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]) == 0) {
            printf("被除数不能为0\r\n");
            return ;
        }

        compo_number_set(num, func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]));
        compo_number_set_visible(num, true);
        } else {
            compo_number_set(num, nm->cnt);
            compo_number_set_visible(num, true);
        }

    } else if ((nm->step[calculator_one] == calculator_multiply) && nm->number_cnt[calculator_one]) {
        if(!nm->number_cnt[calculator_tws]) {
            compo_number_set_visible(num, false);
        } else if (nm->number_cnt[calculator_tws]) {
            compo_number_set(num, func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]));
            compo_number_set_visible(num, true);
        }

    } else if ((nm->step[calculator_one] == calculator_reduce) && nm->number_cnt[calculator_one]) {
        if (!nm->number_cnt[calculator_tws]) {
            compo_number_set_visible(num, false);

    } else if (nm->number_cnt[calculator_tws]!=0) {
            compo_number_set(num, func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]));
            compo_number_set_visible(num, true);
        }

    } else if ((nm->step[calculator_one] == calculator_add) && nm->number_cnt[calculator_one]) {
        if (!nm->number_cnt[calculator_tws]) {
            compo_number_set_visible(num, false);
        }else if(nm->number_cnt[calculator_tws]){
            compo_number_set(num, func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]));
            compo_number_set_visible(num, true);
        }

    } else {
            compo_number_set(num, nm->cnt);
            compo_number_set_visible(num, true);
        }

    if (nm->step[calculator_tws] && nm->number_cnt[calculator_one] && nm->number_cnt[calculator_tws]) {
        if (nm->step[calculator_one] == calculator_divided) {
        nm->cnt = func_calculator_number(nm->number_cnt[calculator_one], &nm->number_one[0])/func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]);
        nm->step[calculator_one] = nm->step[calculator_tws];
        nm->step[calculator_tws] = 0;

        } else if (nm->step[calculator_one] == calculator_multiply) {
        nm->cnt = func_calculator_number(nm->number_cnt[calculator_one], &nm->number_one[0])*func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]);
        nm->step[calculator_one] = nm->step[calculator_tws];
        nm->step[calculator_tws] = 0;

        } else if (nm->step[calculator_one] == calculator_reduce) {
        nm->cnt = func_calculator_number(nm->number_cnt[calculator_one], &nm->number_one[0])+func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]);
        nm->step[calculator_one] = nm->step[calculator_tws];
        nm->step[calculator_tws] = 0;

        } else if (nm->step[calculator_one] == calculator_add) {
        nm->cnt = func_calculator_number(nm->number_cnt[calculator_one], &nm->number_one[0])-func_calculator_number(nm->number_cnt[calculator_tws], &nm->number_tws[0]);
        nm->step[calculator_one] = nm->step[calculator_tws];
        nm->step[calculator_tws] = 0;
        }

        if ((nm->cnt > CALCULATOR_DISP_MAX) || (nm->cnt < CALCULATOR_DISP_MIN)) {
            nm->number_cnt[calculator_one] = 0;
            nm->number_cnt[calculator_tws] = 0;
            nm->step[calculator_one] = 0;
            nm->step[calculator_tws] = 0;
            nm->cnt = 0;
            return ;
        }

        func_calculator_array(nm->cnt, &nm->number_one[0], &nm->number_cnt[calculator_one]);
        compo_number_set(num, nm->cnt);
        compo_number_set_visible(num, true);
        nm->number_cnt[calculator_tws] = 0;
    }

     if ((nm->step[calculator_one] == calculator_equal || nm->step[calculator_tws] == calculator_equal) && nm->number_cnt[calculator_one]) {
        compo_number_set(num, nm->cnt);
        compo_number_set_visible(num, true);
        nm->step[calculator_one] = 0;
        nm->step[calculator_tws] = 0;
    }
}

//计算器功能消息处理
static void func_calculator_message(size_msg_t msg)
{
    switch (msg) {
    case MSG_CTP_CLICK:
        func_calculator_disp_button_click();
        break;

    case MSG_CTP_SHORT_UP:
        break;

    case MSG_CTP_SHORT_DOWN:
        break;

    case MSG_CTP_LONG:
        break;

    default:
        func_message(msg);
        break;
    }
}

//进入计算器功能
static void func_calculator_enter(void)
{
    func_cb.f_cb = func_zalloc(sizeof(f_calculator_t));
    func_cb.frm_main = func_calculator_form_create();
}

//退出计算器功能
static void func_calculator_exit(void)
{
    func_cb.last = FUNC_CALCULATOR;
}

//计算器功能
void func_calculator(void)
{
    printf("%s\n", __func__);
    func_calculator_enter();
    while (func_cb.sta == FUNC_CALCULATOR) {
        func_calculator_process();
        func_calculator_message(msg_dequeue());
    }
    func_calculator_exit();
}
