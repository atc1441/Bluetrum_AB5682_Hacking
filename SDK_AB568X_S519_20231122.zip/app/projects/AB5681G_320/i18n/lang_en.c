#include "include.h"

const char * const i18n_en[] = {
    [STR_CLOCK] = "Clock",
};
